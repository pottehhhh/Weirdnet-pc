package dev.cluvex.zedsecure.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.cluvex.zedsecure.data.account.AccountRepository
import dev.cluvex.zedsecure.platform.currentTimeMillis
import dev.cluvex.zedsecure.shared.resources.*
import dev.cluvex.zedsecure.ui.platform.LocalPlatform
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.getString
import org.jetbrains.compose.resources.stringResource

/** 1234567 -> "1,234,567". */
internal fun toman(n: Long): String = n.toString().reversed().chunked(3).joinToString(",").reversed()

internal suspend fun errorText(e: Throwable?): String {
    val ex = e as? AccountRepository.AccountException
    val code = ex?.message
    return when {
        ex?.kind == AccountRepository.AccountException.Kind.Network -> getString(Res.string.account_error_network)
        ex?.kind == AccountRepository.AccountException.Kind.Unauthorized -> getString(Res.string.account_err_key)
        code == "balance_insufficient" || code == "insufficient_balance" -> getString(Res.string.account_err_balance)
        code == "plan_not_found" -> getString(Res.string.account_err_plan)
        code == "error_panel" || code == "panel_error" -> getString(Res.string.account_err_panel)
        code == "limited_rate" || code == "rate_limited" -> getString(Res.string.account_err_rate)
        code == "invalid_discount" -> getString(Res.string.account_err_discount)
        code == "price_changed" -> getString(Res.string.account_err_price_changed)
        code == "gb_out_of_range" || code == "days_out_of_range" -> getString(Res.string.account_err_range)
        code == "open_invoice" -> getString(Res.string.account_err_invoice)
        code == "service_not_found" -> getString(Res.string.account_err_service)
        code == "account_exists" -> getString(Res.string.account_err_exists)
        code == "panel_not_found" -> getString(Res.string.account_err_panel_not_found)
        code == "panel_required" -> getString(Res.string.account_err_panel_required)
        code == "trial_disabled" -> getString(Res.string.account_err_trial_disabled)
        code == "trial_already_used" -> getString(Res.string.account_err_trial_used)
        code == "trial_out_of_stock" -> getString(Res.string.account_err_trial_stock)
        code == "withdraw_disabled" -> getString(Res.string.err_withdraw_disabled)
        code == "below_minimum" -> getString(Res.string.err_below_minimum)
        code == "invalid_destination" -> getString(Res.string.err_invalid_destination)
        code == "insufficient_withdrawable" -> getString(Res.string.err_insufficient_withdrawable)
        code == "invalid_amount" -> getString(Res.string.err_invalid_amount)
        code == "transfer_disabled" -> getString(Res.string.err_transfer_disabled)
        code == "recipient_not_found" -> getString(Res.string.err_recipient_not_found)
        code == "same_user" -> getString(Res.string.err_same_user)
        code == "invalid_days" || code == "invalid_gb" -> getString(Res.string.account_err_range)
        code == "not_available" || code == "panel_unavailable" -> getString(Res.string.err_renew_unavailable)
        else -> getString(Res.string.account_err_generic) + (code?.let { " ($it)" } ?: "")
    }
}

internal fun gbText(bytes: Long): String {
    val x = (bytes / 1_073_741_824.0 * 10 + 0.5).toLong()
    return if (x % 10 == 0L) "${x / 10}" else "${x / 10}.${x % 10}"
}

internal fun daysLeft(expiryMs: Long?): Long? =
    expiryMs?.let { (it - currentTimeMillis()).let { d -> if (d < 0) -1 else d / 86_400_000L } }

@Composable
internal fun StatusChip(svc: AccountRepository.Service) {
    val left = daysLeft(svc.expiryMs)
    val expired = left != null && left < 0
    val ok = !expired && svc.enabled != false && (svc.status == null || svc.status == "active")
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(50),
        color = if (ok) cs.primaryContainer else cs.errorContainer,
        contentColor = if (ok) cs.onPrimaryContainer else cs.onErrorContainer,
    ) {
        Text(
            stringResource(
                when {
                    expired -> Res.string.account_status_expired
                    ok -> Res.string.account_status_active
                    else -> Res.string.account_status_disabled
                },
            ),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

/**
 * The plans without a volume (the multi-user ones) have no volume to show, only "Unlimited" and the days.
 * The server does not say so for a service, so this goes by the plan name it reports.
 */
internal fun isUnlimitedService(svc: AccountRepository.Service): Boolean {
    val p = svc.plan?.lowercase() ?: return false
    return "unlimited" in p || "نامحدود" in p || "کاربر" in p
}

@Composable
private fun StatBox(label: String, value: String, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Column(modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1)
        Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

/** Total, used and remaining volume with a usage bar, and the days left. Unlimited services show no volume. */
@Composable
internal fun ServiceStats(svc: AccountRepository.Service) {
    val cs = MaterialTheme.colorScheme
    val total = svc.totalBytes
    val used = svc.usedBytes
    val unlimited = isUnlimitedService(svc)
    val left = daysLeft(svc.expiryMs)
    val daysWord = stringResource(Res.string.account_days)
    val daysValue = when {
        left == null -> null
        left < 0 -> stringResource(Res.string.account_status_expired)
        else -> "$left $daysWord"
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (unlimited) {
            Row(Modifier.fillMaxWidth()) {
                StatBox(stringResource(Res.string.svc_volume_label), stringResource(Res.string.buy_unlimited), Modifier.weight(1f))
                if (daysValue != null) StatBox(stringResource(Res.string.svc_days_label), daysValue, Modifier.weight(1f))
            }
        } else {
            if (total != null && total > 0 && used != null) {
                val fraction = (used.toFloat() / total.toFloat()).coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = { fraction },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)),
                    color = if (fraction > 0.9f) cs.error else cs.primary,
                    trackColor = cs.surfaceVariant,
                )
                Row(Modifier.fillMaxWidth()) {
                    StatBox(stringResource(Res.string.svc_total), gbText(total) + " GB", Modifier.weight(1f))
                    StatBox(stringResource(Res.string.svc_used), gbText(used) + " GB", Modifier.weight(1f))
                    StatBox(stringResource(Res.string.svc_remaining), gbText((total - used).coerceAtLeast(0)) + " GB", Modifier.weight(1f))
                }
            }
            if (daysValue != null) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(Res.string.svc_days_label), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
                    Text(daysValue, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/** Usage bar, "x of y GB" and the days left: what a user actually wants to know about a service. */
@Composable
internal fun UsageBlock(svc: AccountRepository.Service) {
    val total = svc.totalBytes
    val used = svc.usedBytes
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (total != null && total > 0 && used != null) {
            val fraction = (used.toFloat() / total.toFloat()).coerceIn(0f, 1f)
            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)),
                color = if (fraction > 0.9f) cs.error else cs.primary,
                trackColor = cs.surfaceVariant,
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            if (total != null && total > 0 && used != null) {
                Text(
                    stringResource(Res.string.account_used_of, gbText(used), gbText(total)),
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
            } else {
                Spacer(Modifier.width(1.dp))
            }
            val left = daysLeft(svc.expiryMs)
            if (left != null) {
                Text(
                    if (left < 0) stringResource(Res.string.account_status_expired)
                    else stringResource(Res.string.account_days_left, left.toString()),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = cs.onSurface,
                )
            }
        }
    }
}

private sealed interface LoginPhase {
    data object Idle : LoginPhase
    data object Checking : LoginPhase
    data class Failed(val message: String) : LoginPhase
}

/**
 * The sign-in step, shown by every page that needs the account (buy, support, my account).
 * [reason] says why signing in is needed on that page. The user gets a personal key from the bot and
 * pastes it here; when the bot accepts it the caller's `loggedIn` state flips and the page content
 * takes over, so nothing else has to be wired up.
 */
@Composable
internal fun LoginSection(account: AccountRepository, reason: String? = null) {
    val platform = LocalPlatform.current
    val scope = rememberCoroutineScope()
    var phase by remember { mutableStateOf<LoginPhase>(LoginPhase.Idle) }
    var apiKey by remember { mutableStateOf("") }
    val cs = MaterialTheme.colorScheme

    // A key copied from the bot is picked up here, so signing in is one tap.
    var clipKey by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        clipKey = runCatching { platform.readClipboard() }.getOrNull()?.trim()?.takeIf { account.looksLikeKey(it) }
    }

    GlassPage {
        Column(
            Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            clipKey?.let { found ->
                if (apiKey.isBlank() && phase !is LoginPhase.Checking) {
                    GlassCard(Modifier.fillMaxWidth(), padding = 16.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            GlassIcon(Res.drawable.ic_lock, cs.primary)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    stringResource(Res.string.login_clip_title),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                )
                                Text(
                                    found.take(4) + "••••" + found.takeLast(3),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = cs.onSurfaceVariant,
                                )
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        CapsuleButton(
                            text = stringResource(Res.string.login_clip_use),
                            onClick = {
                                phase = LoginPhase.Checking
                                scope.launch {
                                    account.login(found).fold(
                                        onSuccess = { phase = LoginPhase.Idle; clipKey = null },
                                        onFailure = { phase = LoginPhase.Failed(errorText(it)); clipKey = null },
                                    )
                                }
                            },
                            container = cs.primary,
                            content = cs.onPrimary,
                            modifier = Modifier.fillMaxWidth(),
                            height = 46.dp,
                        )
                    }
                }
            }
            if (reason != null) {
                GlassCard(Modifier.fillMaxWidth(), padding = 16.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        GlassIcon(Res.drawable.ic_lock, cs.primary)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                stringResource(Res.string.account_login_required),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Text(reason, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
            GlassCard(Modifier.fillMaxWidth(), padding = 18.dp) {
                Text(
                    stringResource(Res.string.account_login_key_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant,
                )
                Spacer(Modifier.height(12.dp))
                GlassField(
                    value = apiKey,
                    // A pasted key often carries a trailing space or line break; none of them belong to it.
                    onValueChange = { apiKey = it.filter { c -> !c.isWhitespace() }.take(256) },
                    label = stringResource(Res.string.account_key_label),
                    mono = true,
                )
                val p = phase
                if (p is LoginPhase.Failed) {
                    Spacer(Modifier.height(8.dp))
                    Text(p.message, color = cs.error, style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(14.dp))
                CapsuleButton(
                    text = if (p is LoginPhase.Checking) stringResource(Res.string.topup_checking) else stringResource(Res.string.account_login),
                    onClick = {
                        phase = LoginPhase.Checking
                        scope.launch {
                            account.login(apiKey).fold(
                                onSuccess = { phase = LoginPhase.Idle; apiKey = "" },
                                onFailure = { phase = LoginPhase.Failed(errorText(it)) },
                            )
                        }
                    },
                    container = cs.primary,
                    content = cs.onPrimary,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = apiKey.isNotBlank() && p !is LoginPhase.Checking,
                    height = 50.dp,
                )
                Spacer(Modifier.height(8.dp))
                CapsuleButton(
                    text = stringResource(Res.string.account_get_key),
                    onClick = { platform.openUri(dev.cluvex.zedsecure.data.account.AccountConfig.BOT_URL) },
                    container = cs.primary.copy(alpha = 0.14f),
                    content = cs.primary,
                    modifier = Modifier.fillMaxWidth(),
                    height = 50.dp,
                )
            }
            Text(
                stringResource(Res.string.account_login_sub),
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 8.dp),
            )
        }
    }
}

/** A small round logo for the plan: shield (Standard), bolt (Omega), gamepad (Gaming), infinity (Unlimited). */
@Composable
internal fun PlanBadge(kind: Int, modifier: Modifier = Modifier) {
    val accent = when (kind) {
        1 -> androidx.compose.ui.graphics.Color(0xFF4D9DFF)
        2 -> androidx.compose.ui.graphics.Color(0xFFFF8A65)
        3 -> androidx.compose.ui.graphics.Color(0xFFB197FC)
        else -> androidx.compose.ui.graphics.Color(0xFF5EE0B5)
    }
    val icon = when (kind) {
        1 -> Res.drawable.ic_bolt
        2 -> Res.drawable.ic_plan_gaming
        3 -> Res.drawable.ic_plan_unlimited
        else -> Res.drawable.ic_plan_standard
    }
    androidx.compose.foundation.layout.Box(
        modifier
            .size(44.dp)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(accent.copy(alpha = 0.18f)),
        contentAlignment = Alignment.Center,
    ) {
        androidx.compose.material3.Icon(
            org.jetbrains.compose.resources.painterResource(icon),
            contentDescription = null,
            tint = accent,
            modifier = Modifier.size(24.dp),
        )
    }
}
