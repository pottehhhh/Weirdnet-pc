package dev.cluvex.zedsecure.data.account

import dev.cluvex.zedsecure.core.VpnManager
import dev.cluvex.zedsecure.domain.config.WeirdNetPlans
import dev.cluvex.zedsecure.platform.HttpTextResponse
import dev.cluvex.zedsecure.platform.KeyValueStore
import dev.cluvex.zedsecure.platform.httpJson
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/** The WEIRDNET bot's own HTTP API. Every request carries the user's personal key; there is no middle server. */
object AccountConfig {
    const val API_URL = "https://weirdico.ir/api/vpn"

    /** The sales bot, where each user gets (and can regenerate) their key. */
    const val BOT_URL = "https://t.me/WeirdNet_Bot"

    /** The human support account on Telegram, for people who prefer to write there. */
    const val SUPPORT_URL = "https://t.me/WeirdNetSup"

    /**
     * Which volume plan each of the bot's panels sells. The bot names panels by id ("pasarguard#2"),
     * the app talks about plan kinds (STANDARD, OMEGA, GAMING). The unlimited plans live on the plain
     * "pasarguard" panel and are bought by plan id, so they are not listed here.
     */
    val PANEL_KINDS: Map<String, String> = mapOf(
        "pasarguard#4" to "STANDARD",
        "nodex" to "OMEGA",
        "pasarguard#2" to "GAMING",
    )

    /** The bot's panel id for a plan kind; anything that is not a known kind is passed through as it is. */
    fun panelIdFor(kindOrId: String): String =
        PANEL_KINDS.entries.firstOrNull { it.value.equals(kindOrId, ignoreCase = true) }?.key ?: kindOrId
}

/**
 * The user's link to their bot account.
 *
 * The user asks the bot for a personal API key and types it into the app. The key only reaches that
 * user's own account (wallet, plans, services, tickets), and "change key" in the bot revokes it at once.
 */
class AccountRepository(
    rootStore: KeyValueStore,
    private val importer: suspend (url: String, name: String?) -> Result<Any?>,
    private val appHasLink: (url: String) -> Boolean,
    private val appRemoveLink: (url: String) -> Unit,
    /** True when the servers this subscription link brought into the app are WireGuard ones (the Gaming tunnel). */
    private val linkIsWireguard: (url: String) -> Boolean = { false },
    /**
     * Set for a helper that looks after one fixed account while another is on screen (see [syncOthers]).
     * Null for the normal instance, which follows whichever account is active.
     */
    private val fixedScope: String? = null,
) {
    // ---- accounts: every account keeps its own key, cache, tickets and tracked links ----

    private val root: KeyValueStore = rootStore

    private var scopeId: String = fixedScope ?: initialScope()

    /** The store the rest of this class reads and writes: the keys of the account that is active right now. */
    private val store: KeyValueStore = ScopedStore()

    private inner class ScopedStore : KeyValueStore {
        private fun k(key: String) = scopedKey(scopeId, key)
        override fun getString(key: String): String? = root.getString(k(key))
        override fun putString(key: String, value: String?) = root.putString(k(key), value)
        override fun getInt(key: String, default: Int): Int = root.getInt(k(key), default)
        override fun putInt(key: String, value: Int) = root.putInt(k(key), value)
        override fun getBoolean(key: String, default: Boolean): Boolean = root.getBoolean(k(key), default)
        override fun putBoolean(key: String, value: Boolean) = root.putBoolean(k(key), value)
        override fun remove(key: String) = root.remove(k(key))
    }

    /** One signed-in account as the switcher shows it. */
    class AccountEntry(val id: String, val label: String, val keyHint: String, val balance: Long?)

    private fun scopedKey(id: String, key: String): String =
        if (id == MAIN || key == KEY_AUTO_ADDED || key == KEY_BOUGHT || key.startsWith(KEY_KIND) ||
            key == KEY_ACCOUNTS || key == KEY_ACTIVE
        ) key else "acc_${id}_$key"

    private fun hasKey(id: String): Boolean = !root.getString(scopedKey(id, KEY_API)).isNullOrBlank()

    /** (id, label) pairs. The account signed in before several were possible is "main" and has no entry yet. */
    private fun storedIds(): List<Pair<String, String>> {
        val list = root.getString(KEY_ACCOUNTS)?.lineSequence()?.filter { it.isNotBlank() }?.map { line ->
            val i = line.indexOf('\t')
            if (i < 0) line to "" else line.substring(0, i) to line.substring(i + 1)
        }?.toMutableList() ?: mutableListOf()
        if (list.none { it.first == MAIN } && hasKey(MAIN)) list.add(0, MAIN to "")
        return list
    }

    private fun saveIds(list: List<Pair<String, String>>) {
        if (list.isEmpty()) root.remove(KEY_ACCOUNTS)
        else root.putString(KEY_ACCOUNTS, list.joinToString("\n") { it.first + "\t" + it.second })
    }

    private fun accountEntries(): List<AccountEntry> =
        storedIds().filter { hasKey(it.first) }.map { (id, label) ->
            AccountEntry(
                id = id,
                label = label,
                keyHint = root.getString(scopedKey(id, KEY_API)).orEmpty().takeLast(4),
                balance = root.getString(scopedKey(id, KEY_BAL))?.toLongOrNull(),
            )
        }

    private fun initialScope(): String {
        val active = root.getString(KEY_ACTIVE)?.takeIf { it.isNotBlank() }
        return if (active != null && hasKey(active)) active else MAIN
    }

    private val _accounts = MutableStateFlow(accountEntries())
    /** Every account that is signed in, in the order they were added. */
    val accounts: StateFlow<List<AccountEntry>> = _accounts.asStateFlow()

    private val _activeId = MutableStateFlow(scopeId)
    /** The account the screens show right now. */
    val activeId: StateFlow<String> = _activeId.asStateFlow()

    private fun refreshAccounts() {
        _accounts.value = accountEntries()
    }

    /** Switches the screens to another signed-in account. Returns false when there is nothing to switch to. */
    fun switchAccount(id: String): Boolean {
        if (fixedScope != null || id == scopeId || !hasKey(id)) return false
        enter(id)
        return true
    }

    private fun enter(id: String) {
        scopeId = id
        root.putString(KEY_ACTIVE, id)
        _activeId.value = id
        _offline.value = false
        _balance.value = store.getString(KEY_BAL)?.toLongOrNull()
        _services.value = cached("services")?.let { o ->
            runCatching { objects(o, "services").map { toService(it) }.filter { it.code.isNotBlank() } }.getOrNull()
        }.orEmpty()
        _lastSync.value = 0L
        _events.value = emptyList()
        _unreadNotes.value = 0
        _unreadSupport.value = 0
        _loggedIn.value = true
    }

    /**
     * Adds another account by its key and switches to it. The key is checked with the bot first and only kept
     * when the bot accepts it. The servers of every account stay in the app (see [syncOthers]).
     */
    suspend fun addAccount(rawKey: String): Result<Unit> {
        val key = rawKey.trim()
        if (key.isEmpty()) return Result.failure(AccountException(AccountException.Kind.Unauthorized, "invalid_api_key"))
        if (accountEntries().any { root.getString(scopedKey(it.id, KEY_API)) == key }) {
            return Result.failure(AccountException(AccountException.Kind.Server, "account_exists"))
        }
        runCatching { probe(key) }.exceptionOrNull()?.let { return Result.failure(it) }
        val taken = storedIds().map { it.first }.toSet()
        var id = "a" + nowSec()
        while (id in taken) id += "x"
        root.putString(scopedKey(id, KEY_API), key)
        saveIds(storedIds() + (id to ""))
        refreshAccounts()
        if (fixedScope == null) enter(id)
        return Result.success(Unit)
    }

    /** Asks the bot one cheap question with [key] and throws what the bot answers when it refuses. */
    private suspend fun probe(key: String) {
        val o = parse(post("key=" + percentEncode(key) + "&action=balance"))
        if (o.bool("ok") == false) {
            val code = o.text("error")
            throw AccountException(
                if (code == "invalid_api_key") AccountException.Kind.Unauthorized else AccountException.Kind.Server,
                code,
            )
        }
    }

    fun renameAccount(id: String, label: String) {
        saveIds(storedIds().map { if (it.first == id) id to label.trim().take(24) else it })
        refreshAccounts()
    }

    /**
     * Signs one account out of the app. Its servers stay in the app, like after any sign-out. When it was
     * the active one, the next account takes over; with none left the app is signed out.
     */
    fun removeAccount(id: String) {
        val wasActive = id == scopeId
        listOf(KEY_API, KEY_SEEN, KEY_SUPPORT_SEEN, KEY_NOTIFIED_SUPPORT, KEY_TICKET, KEY_SENT, KEY_MANAGED, KEY_BAL)
            .forEach { root.remove(scopedKey(id, it)) }
        CACHED_ACTIONS.forEach { root.remove(scopedKey(id, KEY_CACHE + it)) }
        saveIds(storedIds().filterNot { it.first == id })
        refreshAccounts()
        if (fixedScope != null || !wasActive) return
        val next = accountEntries().firstOrNull()
        if (next != null) {
            enter(next.id)
        } else {
            scopeId = MAIN
            root.remove(KEY_ACTIVE)
            _activeId.value = MAIN
            _offline.value = false
            _balance.value = null
            _services.value = emptyList()
            _events.value = emptyList()
            _lastSync.value = 0L
            _unreadNotes.value = 0
            _unreadSupport.value = 0
            _loggedIn.value = false
        }
    }

    private var othersAt = 0L

    /**
     * Keeps the servers of every account that is not on screen in the app too, with one helper per account.
     * Does nothing more often than every [minGapSec] seconds.
     */
    suspend fun syncOthers(minGapSec: Long = 120) {
        if (fixedScope != null || nowSec() - othersAt < minGapSec) return
        othersAt = nowSec()
        for (entry in accountEntries()) {
            if (entry.id == scopeId) continue
            runCatching { sibling(entry.id).refresh() }
        }
        refreshAccounts()
    }

    private fun sibling(id: String): AccountRepository =
        AccountRepository(
            rootStore = root,
            importer = importer,
            appHasLink = appHasLink,
            appRemoveLink = appRemoveLink,
            linkIsWireguard = linkIsWireguard,
            fixedScope = id,
        ).also { it.send = send }

    fun isInApp(url: String): Boolean = appHasLink(url)
    fun removeFromApp(url: String) {
        appRemoveLink(url)
        // The user took this one out on purpose: stop tracking it so the sync does not touch it again.
        val m = managed()
        if (m.values.any { it.equals(url, ignoreCase = true) }) {
            saveManaged(m.filterValues { !it.equals(url, ignoreCase = true) })
        }
    }

    /** One pass of [syncServices]: how many subscriptions were added, taken out, or moved to a new link. */
    data class SyncReport(val added: Int = 0, val removed: Int = 0, val relinked: Int = 0) {
        val changed: Boolean get() = added + removed + relinked > 0
    }

    /** One change the sync made, for the "recent changes" list of the sync center. */
    class SyncEvent(val at: Long, val kind: Kind, val name: String) {
        enum class Kind { Added, Removed, Relinked, Trial }
    }

    private val _events = MutableStateFlow<List<SyncEvent>>(emptyList())
    /** The newest changes between the bot and the app, newest first (kept for this run only). */
    val events: StateFlow<List<SyncEvent>> = _events.asStateFlow()

    private fun note(kind: SyncEvent.Kind, name: String) {
        _events.value = (listOf(SyncEvent(nowSec(), kind, name)) + _events.value).take(20)
    }

    /** True when [text] has the shape of a bot key: one unbroken token, not a link. */
    fun looksLikeKey(text: String?): Boolean {
        val t = text?.trim() ?: return false
        if (t.length !in 16..128 || t.any { it.isWhitespace() }) return false
        if (t.startsWith("http", ignoreCase = true) || "://" in t) return false
        return t.all { it.isLetterOrDigit() || it == '-' || it == '_' || it == ':' || it == '.' }
    }

    private val syncLock = Mutex()

    private val _loggedIn = MutableStateFlow(!store.getString(KEY_API).isNullOrBlank())
    val loggedIn: StateFlow<Boolean> = _loggedIn.asStateFlow()

    init {
        // Sessions of the old Telegram-login link server are of no use to the bot API.
        store.remove("account_session_token")
    }

    /** True while the answers on screen are the last saved ones because the server could not be reached. */
    private val _offline = MutableStateFlow(false)
    val offline: StateFlow<Boolean> = _offline.asStateFlow()

    private val _balance = MutableStateFlow<Long?>(null)
    /** Last wallet balance seen (toman); null until it has been fetched. Shown on Home. */
    val balanceFlow: StateFlow<Long?> = _balance.asStateFlow()

    private val _services = MutableStateFlow<List<Service>>(emptyList())
    /** The account's services as the bot last reported them. Every screen reads this one list. */
    val servicesFlow: StateFlow<List<Service>> = _services.asStateFlow()

    private val _lastSync = MutableStateFlow(0L)
    /** When the app last heard from the bot (epoch seconds); 0 until the first answer. */
    val lastSync: StateFlow<Long> = _lastSync.asStateFlow()

    private val _syncing = MutableStateFlow(false)
    val syncing: StateFlow<Boolean> = _syncing.asStateFlow()

    private val _unreadNotes = MutableStateFlow(0)
    val unreadNotes: StateFlow<Int> = _unreadNotes.asStateFlow()

    private val _unreadSupport = MutableStateFlow(0)
    val unreadSupport: StateFlow<Int> = _unreadSupport.asStateFlow()

    class AccountException(val kind: Kind, message: String? = null) : Exception(message) {
        enum class Kind { Network, Unauthorized, Server }
    }

    /** Signs in with the key the bot gave the user. The key is only kept when the bot accepts it. */
    suspend fun login(rawKey: String): Result<Unit> {
        val key = rawKey.trim()
        if (key.isEmpty()) return Result.failure(AccountException(AccountException.Kind.Unauthorized, "invalid_api_key"))
        store.putString(KEY_API, key)
        val check = balance()
        return if (check.isSuccess) {
            _loggedIn.value = true
            _activeId.value = scopeId
            refreshAccounts()
            Result.success(Unit)
        } else {
            store.remove(KEY_API)
            Result.failure(check.exceptionOrNull() ?: AccountException(AccountException.Kind.Server))
        }
    }

    private fun nowSec(): Long = dev.cluvex.zedsecure.platform.currentTimeMillis() / 1000

    /**
     * Calls one bot action (plans, balance, buy, services, status, tickets, ...) and returns the reply
     * exactly as the bot sent it. [params] are the extra fields for that action.
     */
    suspend fun call(action: String, params: Map<String, Any> = emptyMap()): Result<JsonObject> = runCatching {
        val myScope = scopeId
        val key = root.getString(scopedKey(myScope, KEY_API))?.takeIf { it.isNotBlank() }
            ?: throw AccountException(AccountException.Kind.Unauthorized, "invalid_api_key")
        val form = buildList<Pair<String, String>> {
            add("key" to key)
            add("action" to action)
            params.forEach { (k, v) -> add(k to v.toString()) }
        }.joinToString("&") { (k, v) -> percentEncode(k) + "=" + percentEncode(v) }
        val response = try {
            post(form, retry = action !in ONCE_ACTIONS)
        } catch (e: AccountException) {
            // The answer of an account that is no longer on screen must not touch the screen.
            if (scopeId != myScope) throw AccountException(AccountException.Kind.Server, "account_switched")
            // The server cannot be reached: a read-only screen keeps showing what it showed last time.
            val saved = if (e.kind == AccountException.Kind.Network && action in CACHED_ACTIONS) cached(action, myScope) else null
            if (saved == null) throw e
            _offline.value = true
            return@runCatching saved
        }
        if (scopeId != myScope) throw AccountException(AccountException.Kind.Server, "account_switched")
        _offline.value = false
        val o = parse(response)
        if (o.bool("ok") == false) {
            val code = o.text("error")
            if (code == "invalid_api_key") {
                // The bot revoked this key ("change key" in the bot): only this account is signed out.
                removeAccount(myScope)
                throw AccountException(AccountException.Kind.Unauthorized, code)
            }
            throw AccountException(AccountException.Kind.Server, code)
        }
        if (action in CACHED_ACTIONS) root.putString(scopedKey(myScope, KEY_CACHE + action), o.toString())
        o
    }

    private fun cached(action: String, id: String = scopeId): JsonObject? =
        root.getString(scopedKey(id, KEY_CACHE + action))?.let { runCatching { Json.parseToJsonElement(it).jsonObject }.getOrNull() }

    /** Adds a subscription link to the app's own subscription list. */
    suspend fun addToApp(url: String, name: String?): Result<Any?> = importer(url, name)

    class Plan(
        val id: String,
        val title: String,
        val volumeGb: String?,
        val days: String?,
        val price: Long?,
        val appDiscount: Int? = null,
        val appPrice: Long? = null,
        val appLabel: String? = null,
        /** "UNLIMITED" for the multi-user plans; anything else is sold by volume. */
        val category: String? = null,
        /** How many devices/users the plan allows (the unlimited plans). */
        val ipLimit: Int? = null,
    ) {
        val isUnlimited: Boolean get() = category.equals("UNLIMITED", ignoreCase = true)
    }

    class Note(val id: Long, val title: String, val body: String, val at: Long)

    class ChatMessage(val id: Long, val fromSupport: Boolean, val body: String, val at: Long)

    data class Service(
        val code: String,
        val email: String?,
        val subLink: String?,
        val plan: String?,
        val status: String?,
        val enabled: Boolean?,
        val usedBytes: Long?,
        val totalBytes: Long?,
        val expiryMs: Long?,
        /** True when this service was bought through this app (remembered on the phone). */
        val appBought: Boolean = false,
        /** The panel type the server reports ("pasarguard", "nodex", ...). */
        val panel: String? = null,
    )

    class Quote(val finalPrice: Long?, val basePrice: Long?)

    class BuyResult(val service: Service?, val balance: Long?, val charged: Long?)

    class Charge(val payUrl: String?, val orderId: String?)

    /** What the bot allows for a custom (volume + duration) plan. Every field is optional: the bot decides. */
    class CustomInfo(
        val minGb: Int, val maxGb: Int, val minDays: Int, val maxDays: Int, val perGb: Long?, val perDay: Long?,
        val panels: List<PanelLimits> = emptyList(),
    )

    /** Limits of one volume-plan kind ("STANDARD", "GAMING", "OMEGA"); a null field means the bot did not say. */
    class PanelLimits(
        val type: String, val found: Boolean,
        val minGb: Int?, val maxGb: Int?, val minDays: Int?, val maxDays: Int?, val perGb: Long?,
    )

    suspend fun balance(): Result<Long> = call("balance").mapCatching { o ->
        val n = o["balance"] ?: o["wallet"] ?: o["amount"]
        (n?.jsonPrimitive?.doubleOrNull?.toLong() ?: throw AccountException(AccountException.Kind.Server, "no balance"))
            .also {
                _balance.value = it
                store.putString(KEY_BAL, it.toString())
                refreshAccounts()
            }
    }

    suspend fun plans(): Result<List<Plan>> = call("plans").mapCatching { o ->
        objects(o, "plans").map { p ->
            Plan(
                id = p.pick("id", "plan_id").orEmpty(),
                title = p.pick("title", "name").orEmpty(),
                volumeGb = p.pick("volume_gb", "volume"),
                days = p.pick("days", "duration"),
                price = p["price"]?.jsonPrimitive?.doubleOrNull?.toLong(),
                appDiscount = p.long("app_discount")?.toInt(),
                appPrice = p.long("app_price"),
                appLabel = p.pick("app_label"),
                category = p.pick("category"),
                ipLimit = p.long("ip_limit")?.toInt(),
            )
        }.filter { it.id.isNotBlank() }
    }

    suspend fun services(): Result<List<Service>> = call("services").mapCatching { o ->
        objects(o, "services").map { toService(it) }.filter { it.code.isNotBlank() }.also { _services.value = it }
    }

    /** Live state of one service. */
    suspend fun status(code: String): Result<Service> =
        call("status", mapOf("service" to code)).map { o -> toService((o["service"] as? JsonObject) ?: o) }

    /**
     * Buys a plan ([planId]) or a custom plan ([gb] + [days]). [ref] must stay the same when the same
     * purchase is retried, so it is never charged twice. [expect] is the price the user was shown: the
     * server refuses (price_changed) when the real price is different. [code] is an optional discount code.
     */
    suspend fun buy(
        planId: String?,
        ref: String,
        gb: Int? = null,
        days: Int? = null,
        panel: String? = null,
        code: String? = null,
        expect: Long? = null,
    ): Result<BuyResult> {
        // The API has no "expected price" field, so the check is made here: ask for the live price first.
        if (expect != null) {
            val live = quote(planId, gb, days, panel, code).getOrNull()?.finalPrice
            if (live != null && live != expect) {
                return Result.failure(AccountException(AccountException.Kind.Server, "price_changed"))
            }
        }
        val params = productParams(planId, gb, days, panel, code) + mapOf("ref" to ref)
        return call("buy", params).map { o ->
            BuyResult(
                service = (o["service"] as? JsonObject)?.let { toService(it).copy(appBought = true) }
                    ?.also { markBought(it.code) },
                balance = o["balance"]?.jsonPrimitive?.doubleOrNull?.toLong()?.also { _balance.value = it },
                charged = o.long("charged"),
            )
        }
    }

    /** The price of a plan or a custom plan, with an optional discount code, without buying. */
    suspend fun quote(planId: String?, gb: Int? = null, days: Int? = null, panel: String? = null, code: String? = null): Result<Quote> =
        call("quote", productParams(planId, gb, days, panel, code)).map { o ->
            Quote(
                finalPrice = o.long("app_final") ?: priceIn(o, FINAL_KEYS),
                basePrice = o.long("app_base") ?: priceIn(o, BASE_KEYS),
            )
        }

    /** What a custom plan may be (ranges, unit prices). Falls back to wide limits when the bot does not say. */
    suspend fun custom(): Result<CustomInfo> = call("custom").map { o ->
        fun num(vararg names: String): Long? = deepLong(o, names.toSet())
        CustomInfo(
            minGb = (num("min_gb", "gb_min") ?: gbRange(o, "min") ?: 1L).toInt().coerceAtLeast(1),
            maxGb = (num("max_gb", "gb_max") ?: gbRange(o, "max") ?: 1000L).toInt().coerceAtLeast(1),
            minDays = (num("min_days", "days_min") ?: 1L).toInt().coerceAtLeast(1),
            maxDays = (num("max_days", "days_max") ?: 365L).toInt().coerceAtLeast(1),
            perGb = num("price_per_gb", "per_gb", "gb_price", "price_gb"),
            perDay = num("price_per_day", "per_day", "day_price", "price_day"),
            panels = ((o["app_panels"] ?: o["panels"] ?: o["items"]) as? kotlinx.serialization.json.JsonArray).orEmpty().mapNotNull { e ->
                val po = e as? JsonObject ?: return@mapNotNull null
                // The bot lists panels by id; the kind (STANDARD, OMEGA, GAMING) is what the app shows.
                val kind = po.pick("type")?.uppercase() ?: AccountConfig.PANEL_KINDS[po.pick("panel", "name", "id")]
                    ?: return@mapNotNull null
                PanelLimits(
                    type = kind,
                    found = (po["found"] as? JsonPrimitive)?.booleanOrNull ?: true,
                    perGb = po.long("per_gb") ?: po.long("price_per_gb"),
                    minGb = po.long("min_gb")?.toInt(), maxGb = po.long("max_gb")?.toInt(),
                    minDays = po.long("min_days")?.toInt(), maxDays = po.long("max_days")?.toInt(),
                )
            },
        )
    }

    /** Deletes one of the account's services (no refund). */
    suspend fun delete(code: String): Result<Unit> =
        call("delete", mapOf("service" to code)).map { Unit }

    /** Starts a wallet top-up. The user pays on the returned page; the balance grows by itself afterwards. */
    suspend fun charge(amount: Long): Result<Charge> = call("charge", mapOf("amount" to amount)).map { o ->
        Charge(payUrl = o.pick("pay_url", "url", "link"), orderId = o.pick("order_id", "id"))
    }

    /** "paid", "waiting", ... for a top-up invoice. */
    suspend fun chargeStatus(orderId: String): Result<String> =
        call("charge_status", mapOf("order_id" to orderId)).map { o -> o.pick("status", "state") ?: "waiting" }

    private fun productParams(planId: String?, gb: Int?, days: Int?, panel: String?, code: String?): Map<String, Any> =
        buildMap {
            if (planId != null) put("plan_id", planId)
            else {
                gb?.let { put("gb", it) }
                days?.let { put("days", it) }
                panel?.takeIf { it.isNotBlank() }?.let { put("panel", AccountConfig.panelIdFor(it)) }
            }
            code?.trim()?.takeIf { it.isNotEmpty() }?.let { put("discount_code", it) }
        }

    private fun priceIn(o: JsonObject, keys: List<String>): Long? {
        for (node in listOf(o, o["quote"], o["data"], o["result"])) {
            val obj = node as? JsonObject ?: continue
            for (k in keys) obj.long(k)?.let { return it }
        }
        return null
    }

    private fun deepLong(node: JsonElement?, names: Set<String>, depth: Int = 0): Long? {
        if (depth > 4) return null
        when (node) {
            is JsonObject -> {
                for ((k, v) in node) if (k.lowercase() in names && v is JsonPrimitive) v.doubleOrNull?.let { return it.toLong() }
                for (v in node.values) deepLong(v, names, depth + 1)?.let { return it }
            }
            is JsonArray -> for (v in node) deepLong(v, names, depth + 1)?.let { return it }
            else -> {}
        }
        return null
    }

    private fun gbRange(o: JsonObject, edge: String): Long? =
        ((o["gb"] as? JsonObject) ?: (o["volume"] as? JsonObject))?.long(edge)

    // ---- keeping the app and the account in step ----

    /**
     * One pass after sign-in and then every few minutes while the app is open: wallet balance, unread
     * counters, and the subscriptions of every service on the account are brought in line with the app
     * (see [syncServices]).
     */
    suspend fun sync(): SyncReport {
        if (!_loggedIn.value) return SyncReport()
        val report = refresh()
        refreshUnread()
        syncOthers(minGapSec = 10)
        return report
    }

    /**
     * The light pass: wallet balance and services, and the app's subscriptions brought in line with them.
     * Cheap enough to run every few seconds while the account screen is open.
     */
    suspend fun refresh(): SyncReport {
        if (!_loggedIn.value) return SyncReport()
        val sid = scopeId
        _syncing.value = true
        try {
            balance()
            val report = services().map { syncServices(it, expectScope = sid) }.getOrDefault(SyncReport())
            if (!_offline.value && _loggedIn.value && sid == scopeId) _lastSync.value = nowSec()
            if (fixedScope == null) syncOthers()
            return report
        } finally {
            _syncing.value = false
        }
    }

    /** Same as [syncServices]; kept for the screens that only care about what was added. */
    suspend fun autoAddPurchased(list: List<Service>): Int = syncServices(list).let { it.added + it.relinked }

    /**
     * Makes the app's subscription list match the services of the account:
     *  - a service whose link is not in the app yet is added (once per service, so a service the user
     *    removed later is not brought back);
     *  - a service whose link changed on the server gets its old link replaced by the new one;
     *  - a service that no longer exists on the account has its subscription (and servers) taken out.
     * Only subscriptions this sync added or adopted are ever taken out; links the user pasted by hand
     * that do not belong to a service are never touched. [list] must be a fresh answer of the server.
     */
    suspend fun syncServices(list: List<Service>, expectScope: String? = null): SyncReport = syncLock.withLock {
        // The list belongs to one account; if the screen moved to another one meanwhile, it is of no use here.
        if (expectScope != null && expectScope != scopeId) return@withLock SyncReport()
        val sid = scopeId
        val tracked = managed(sid).toMutableMap()
        val seen = autoAdded()
        var added = 0
        var removed = 0
        var relinked = 0

        for (svc in list) {
            val link = svc.subLink?.trim()?.takeIf { it.isNotBlank() } ?: continue
            val old = tracked[svc.code]
            val name = svc.email ?: svc.code
            when {
                old != null && !old.equals(link, ignoreCase = true) -> {
                    // The server hands out a new link for this service. Keep it in the app only if the old one was.
                    if (!appHasLink(old)) {
                        tracked.remove(svc.code)
                    } else if (importer(link, name).isSuccess) {
                        // The new link works: only now is the old one taken out, so a failed fetch loses nothing.
                        appRemoveLink(old)
                        tracked[svc.code] = link
                        relinked++
                        note(SyncEvent.Kind.Relinked, name)
                    }
                    // Otherwise the old link stays and the next pass tries again.
                }
                appHasLink(link) -> {
                    // Already in the app (added by hand or by an older version): follow it from now on.
                    tracked[svc.code] = link
                    if (svc.code !in seen) markAutoAdded(svc.code)
                }
                // The user removed it from the app on purpose (Servers page): leave it out.
                svc.code in seen -> tracked.remove(svc.code)
                else -> if (importer(link, name).isSuccess) {
                    tracked[svc.code] = link
                    markAutoAdded(svc.code)
                    added++
                    note(SyncEvent.Kind.Added, name)
                }
            }
        }

        // Services that are gone from the account: their link is dead, so take it out of the app.
        // Never done from an offline copy of the answer.
        if (!_offline.value) {
            val live = list.map { it.code }.toSet()
            for ((code, url) in tracked.toMap()) {
                if (code in live) continue
                if (appHasLink(url)) { appRemoveLink(url); removed++; note(SyncEvent.Kind.Removed, code) }
                tracked.remove(code)
            }
        }

        saveManaged(tracked, sid)
        SyncReport(added, removed, relinked)
    }

    // ---- links this sync looks after (service code -> subscription link) ----

    private fun managed(id: String = scopeId): Map<String, String> =
        root.getString(scopedKey(id, KEY_MANAGED))?.lineSequence()?.mapNotNull { line ->
            val i = line.indexOf('\t')
            if (i <= 0) null else line.substring(0, i) to line.substring(i + 1)
        }?.filter { it.second.isNotBlank() }?.toMap().orEmpty()

    private fun saveManaged(m: Map<String, String>, id: String = scopeId) {
        if (m.isEmpty()) root.remove(scopedKey(id, KEY_MANAGED))
        else root.putString(scopedKey(id, KEY_MANAGED), m.entries.joinToString("\n") { it.key + "\t" + it.value })
    }

    private fun hostOf(link: String?): String? =
        link?.substringAfter("://", "")?.substringBefore("/")?.lowercase()?.takeIf { it.isNotBlank() }

    /**
     * The plan family of a service: 0 Standard, 1 Omega, 2 Gaming, 3 Unlimited.
     * The server only says "pasarguard" for both Standard and Gaming, so the family of a service bought in
     * this app is remembered, and so is the server host it lives on; other services on that host follow.
     */
    fun kindOf(svc: Service): Int {
        store.getString(KEY_KIND + "code_" + svc.code)?.toIntOrNull()?.let { return it }
        when (svc.panel?.let { AccountConfig.PANEL_KINDS[it] }) {
            "STANDARD" -> return 0
            "OMEGA" -> return 1
            "GAMING" -> return 2
        }
        val panel = svc.panel?.lowercase().orEmpty()
        val plan = svc.plan?.lowercase().orEmpty()
        return when {
            "nodex" in panel || "omega" in panel || "omega" in plan || "امگا" in plan -> 1
            "gaming" in panel || "gaming" in plan || "گیم" in plan -> 2
            "unlimited" in plan || "نامحدود" in plan || "کاربر" in plan -> 3
            // A link on one of the WEIRDNET plan hosts says which plan it is.
            svc.subLink?.let { WeirdNetPlans.familyOf(it) } != null -> WeirdNetPlans.familyOf(svc.subLink!!)!!
            // The server calls both Standard and Gaming "pasarguard", but a Gaming service hands out WireGuard servers.
            svc.subLink?.let { linkIsWireguard(it) } == true -> 2
            else -> hostOf(svc.subLink)?.let { store.getString(KEY_KIND + "host_" + it)?.toIntOrNull() } ?: 0
        }
    }

    /** Remembers the family of a service bought just now (see [kindOf]). */
    fun learnKind(svc: Service, kind: Int) {
        store.putString(KEY_KIND + "code_" + svc.code, kind.toString())
        if (kind != 3) hostOf(svc.subLink)?.let { store.putString(KEY_KIND + "host_" + it, kind.toString()) }
    }

    /** Adds a service bought just now. When it fails, the next [sync] tries again by itself. */
    suspend fun addPurchased(svc: Service): Boolean {
        val link = svc.subLink ?: return false
        if (appHasLink(link)) { markAutoAdded(svc.code); track(svc.code, link); return true }
        val ok = importer(link, svc.email ?: svc.code).isSuccess
        if (ok) { markAutoAdded(svc.code); track(svc.code, link) }
        return ok
    }

    /** Adds one service by hand ("add to app") and keeps it in step with the account from then on. */
    suspend fun addService(svc: Service): Result<Any?> {
        val link = svc.subLink ?: return Result.failure(IllegalStateException("no link"))
        val r = importer(link, svc.email ?: svc.code)
        if (r.isSuccess) { markAutoAdded(svc.code); track(svc.code, link) }
        return r
    }

    private fun track(code: String, link: String) = saveManaged(managed() + (code to link))

    /** Called when a purchase made right now was added directly, so it is not added a second time. */
    fun markAutoAdded(code: String) {
        store.putString(KEY_AUTO_ADDED, (autoAdded() + code).takeLast(200).joinToString(","))
    }

    private fun autoAdded(): List<String> =
        store.getString(KEY_AUTO_ADDED)?.split(',')?.filter { it.isNotBlank() }.orEmpty()

    // ---- bought-in-app marker (kept on the phone; the bot API has no such flag) ----

    private fun bought(): Set<String> =
        store.getString(KEY_BOUGHT)?.split(',')?.filter { it.isNotBlank() }?.toSet().orEmpty()

    private fun markBought(code: String) {
        if (code.isBlank()) return
        store.putString(KEY_BOUGHT, (bought() + code).toList().takeLast(200).joinToString(","))
    }

    // ---- announcements: the bot API has none, so there is nothing to show ----

    class Fresh(val notes: List<Note>, val replies: List<ChatMessage>)

    /** Kept so the rest of the app keeps working; the bot API has no endpoint for this. */
    suspend fun hello(version: String, device: String): Result<Unit> = Result.success(Unit)

    /** The bot API has no announcements, so the inbox is always empty. */
    suspend fun inbox(): Result<List<Note>> = Result.success(emptyList())

    // ---- support: the bot's tickets ----

    /**
     * Every message of the user's latest [maxTickets] tickets, oldest first. A ticket's own text is the
     * user's first message; its replies follow. Ids are made up from the ticket id and the position so
     * that they only ever grow, which is what the "seen" markers rely on.
     */
    private suspend fun loadSupport(maxTickets: Int): List<ChatMessage> {
        val list = objects(call("tickets").getOrThrow(), "tickets")
            .mapNotNull { t -> t.pick("id", "id_ticket", "ticket_id")?.let { id -> id to t } }
            .sortedBy { (id, _) -> id.toLongOrNull() ?: 0L }
            .takeLast(maxTickets)
        list.lastOrNull()?.first?.let { store.putString(KEY_TICKET, it) }
        val out = mutableListOf<ChatMessage>()
        for ((index, entry) in list.withIndex()) {
            val (id, head) = entry
            val call = call("tickets", mapOf("ticket_id" to id))
            // The newest ticket must load, or the user would see an empty chat and think nobody answered.
            val detail = (if (index == list.lastIndex) call.getOrThrow() else call.getOrNull())?.let { onlyDetailOf(id, it) }
            out += buildThread(id, detail, head)
        }
        return out
    }

    private val replyKeys = listOf("replies", "answers", "messages", "responses", "comments", "conversation", "reply", "answer")
    private val textKeys = arrayOf("text", "body", "message", "content", "reply", "answer", "response", "msg", "reply_text", "answer_text", "description", "comment")

    /**
     * One ticket as messages, oldest first: the ticket's own text, then its replies. The bot may name the
     * list of replies and their text in different ways, so every usual name is tried; a plain "answer"
     * text on the ticket itself counts as support's reply.
     */
    private fun buildThread(id: String, detail: JsonObject?, head: JsonObject): List<ChatMessage> {
        val t = (detail?.get("ticket") as? JsonObject) ?: detail ?: head
        val base = (id.toLongOrNull() ?: 0L) * 1000
        var n = 0L
        val out = mutableListOf<ChatMessage>()
        val own = t.pick("text", "body", "message", "content") ?: head.pick("text", "body", "message", "content")
        if (own != null) out += ChatMessage(base + n++, false, own, timeOf(t).takeIf { it > 0 } ?: timeOf(head))

        // The replies are every object that carries a text inside a list, wherever that list sits and
        // whatever it is called ("replies", "items", "answers"...), except the ticket itself.
        val found = mutableListOf<JsonObject>()
        for (node in listOfNotNull(detail, head).distinct()) collectReplies(node, found, false)
        // The same reply can be reached twice (in the detail and in the list row); and the ticket's own
        // text is sometimes the first entry of the list.
        var replies: List<JsonObject> = found
            .distinctBy { (it.pick("id", "reply_id") ?: "") + "|" + (it.pick(*textKeys) ?: "") + "|" + timeOf(it) }
            .filter { it.pick(*textKeys) != own || it.pick("id", "reply_id") != id }
        if (replies.firstOrNull()?.pick(*textKeys) == own) replies = replies.drop(1)
        replies.forEach { r ->
            val body = r.pick(*textKeys) ?: return@forEach
            val pos = (n++).coerceAtMost(999)
            out += ChatMessage(base + pos, fromSupport(r, body), body, timeOf(r))
        }
        if (replies.isEmpty()) {
            // An answer written as a plain field of the ticket ("answer", "admin_reply", "reply_text"...).
            val answers = listOfNotNull(detail, t, head).flatMap { answerFields(it) }.distinct().filter { it != own }
            answers.forEach { out += ChatMessage(base + (n++).coerceAtMost(999), true, it, timeOf(t)) }
        }
        return out
    }

    /**
     * The bot answers the whole list of tickets when it does not understand which one is asked for. Such an
     * answer must never be read as one ticket's replies, or every thread would show every other ticket's
     * messages mixed together; it is dropped (null) and the thread falls back to the ticket's own row.
     */
    private fun onlyDetailOf(id: String, o: JsonObject): JsonObject? {
        fun foreignTickets(node: kotlinx.serialization.json.JsonElement?): Boolean = when (node) {
            is JsonArray -> node.any { e ->
                e is JsonObject && e["subject"] != null && (e.pick("id", "id_ticket", "ticket_id")?.let { it != id } == true) || foreignTickets(e)
            }
            is JsonObject -> node.values.any { foreignTickets(it) }
            else -> false
        }
        return if (foreignTickets(o)) null else o
    }

    private fun collectReplies(node: kotlinx.serialization.json.JsonElement?, out: MutableList<JsonObject>, inList: Boolean) {
        when (node) {
            is JsonArray -> node.forEach { collectReplies(it, out, true) }
            is JsonObject -> {
                if (inList && node.pick(*textKeys) != null) {
                    out += node
                    return
                }
                node.values.forEach { collectReplies(it, out, false) }
            }
            else -> Unit
        }
    }

    /** Words in a key that mean "this is an answer", for a reply written as a plain field of the ticket. */
    private fun answerFields(o: JsonObject): List<String> =
        o.entries.mapNotNull { (k, v) ->
            val key = k.lowercase()
            val looksLikeAnswer = listOf("answer", "reply", "response", "پاسخ").any { it in key }
            val notText = listOf("status", "count", "_id", "_at", "date", "time", "by", "is_", "has_", "replies").any { it in key }
            if (looksLikeAnswer && !notText) (v as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() && it != "null" } else null
        }

    /** The bot's raw answer for one ticket with subscription tokens hidden, for support to look at. */
    suspend fun ticketRaw(id: String): String =
        call("tickets", mapOf("ticket_id" to id)).fold(
            onSuccess = { Regex("""(https?://[^/"\s]+/)[^"\s]+""").replace(it.toString()) { m -> m.groupValues[1] + "xxx" } },
            onFailure = { "error: ${it.message ?: it::class.simpleName}" },
        )

    private fun rememberSent(text: String) {
        val all = (sentTexts() + text.trim()).takeLast(60)
        store.putString(KEY_SENT, all.joinToString("\u0001"))
    }

    private fun sentTexts(): List<String> =
        store.getString(KEY_SENT)?.split('\u0001')?.filter { it.isNotBlank() }.orEmpty()

    /**
     * Who wrote a reply. Marks for support win, then marks for the user, then what this phone sent itself;
     * a reply with no mark at all comes from support (the user's own text is the ticket's first message).
     */
    private fun fromSupport(r: JsonObject, body: String): Boolean {
        for (k in listOf("admin", "is_admin", "from_admin", "is_support", "support", "by_admin", "staff", "is_staff", "is_operator")) {
            val p = r[k] as? JsonPrimitive ?: continue
            if (p.booleanOrNull == true || p.doubleOrNull == 1.0) return true
        }
        for (k in listOf("is_user", "from_user", "by_user", "user", "customer", "client", "mine")) {
            val p = r[k] as? JsonPrimitive ?: continue
            if (p.booleanOrNull == true || p.doubleOrNull == 1.0) return false
        }
        if (r.pick("admin_id", "staff_id", "answered_by", "operator_id")?.let { it != "0" } == true) return true
        val who = r.pick("from", "sender", "role", "type", "by", "user_type", "author")?.lowercase()
        if (who != null) {
            if (who in setOf("admin", "support", "staff", "operator", "agent", "answer", "reply", "پشتیبان", "ادمین", "پشتیبانی")) return true
            if (who in setOf("user", "customer", "client", "me", "کاربر", "مشتری")) return false
        }
        return body.trim() !in sentTexts()
    }

    private fun timeOf(o: JsonObject): Long {
        for (k in listOf("at", "time", "date", "created_at", "created", "timestamp", "datetime", "updated_at")) {
            val p = o[k] as? JsonPrimitive ?: continue
            p.doubleOrNull?.let { v ->
                val n = v.toLong()
                return if (n > 100_000_000_000L) n / 1000 else n
            }
            parseDate(p.contentOrNull)?.let { return it }
        }
        return 0L
    }

    /** "2026-11-04 12:30:00" or "2026-11-04T12:30:00" (read as UTC) to epoch seconds. */
    private fun parseDate(text: String?): Long? {
        val m = Regex("""(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?""").find(text ?: return null) ?: return null
        val (y, mo, d, h, mi) = m.destructured
        val sec = m.groupValues[6].toIntOrNull() ?: 0
        // Days since 1970-01-01 (civil-from-days algorithm).
        var yy = y.toInt(); val mm = mo.toInt()
        if (mm <= 2) yy -= 1
        val era = (if (yy >= 0) yy else yy - 399) / 400
        val yoe = yy - era * 400
        val doy = (153 * (mm + (if (mm > 2) -3 else 9)) + 2) / 5 + d.toInt() - 1
        val doe = yoe * 365 + yoe / 4 - yoe / 100 + doy
        val days = era * 146097L + doe - 719468L
        return days * 86400 + h.toInt() * 3600 + mi.toInt() * 60 + sec
    }

    /**
     * What arrived since the last background notification: support replies. The very first check only
     * remembers where things stand, so old tickets never turn into a burst of alerts.
     */
    suspend fun newMessages(): Result<Fresh> = runCatching {
        val seen = store.getString(KEY_NOTIFIED_SUPPORT)?.toLongOrNull()
        val replies = loadSupport(1).filter { it.fromSupport }
        val latest = replies.maxOfOrNull { it.id } ?: seen ?: 0L
        store.putString(KEY_NOTIFIED_SUPPORT, latest.toString())
        if (seen == null) Fresh(emptyList(), emptyList())
        else Fresh(emptyList(), replies.filter { it.id > seen }.sortedBy { it.id })
    }

    /** Refreshes the unread counter used for the support badge on Home. */
    suspend fun refreshUnread(): Result<Unit> = runCatching {
        val seen = store.getString(KEY_SUPPORT_SEEN)?.toLongOrNull()
        val replies = loadSupport(1).filter { it.fromSupport }
        if (seen == null) {
            store.putString(KEY_SUPPORT_SEEN, (replies.maxOfOrNull { it.id } ?: 0L).toString())
            _unreadSupport.value = 0
        } else {
            _unreadSupport.value = replies.count { it.id > seen }
        }
        _unreadNotes.value = 0
    }

    /** The support conversation. Calling this while the chat is on screen counts the replies as read. */
    suspend fun supportMessages(): Result<List<ChatMessage>> = runCatching {
        val list = loadSupport(3)
        list.filter { it.fromSupport }.maxOfOrNull { it.id }?.let { store.putString(KEY_SUPPORT_SEEN, it.toString()) }
        _unreadSupport.value = 0
        list
    }

    /**
     * Adds to the user's latest ticket; opens a new one when there is none or it cannot take replies.
     * [forceNew] always opens a new ticket, with [subject] as its title.
     */
    suspend fun supportSend(text: String, subject: String? = null, forceNew: Boolean = false): Result<Unit> = runCatching {
        val open = store.getString(KEY_TICKET)
        if (open != null && !forceNew) {
            val reply = call("ticket_reply", mapOf("ticket_id" to open, "text" to text))
            if (reply.isSuccess) { rememberSent(text); return@runCatching }
            val e = reply.exceptionOrNull()
            // A lost connection must not turn into a second ticket with the same text.
            if (e is AccountException && e.kind != AccountException.Kind.Server) throw e
        }
        val title = subject?.trim()?.takeIf { it.isNotEmpty() } ?: "WeirdNet app"
        val o = call("ticket", mapOf("subject" to title, "text" to text)).getOrThrow()
        val id = (o["ticket"] as? JsonObject)?.pick("id", "id_ticket") ?: o.pick("id", "ticket_id", "id_ticket")
        rememberSent(text)
        if (id != null) store.putString(KEY_TICKET, id)
    }

    /** Opens a new ticket and returns its id (null when the bot did not say). */
    suspend fun createTicket(subject: String?, text: String): Result<String?> = runCatching {
        val title = subject?.trim()?.takeIf { it.isNotEmpty() } ?: "WeirdNet app"
        val o = call("ticket", mapOf("subject" to title, "text" to text)).getOrThrow()
        val id = (o["ticket"] as? JsonObject)?.pick("id", "id_ticket") ?: o.pick("id", "ticket_id", "id_ticket")
        rememberSent(text)
        if (id != null) store.putString(KEY_TICKET, id)
        id
    }

    // ---- panels and free trial ----

    /** One panel (plan family) the bot sells from. [key] is what `panel=` takes; [id] is the panel's own id. */
    class PanelInfo(
        val id: String,
        val key: String,
        val name: String,
        val customEnabled: Boolean,
        val trialEnabled: Boolean,
    ) {
        /** What to send as `panel=`: the key when the bot gave one, the id otherwise. */
        val ref: String get() = key.ifBlank { id }

        /** The plan kind the app shows for this panel (STANDARD, OMEGA, GAMING) or the bot's own name. */
        val label: String
            get() = AccountConfig.PANEL_KINDS[id] ?: AccountConfig.PANEL_KINDS[key] ?: name.ifBlank { ref }
    }

    /** The bot's active panels, with whether custom plans and the free trial are on for each. */
    suspend fun panels(): Result<List<PanelInfo>> = call("panels").map { o ->
        objects(o, "panels").map { p ->
            PanelInfo(
                id = p.pick("id").orEmpty(),
                key = p.pick("panel", "key").orEmpty(),
                name = p.pick("name", "title").orEmpty(),
                customEnabled = p.flag("custom_enabled") ?: false,
                // A panel that says nothing about trials is not "off": the bot itself decides when a test is taken.
                trialEnabled = p.flag("trial_enabled") ?: p.flag("trial") ?: p.flag("test_enabled") ?: p.flag("free_trial") ?: true,
            )
        }.filter { it.id.isNotBlank() || it.key.isNotBlank() }
    }

    /**
     * Claims the free trial (once per user; the bot decides if it is on). With [panel] (a panel's key or id
     * from [panels]) the trial comes from that plan; without it the bot uses its first active panel.
     * Returns the new service.
     */
    suspend fun trial(panel: String? = null): Result<Service?> =
        call("trial", buildMap<String, Any> { panel?.takeIf { it.isNotBlank() }?.let { put("panel", it) } }).map { o ->
            (o["service"] as? JsonObject)?.let { toService(it).copy(appBought = true).also { s -> markBought(s.code); note(SyncEvent.Kind.Trial, s.email ?: s.code) } }
        }

    // ---- profile, referral, key ----

    /** The account summary. [fields] are the remaining facts the bot sent, as text, with secrets hidden. */
    class Profile(
        val balance: Long?,
        val serviceCount: Int?,
        val referralLink: String?,
        val fields: List<Pair<String, String>>,
    )

    suspend fun profile(): Result<Profile> = call("profile").map { o ->
        val src = (o["profile"] as? JsonObject) ?: o
        val bal = deepLong(src, setOf("balance", "wallet"))?.also { _balance.value = it }
        Profile(
            balance = bal,
            serviceCount = deepLong(src, setOf("services", "services_total", "services_count", "service_count", "count_services"))?.toInt(),
            referralLink = deepText(src, setOf("referral_link", "link", "ref_link", "invite_link")),
            fields = flatten(src).filter { (k, v) -> k != "ok" && v.isNotBlank() }.map { (k, v) -> k to maskSecret(k, v) },
        )
    }

    class Referral(
        val link: String?,
        val clicks: Long?,
        val invited: Long?,
        val reward: Long?,
        val points: Long?,
    )

    /** The invite link with its click, invited-friend, reward (and, when on, points) counters. */
    suspend fun referral(): Result<Referral> = call("referral").map { o ->
        val src = (o["referral"] as? JsonObject) ?: o
        Referral(
            link = deepText(src, setOf("link", "referral_link", "url", "invite_link")),
            clicks = deepLong(src, setOf("clicks", "click_count", "visits")),
            invited = deepLong(src, setOf("invited", "invited_count", "joins", "referred", "referrals", "count")),
            reward = deepLong(src, setOf("reward", "reward_earned", "rewards", "bonus", "earned")),
            points = deepLong(src, setOf("points", "score")),
        )
    }

    /** Status of the personal API key. The key itself is returned by the bot only to its owner. */
    class ApiKeyInfo(val key: String?, val hasKey: Boolean, val allowed: Boolean?)

    suspend fun apiKey(): Result<ApiKeyInfo> = call("apikey").map { o ->
        val src = (o["apikey"] as? JsonObject) ?: o
        val key = src.pick("api_key", "key")
        ApiKeyInfo(key = key, hasKey = src.flag("has_key") ?: (key != null), allowed = src.flag("allowed"))
    }

    // ---- renew ----

    /** One way to renew: how many days, how much volume (when it is part of the option) and the price for this user. */
    class RenewOption(val days: Long?, val gb: Long?, val price: Long?, val planId: String?)

    class RenewInfo(val options: List<RenewOption>, val gbMin: Long?, val gbMax: Long?, val daysOptions: List<Long> = emptyList(), val raw: String = "")

    /** What a service can be renewed with, priced for this user. */
    suspend fun renewInfo(service: String): Result<RenewInfo> = call("renew_info", mapOf("service" to service)).map { o ->
        val src = (o["renew"] as? JsonObject) ?: (o["info"] as? JsonObject) ?: o
        val out = ArrayList<RenewOption>()
        // "options" carries days / gb / final price per row; "days_options" is the plain list of allowed durations.
        for (key in listOf("options", "items", "plans")) {
            val arr = src[key] as? JsonArray ?: continue
            for (e in arr) {
                when (e) {
                    is JsonObject -> out.add(
                        RenewOption(
                            days = deepLong(e, setOf("days", "duration", "day")),
                            gb = deepLong(e, setOf("gb", "volume_gb", "volume")),
                            price = priceIn(e, FINAL_KEYS) ?: priceIn(e, BASE_KEYS),
                            planId = e.pick("plan_id"),
                        ),
                    )
                    is JsonPrimitive -> e.doubleOrNull?.toLong()?.let { out.add(RenewOption(it, null, null, null)) }
                    else -> {}
                }
            }
            if (out.isNotEmpty()) break
        }
        val dayList = ArrayList<Long>()
        (src["days_options"] as? JsonArray)?.forEach { e ->
            when (e) {
                is JsonPrimitive -> e.doubleOrNull?.toLong()?.let { dayList.add(it) }
                is JsonObject -> deepLong(e, setOf("days", "day", "duration"))?.let { dayList.add(it) }
                else -> {}
            }
        }
        RenewInfo(
            options = out.filter { it.days != null || it.planId != null || it.gb != null }.distinctBy { Triple(it.days, it.gb, it.planId) },
            gbMin = deepLong(src, setOf("gb_min", "min_gb")),
            gbMax = deepLong(src, setOf("gb_max", "max_gb")),
            daysOptions = dayList.distinct().sorted(),
            raw = o.toString(),
        )
    }

    class RenewResult(val charged: Long?, val balance: Long?, val service: Service?)

    /** Renews a service from the wallet. The same [ref] sent again never charges twice. */
    suspend fun renew(service: String, ref: String, days: Int? = null, gb: Int? = null, planId: String? = null): Result<RenewResult> {
        val p = buildMap<String, Any> {
            put("service", service)
            put("ref", ref)
            if (planId != null) put("plan_id", planId) else {
                days?.let { put("days", it) }
                gb?.let { put("gb", it) }
            }
        }
        return call("renew", p).map { o ->
            RenewResult(
                charged = o.long("charged"),
                balance = o["balance"]?.jsonPrimitive?.doubleOrNull?.toLong()?.also { _balance.value = it },
                service = (o["service"] as? JsonObject)?.let { toService(it) },
            )
        }
    }

    // ---- withdraw and transfer ----

    class WithdrawInfo(val enabled: Boolean, val minAmount: Long?, val balance: Long?, val withdrawable: Long?, val label: String?)

    /** Whether withdrawing is on, the smallest amount, and how much of the balance can be taken out. */
    suspend fun withdrawInfo(): Result<WithdrawInfo> = call("withdraw_info").map { o ->
        val src = (o["withdraw"] as? JsonObject) ?: (o["info"] as? JsonObject) ?: o
        WithdrawInfo(
            enabled = src.flag("enabled") ?: false,
            minAmount = deepLong(src, setOf("min_amount", "min")),
            balance = deepLong(src, setOf("balance"))?.also { _balance.value = it },
            withdrawable = deepLong(src, setOf("withdrawable")),
            label = src.pick("label"),
        )
    }

    class WithdrawResult(val id: String?, val status: String?, val balance: Long?)

    /** Asks the admins to pay [amount] out to [destination] (card number or wallet). The amount leaves the balance at once. */
    suspend fun withdraw(amount: Long, destination: String): Result<WithdrawResult> =
        call("withdraw", mapOf("amount" to amount, "destination" to destination.trim())).map { o ->
            val req = (o["request"] as? JsonObject) ?: o
            WithdrawResult(
                id = req.pick("id"),
                status = req.pick("status"),
                balance = o["balance"]?.jsonPrimitive?.doubleOrNull?.toLong()?.also { _balance.value = it },
            )
        }

    class WithdrawItem(val id: String, val amount: Long?, val status: String?, val destination: String?, val at: Long)

    suspend fun withdraws(): Result<List<WithdrawItem>> = call("withdraws").map { o ->
        objects(o, "withdraws").mapIndexed { i, p ->
            WithdrawItem(
                id = p.pick("id", "request_id") ?: i.toString(),
                amount = p.pick("amount", "value")?.toDoubleOrNull()?.toLong(),
                status = p.pick("status", "state"),
                destination = p.pick("destination", "card", "to"),
                at = timeOf(p),
            )
        }
    }

    class TransferInfo(val enabled: Boolean, val needsApproval: Boolean, val minAmount: Long?)

    suspend fun transferInfo(): Result<TransferInfo> = call("transfer_info").map { o ->
        val src = (o["transfer"] as? JsonObject) ?: (o["info"] as? JsonObject) ?: o
        TransferInfo(
            enabled = src.flag("enabled") ?: false,
            needsApproval = src.pick("mode")?.trim()?.lowercase() == "approve",
            minAmount = deepLong(src, setOf("min_amount", "min")),
        )
    }

    class TransferResult(val status: String?, val balance: Long?)

    /** Sends [amount] to another user of the bot, by numeric Telegram id or @username. */
    suspend fun transfer(to: String, amount: Long): Result<TransferResult> {
        val who = to.trim().let { if (it.isNotEmpty() && !it.startsWith("@") && !it.all(Char::isDigit)) "@$it" else it }
        return call("transfer", mapOf("to" to who, "amount" to amount)).map { o ->
            TransferResult(
                status = o.pick("status"),
                balance = o["balance"]?.jsonPrimitive?.doubleOrNull?.toLong()?.also { _balance.value = it },
            )
        }
    }

    // ---- wallet history ----

    /** One line of the wallet's history: a transaction or a payment. */
    class WalletEntry(
        val id: String,
        val kind: String?,
        val amount: Long?,
        val at: Long,
        val note: String?,
        val status: String?,
    )

    /** Wallet transactions, newest first. [limit] is capped at 100; [kind] filters by transaction kind. */
    suspend fun transactions(limit: Int = 50, offset: Int = 0, kind: String? = null): Result<List<WalletEntry>> =
        call("transactions", historyParams(limit, offset, kind)).map { o -> entries(o, "transactions") }

    /** Successful top-ups and deposits, newest first. */
    suspend fun payments(limit: Int = 50, offset: Int = 0, kind: String? = null): Result<List<WalletEntry>> =
        call("payments", historyParams(limit, offset, kind)).map { o -> entries(o, "payments") }

    private fun historyParams(limit: Int, offset: Int, kind: String?): Map<String, Any> = buildMap {
        put("limit", limit.coerceIn(1, 100))
        put("offset", offset.coerceAtLeast(0))
        kind?.trim()?.takeIf { it.isNotEmpty() }?.let { put("kind", it) }
    }

    private fun entries(o: JsonObject, key: String): List<WalletEntry> =
        objects(o, key).mapIndexed { i, p ->
            WalletEntry(
                id = p.pick("id", "order_id", "code", "ref") ?: i.toString(),
                kind = p.pick("kind", "type"),
                amount = (p.pick("amount", "price", "value", "sum")?.toDoubleOrNull())?.toLong(),
                at = timeOf(p),
                note = p.pick("note", "description", "title", "reason", "comment", "text"),
                status = p.pick("status", "state"),
            )
        }

    // ---- tickets ----

    class TicketInfo(val id: String, val subject: String?, val status: String?, val at: Long, val text: String? = null)

    /** The user's tickets, newest first. */
    suspend fun tickets(): Result<List<TicketInfo>> = call("tickets").map { o ->
        objects(o, "tickets").mapNotNull { t ->
            val id = t.pick("id", "id_ticket", "ticket_id") ?: return@mapNotNull null
            TicketInfo(id, t.pick("subject", "title"), t.pick("status", "state"), timeOf(t), t.pick("text", "message", "body"))
        }.sortedByDescending { it.id.toLongOrNull() ?: 0L }
    }

    /** Opens a new ticket and returns its id. */
    suspend fun openTicket(subject: String, text: String): Result<String?> =
        call("ticket", buildMap<String, Any> { put("text", text); subject.takeIf { it.isNotBlank() }?.let { put("subject", it) } }).map { o ->
            ((o["ticket"] as? JsonObject)?.pick("id", "id_ticket") ?: o.pick("id", "ticket_id", "id_ticket"))
                ?.also { store.putString(KEY_TICKET, it) }
        }

    /** Every message of one ticket, oldest first: the ticket's own text, then the replies. */
    suspend fun ticketConversation(id: String): Result<List<ChatMessage>> = runCatching {
        val raw = call("tickets", mapOf("ticket_id" to id)).getOrThrow()
        val detail = onlyDetailOf(id, raw)
        // Without a usable detail, the ticket's own row from the list still gives its text.
        val row = detail ?: objects(raw, "tickets").firstOrNull { it.pick("id", "id_ticket", "ticket_id") == id } ?: JsonObject(emptyMap())
        buildThread(id, detail, row)
    }

    /** Answers one of the user's own tickets. */
    suspend fun replyTicket(id: String, text: String): Result<Unit> =
        call("ticket_reply", mapOf("ticket_id" to id, "text" to text)).map { rememberSent(text) }

    private fun toService(o: JsonObject): Service {
        val total = o.long("total_bytes")
            ?: o.long("volume_gb")?.let { it * GIB }
            ?: o.long("volume_mb")?.let { it * 1_048_576L }
        val used = o.long("used_bytes") ?: o.long("remaining_bytes")?.let { r -> total?.minus(r) }
        return Service(
            code = o.pick("code", "service", "id").orEmpty(),
            email = o.pick("email", "username"),
            subLink = o.pick("sub_link", "link"),
            plan = o.pick("plan"),
            status = o.pick("status"),
            enabled = (o["enabled"] as? JsonPrimitive)?.booleanOrNull,
            usedBytes = used,
            totalBytes = total,
            expiryMs = o.long("expiry_ms") ?: parseDate(o.pick("expires_at", "expire_at", "expiry"))?.let { it * 1000 },
            appBought = (o["app_bought"] as? JsonPrimitive)?.booleanOrNull == true || (o.pick("code", "service", "id") ?: "") in bought(),
            panel = o.pick("panel"),
        )
    }

    /** A true/false flag the bot may send as a boolean or as 1/0. */
    private fun JsonObject.flag(key: String): Boolean? {
        val p = this[key] as? JsonPrimitive ?: return null
        p.booleanOrNull?.let { return it }
        p.doubleOrNull?.let { return it != 0.0 }
        return when (p.contentOrNull?.trim()?.lowercase()) {
            "on", "yes", "enabled", "active" -> true
            "off", "no", "disabled", "inactive" -> false
            else -> null
        }
    }

    private fun deepText(node: JsonElement?, names: Set<String>, depth: Int = 0): String? {
        if (depth > 4) return null
        when (node) {
            is JsonObject -> {
                for ((k, v) in node) if (k.lowercase() in names && v is JsonPrimitive) v.contentOrNull?.takeIf { it.isNotBlank() && it != "null" }?.let { return it }
                for (v in node.values) deepText(v, names, depth + 1)?.let { return it }
            }
            is JsonArray -> for (v in node) deepText(v, names, depth + 1)?.let { return it }
            else -> {}
        }
        return null
    }

    /** Keys, tokens and links with a token in them are shown shortened. */
    private fun maskSecret(key: String, value: String): String {
        val k = key.lowercase()
        return when {
            "key" in k || "token" in k || "secret" in k -> if (value.length <= 6) "••••" else value.take(3) + "••••" + value.takeLast(2)
            value.startsWith("http", ignoreCase = true) && "sub" in k -> value.substringBefore("//") + "//" + value.substringAfter("//").substringBefore('/') + "/•••"
            else -> value
        }
    }

    private fun JsonObject.long(key: String): Long? = (this[key] as? JsonPrimitive)?.doubleOrNull?.toLong()

    private fun objects(o: JsonObject, key: String): List<JsonObject> {
        val arr = (o[key] as? JsonArray)
            ?: o.values.firstOrNull { it is JsonArray && it.all { e -> e is JsonObject } } as? JsonArray
            ?: return emptyList()
        return arr.filterIsInstance<JsonObject>()
    }

    private fun JsonObject.pick(vararg keys: String): String? =
        keys.firstNotNullOfOrNull { k -> (this[k] as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() && it != "null" } }

    private fun flatten(o: JsonObject, prefix: String = ""): List<Pair<String, String>> =
        o.entries.flatMap { (k, v) ->
            when (v) {
                is JsonObject -> flatten(v, "$prefix$k.")
                is JsonPrimitive -> listOf("$prefix$k" to (v.contentOrNull ?: ""))
                else -> emptyList()
            }
        }

    /** Signs the active account out (its servers stay in the app). Other accounts stay signed in. */
    suspend fun logout() = removeAccount(scopeId)

    private fun percentEncode(value: String): String = buildString {
        value.encodeToByteArray().forEach { byte ->
            val b = byte.toInt() and 0xFF
            val c = b.toChar()
            if (b < 0x80 && (c in 'a'..'z' || c in 'A'..'Z' || c in '0'..'9' || c in "-_.~")) append(c)
            else {
                append('%')
                append("0123456789ABCDEF"[(b shr 4) and 0xF])
                append("0123456789ABCDEF"[b and 0xF])
            }
        }
    }

    /** The one place that touches the network. Tests replace it with a fake bot. */
    internal var send: suspend (headers: Map<String, String>, form: String) -> HttpTextResponse = { headers, form ->
        httpJson(
            method = "POST",
            url = AccountConfig.API_URL,
            headers = headers,
            body = form,
            connectTimeoutMs = 12_000,
            readTimeoutMs = 30_000,
            socksPort = VpnManager.activeSocksPort,
        )
    }

    private suspend fun post(form: String, retry: Boolean = true): HttpTextResponse {
        val headers = mapOf("Content-Type" to "application/x-www-form-urlencoded", "Accept" to "application/json")
        var failure: Exception? = null
        // Short outages are common: try once more after a moment before giving up. Moves of money that have
        // no "ref" (withdraw, transfer) are sent exactly once: a second send could pay twice.
        repeat(if (retry) 2 else 1) { round ->
            if (round > 0) delay(2_500)
            try {
                return send(headers, form)
            } catch (e: Exception) {
                failure = e
            }
        }
        throw AccountException(AccountException.Kind.Network, failure?.message)
    }

    private fun parse(response: HttpTextResponse): JsonObject = try {
        Json.parseToJsonElement(response.body).jsonObject
    } catch (e: Exception) {
        throw AccountException(AccountException.Kind.Server, "bad reply (HTTP ${response.code})")
    }

    private fun JsonObject.text(key: String): String? = this[key]?.jsonPrimitive?.contentOrNull
    private fun JsonObject.bool(key: String): Boolean? = this[key]?.jsonPrimitive?.booleanOrNull

    private companion object {
        const val GIB = 1_073_741_824L
        const val KEY_CACHE = "account_cache_"
        private const val KEY_KIND = "account_kind_"
        /** Read-only answers worth showing again when the server is out of reach. */
        /** Actions that move money and carry no idempotency "ref": never sent twice. */
        val ONCE_ACTIONS = setOf("withdraw", "transfer")
        val CACHED_ACTIONS = setOf("plans", "balance", "services", "custom", "panels", "profile")
        const val KEY_API = "account_api_key"
        const val KEY_BOUGHT = "account_bought_codes"
        const val KEY_TICKET = "account_support_ticket"
        const val KEY_SEEN = "account_notes_seen"
        const val KEY_SUPPORT_SEEN = "account_support_seen"
        const val KEY_NOTIFIED_SUPPORT = "account_support_notified"
        const val KEY_SENT = "account_support_sent"
        const val KEY_AUTO_ADDED = "account_auto_added"
        private const val KEY_MANAGED = "account_managed_links"
        private const val KEY_BAL = "account_last_balance"
        private const val KEY_ACCOUNTS = "account_list"
        private const val KEY_ACTIVE = "account_active"
        private const val MAIN = "main"
        val FINAL_KEYS = listOf("final_price", "final", "payable", "pay", "total", "to_pay", "amount", "price_final", "price")
        val BASE_KEYS = listOf("base_price", "original_price", "price_before", "list_price", "price_original", "price")
    }
}
