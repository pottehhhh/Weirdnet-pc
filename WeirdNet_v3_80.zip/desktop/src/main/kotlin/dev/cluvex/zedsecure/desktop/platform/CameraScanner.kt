package dev.cluvex.zedsecure.desktop.platform

import dev.cluvex.zedsecure.platform.QrDecode
import java.awt.BorderLayout
import java.awt.Dimension
import java.awt.image.BufferedImage
import javax.swing.ImageIcon
import javax.swing.JButton
import javax.swing.JDialog
import javax.swing.JLabel
import javax.swing.SwingConstants
import javax.swing.SwingUtilities

/**
 * Scans a QR code with the computer's camera: a small window shows the camera and closes by itself when a code is read.
 * The camera library (openpnp-capture) is reached by reflection so a computer without a camera, or with a camera that
 * cannot be opened, simply falls back to reading a QR code that is visible on the screen.
 */
object CameraScanner {
    private class Camera(val stream: Any, val capture: java.lang.reflect.Method) {
        fun frame(): BufferedImage? = runCatching { capture.invoke(stream) as? BufferedImage }.getOrNull()
        fun close() { runCatching { stream.javaClass.getMethod("close").invoke(stream) } }
    }

    private fun openCamera(): Camera? = runCatching {
        val lib = Class.forName("org.openpnp.capture.OpenPnpCapture").getConstructor().newInstance()
        val devices = lib.javaClass.getMethod("getDevices").invoke(lib) as List<*>
        val device = devices.firstOrNull() ?: return@runCatching null
        val formats = device.javaClass.getMethod("getFormats").invoke(device) as List<*>
        fun dim(f: Any, name: String) = (f.javaClass.getMethod(name).invoke(f) as Number).toInt()
        // A medium size reads a QR code well and keeps decoding fast: the smallest format that is at least 640 wide.
        val format = formats.filterNotNull().filter { dim(it, "getWidth") >= 640 }.minByOrNull { dim(it, "getWidth") }
            ?: formats.firstOrNull() ?: return@runCatching null
        val open = device.javaClass.methods.first { it.name == "openStream" && it.parameterCount == 1 }
        val stream = open.invoke(device, format) ?: return@runCatching null
        Camera(stream, stream.javaClass.getMethod("capture"))
    }.getOrNull()

    /** [onResult]: the text of the code; "" when none was found; null when the user closed the window. */
    fun scan(title: String, hint: String, cancel: String, onResult: (String?) -> Unit) {
        Thread {
            val camera = openCamera()
            if (camera == null) {
                Thread.sleep(250)
                onResult(QrDecode.decodeScreens() ?: "")
                return@Thread
            }
            var done = false
            var text: String? = null
            lateinit var dialog: JDialog
            val preview = JLabel("", SwingConstants.CENTER).apply { preferredSize = Dimension(640, 480) }
            SwingUtilities.invokeAndWait {
                dialog = JDialog(null as java.awt.Frame?, title, false).apply {
                    layout = BorderLayout(8, 8)
                    add(preview, BorderLayout.CENTER)
                    add(JLabel(hint, SwingConstants.CENTER), BorderLayout.NORTH)
                    add(JButton(cancel).apply { addActionListener { done = true; dispose() } }, BorderLayout.SOUTH)
                    defaultCloseOperation = JDialog.DISPOSE_ON_CLOSE
                    addWindowListener(object : java.awt.event.WindowAdapter() {
                        override fun windowClosed(e: java.awt.event.WindowEvent?) { done = true }
                    })
                    isAlwaysOnTop = true
                    pack()
                    setLocationRelativeTo(null)
                    isVisible = true
                }
            }
            var n = 0
            val deadline = System.currentTimeMillis() + 120_000
            while (!done && System.currentTimeMillis() < deadline) {
                val img = camera.frame()
                if (img == null) { Thread.sleep(60); continue }
                val w = preview.width.coerceAtLeast(320)
                val h = (w * img.height / img.width.coerceAtLeast(1)).coerceAtLeast(1)
                val shown = img.getScaledInstance(w, h, java.awt.Image.SCALE_FAST)
                SwingUtilities.invokeLater { preview.icon = ImageIcon(shown) }
                if (n++ % 2 == 0) {
                    val found = QrDecode.decode(img)
                    if (found != null) { text = found; break }
                }
                Thread.sleep(30)
            }
            camera.close()
            val closedByUser = done && text == null
            SwingUtilities.invokeLater { dialog.dispose() }
            onResult(if (closedByUser) null else text ?: "")
        }.apply { isDaemon = true }.start()
    }
}
