package dev.cluvex.zedsecure.desktop.platform

import dev.cluvex.zedsecure.platform.DeviceIdentity
import java.io.File
import java.security.MessageDigest

/** The computer's HWID: made once, saved in the app's data folder, and sent with subscription requests. */
object DesktopHwid {
    fun init() {
        val store = DesktopKeyValueStore("device")
        val saved = store.getString("hwid")?.takeIf { it.length >= 16 }
        val hwid = saved ?: run {
            // Derived from the machine id (hashed, never sent as it is), so the same computer gets the same HWID even after
            // a reinstall; a random one is made when the machine has no id.
            val raw = machineId()?.let { "weirdnet:$it" } ?: java.util.UUID.randomUUID().toString()
            MessageDigest.getInstance("SHA-256").digest(raw.toByteArray()).joinToString("") { "%02x".format(it) }.take(32)
        }
        if (saved == null) store.putString("hwid", hwid)
        DeviceIdentity.hwid = hwid
        val os = System.getProperty("os.name").orEmpty()
        DeviceIdentity.osName = when {
            os.startsWith("Windows", true) -> "Windows"
            os.startsWith("Mac", true) -> "macOS"
            else -> "Linux"
        }
        DeviceIdentity.osVersion = System.getProperty("os.version").orEmpty()
        DeviceIdentity.model = runCatching { java.net.InetAddress.getLocalHost().hostName }.getOrDefault("PC")
    }

    private fun machineId(): String? = runCatching {
        val os = System.getProperty("os.name").orEmpty()
        when {
            os.startsWith("Windows", true) -> {
                val out = ProcessBuilder("reg", "query", "HKLM\\SOFTWARE\\Microsoft\\Cryptography", "/v", "MachineGuid")
                    .redirectErrorStream(true).start().inputStream.bufferedReader().readText()
                Regex("""MachineGuid\s+REG_SZ\s+(\S+)""").find(out)?.groupValues?.get(1)
            }
            else -> listOf("/etc/machine-id", "/var/lib/dbus/machine-id").firstNotNullOfOrNull { f ->
                File(f).takeIf { it.isFile }?.readText()?.trim()?.takeIf { it.isNotEmpty() }
            }
        }
    }.getOrNull()
}
