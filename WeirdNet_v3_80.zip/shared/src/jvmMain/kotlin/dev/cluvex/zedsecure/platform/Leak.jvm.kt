package dev.cluvex.zedsecure.platform

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.security.SecureRandom

internal actual suspend fun resolveAddresses(name: String): List<String> = withContext(Dispatchers.IO) {
    runCatching { InetAddress.getAllByName(name).mapNotNull { it.hostAddress } }.getOrDefault(emptyList())
}

internal actual suspend fun stunMappedAddress(): String? = withContext(Dispatchers.IO) {
    runCatching {
        val target = InetAddress.getAllByName("stun.l.google.com").firstOrNull { it is Inet4Address } ?: return@runCatching null
        DatagramSocket().use { socket ->
            socket.soTimeout = 4000
            val id = ByteArray(12).also { SecureRandom().nextBytes(it) }
            val request = ByteArray(20)
            request[0] = 0x00; request[1] = 0x01 // binding request
            request[4] = 0x21; request[5] = 0x12; request[6] = 0xA4.toByte(); request[7] = 0x42 // magic cookie
            id.copyInto(request, 8)
            socket.send(DatagramPacket(request, request.size, target, 19302))
            val buf = ByteArray(512)
            val packet = DatagramPacket(buf, buf.size)
            socket.receive(packet)
            parseStun(buf.copyOf(packet.length), id)
        }
    }.getOrNull()
}

/** The (XOR-)mapped IPv4 address in a STUN binding response for the request [id]. */
internal fun parseStun(data: ByteArray, id: ByteArray): String? {
    if (data.size < 20) return null
    fun u16(i: Int) = ((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)
    if (u16(0) != 0x0101) return null
    if (data[4] != 0x21.toByte() || data[5] != 0x12.toByte() || data[6] != 0xA4.toByte() || data[7] != 0x42.toByte()) return null
    for (i in 0 until 12) if (data[8 + i] != id[i]) return null
    val end = minOf(20 + u16(2), data.size)
    var at = 20
    val cookie = intArrayOf(0x21, 0x12, 0xA4, 0x42)
    while (at + 4 <= end) {
        val type = u16(at)
        val length = u16(at + 2)
        val body = at + 4
        if (body + length > data.size) return null
        // 0x0020 XOR-MAPPED-ADDRESS, 0x0001 MAPPED-ADDRESS; family 0x01 is IPv4
        if ((type == 0x0020 || type == 0x0001) && length >= 8 && data[body + 1].toInt() == 0x01) {
            val xor = type == 0x0020
            return (0 until 4).joinToString(".") { k -> ((data[body + 4 + k].toInt() and 0xFF) xor (if (xor) cookie[k] else 0)).toString() }
        }
        at = body + length + (4 - length % 4) % 4
    }
    return null
}
