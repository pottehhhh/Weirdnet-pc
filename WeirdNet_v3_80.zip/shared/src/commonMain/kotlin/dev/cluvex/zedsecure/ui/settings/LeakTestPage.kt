package dev.cluvex.zedsecure.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.cluvex.zedsecure.data.net.DnsEntryKind
import dev.cluvex.zedsecure.data.net.DnsLeakResult
import dev.cluvex.zedsecure.data.net.DnsVerdict
import dev.cluvex.zedsecure.data.net.LeakEntry
import dev.cluvex.zedsecure.data.net.LeakIp
import dev.cluvex.zedsecure.data.net.LeakTest
import dev.cluvex.zedsecure.domain.model.ConnectionState
import dev.cluvex.zedsecure.shared.resources.*
import dev.cluvex.zedsecure.ui.platform.LocalPlatform
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.stringResource

private enum class Level { Pending, Ok, Warn, Bad, Info }

private val Green = Color(0xFF34C759)
private val Amber = Color(0xFFFF9F0A)
private val Red = Color(0xFFFF453A)

/** Checks what the outside world sees of this device: its address, what a browser's WebRTC would give away, and DNS. */
@Composable
fun LeakTestPage(contentPadding: PaddingValues, modifier: Modifier) {
    val platform = LocalPlatform.current
    val cs = MaterialTheme.colorScheme
    var run by remember { mutableIntStateOf(0) }
    var ip by remember { mutableStateOf<LeakIp?>(null) }
    var ipDone by remember { mutableStateOf(false) }
    var stun by remember { mutableStateOf<String?>(null) }
    var stunDone by remember { mutableStateOf(false) }
    var dns by remember { mutableStateOf<DnsLeakResult?>(null) }
    var dnsDone by remember { mutableStateOf(false) }
    var dnsFailed by remember { mutableStateOf(false) }
    val vpnStatus by dev.cluvex.zedsecure.core.VpnManager.status.collectAsState()
    val connected = vpnStatus.state == ConnectionState.Connected

    LaunchedEffect(run) {
        ip = null; ipDone = false; stun = null; stunDone = false; dns = null; dnsDone = false; dnsFailed = false
        kotlinx.coroutines.coroutineScope {
            launch { ip = runCatching { LeakTest.fetchIp() }.getOrNull(); ipDone = true }
            launch { stun = runCatching { LeakTest.stunAddress() }.getOrNull(); stunDone = true }
            launch {
                runCatching { LeakTest.runDns { dns = it } }.fold(
                    onSuccess = { dns = it },
                    onFailure = { dnsFailed = true },
                )
                dnsDone = true
            }
        }
    }

    // What each part says.
    val exit = ip?.v4
    val ipLevel = when {
        !ipDone -> Level.Pending
        ip == null || (ip?.v4 == null && ip?.v6 == null) -> Level.Warn
        !connected -> Level.Info
        // IPv4 and IPv6 should leave through the same network; another country or provider means IPv6 goes out around the VPN.
        ip?.v6 != null && ip?.v4 != null && ip?.v6Country == null -> Level.Warn
        ip?.v6 != null && ip?.v4 != null &&
            (!ip?.v6Country.equals(ip?.countryCode, ignoreCase = true) || !ip?.v6Isp.equals(ip?.isp, ignoreCase = true)) -> Level.Bad
        else -> Level.Ok
    }
    val stunLevel = when {
        !stunDone -> Level.Pending
        // No answer with no network at all is not "nothing leaks": nothing could be tested.
        stun == null && ip?.v4 == null && ip?.v6 == null -> Level.Warn
        stun == null -> Level.Ok
        !connected -> Level.Info
        exit != null && stun == exit -> Level.Ok
        else -> Level.Bad
    }
    val (dnsVerdict, kinds) = dns?.let { LeakTest.judgeDns(it) } ?: (DnsVerdict.Unknown to emptyMap<LeakEntry, DnsEntryKind>())
    val dnsLevel = when {
        !dnsDone && dns == null -> Level.Pending
        dnsFailed -> Level.Warn
        !connected && dnsVerdict != DnsVerdict.Unknown -> Level.Info
        dnsVerdict == DnsVerdict.Ok -> Level.Ok
        dnsVerdict == DnsVerdict.Possible -> Level.Warn
        dnsVerdict == DnsVerdict.Leak -> Level.Bad
        else -> Level.Warn
    }
    val running = !(ipDone && stunDone && dnsDone)
    val overall = listOf(ipLevel, stunLevel, dnsLevel).let { l ->
        when {
            running -> Level.Pending
            !connected -> Level.Info
            Level.Bad in l -> Level.Bad
            Level.Warn in l -> Level.Warn
            else -> Level.Ok
        }
    }

    GlassPage {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(contentPadding).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // The verdict.
            GlassCard(Modifier.fillMaxWidth(), padding = 18.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusDot(overall, 44)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            stringResource(
                                when (overall) {
                                    Level.Pending -> Res.string.leak_running
                                    Level.Ok -> Res.string.leak_verdict_ok
                                    Level.Warn -> Res.string.leak_verdict_warn
                                    Level.Bad -> Res.string.leak_verdict_bad
                                    Level.Info -> Res.string.leak_verdict_idle
                                },
                            ),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            stringResource(if (connected) Res.string.leak_sub else Res.string.leak_not_connected),
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
                CapsuleButton(
                    text = stringResource(if (running) Res.string.leak_running else Res.string.leak_again),
                    onClick = { run++ },
                    container = cs.primary,
                    content = cs.onPrimary,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !running,
                    height = 48.dp,
                )
            }

            // IP address.
            GlassCard(Modifier.fillMaxWidth(), padding = 16.dp) {
                SectionHead(Res.string.leak_ip_title, ipLevel)
                val v = ip
                if (v != null) {
                    Spacer(Modifier.height(8.dp))
                    v.v4?.let { Line(stringResource(Res.string.leak_ip_v4), it, mono = true) }
                    Line(stringResource(Res.string.leak_ip_v6), v.v6 ?: stringResource(Res.string.leak_ip_none), mono = v.v6 != null)
                    if (ipLevel == Level.Bad) Text(stringResource(Res.string.leak_ip_v6_leak), style = MaterialTheme.typography.bodySmall, color = Red)
                    if (ipLevel == Level.Warn && v.v6 != null) Text(stringResource(Res.string.leak_ip_v6_unknown), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    val place = listOfNotNull(v.country, v.city).joinToString(" · ")
                    if (place.isNotEmpty()) Line(stringResource(Res.string.leak_ip_place), place)
                    v.isp?.let { Line(stringResource(Res.string.leak_ip_isp), it) }
                    v.iranAddress?.takeIf { it != v.v4 }?.let {
                        Line(stringResource(Res.string.leak_ip_iran), it, mono = true)
                        Text(stringResource(Res.string.leak_ip_iran_note), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                } else if (ipDone) {
                    Spacer(Modifier.height(8.dp))
                    Text(stringResource(Res.string.leak_failed), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }

            // WebRTC-style test.
            GlassCard(Modifier.fillMaxWidth(), padding = 16.dp) {
                SectionHead(Res.string.leak_webrtc_title, stunLevel)
                if (stunDone) {
                    Spacer(Modifier.height(8.dp))
                    if (stun != null) Line(stringResource(Res.string.leak_webrtc_seen), stun!!, mono = true)
                    Text(
                        stringResource(
                            when {
                                stun == null && ip?.v4 == null && ip?.v6 == null -> Res.string.leak_failed
                                stun == null -> Res.string.leak_webrtc_none
                                !connected -> Res.string.leak_webrtc_idle
                                stunLevel == Level.Ok -> Res.string.leak_webrtc_same
                                else -> Res.string.leak_webrtc_leak
                            },
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = if (stunLevel == Level.Bad) Red else cs.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(10.dp))
                    CapsuleButton(
                        text = stringResource(Res.string.leak_webrtc_browser),
                        onClick = { platform.openUri("https://browserleaks.com/webrtc") },
                        container = cs.primary.copy(alpha = 0.14f),
                        content = cs.primary,
                        modifier = Modifier.fillMaxWidth(),
                        height = 44.dp,
                    )
                }
            }

            // DNS.
            GlassCard(Modifier.fillMaxWidth(), padding = 16.dp) {
                SectionHead(Res.string.leak_dns_title, dnsLevel)
                val r = dns
                Spacer(Modifier.height(8.dp))
                if (r != null) {
                    Text(stringResource(Res.string.leak_dns_servers, r.resolvers.size), style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                    r.resolvers.forEach { e ->
                        val kind = kinds[e] ?: DnsEntryKind.Safe
                        val c = when (kind) { DnsEntryKind.Safe -> Green; DnsEntryKind.PublicDns -> Amber; DnsEntryKind.Leak -> Red }
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            StatusDot(if (kind == DnsEntryKind.Safe) Level.Ok else if (kind == DnsEntryKind.PublicDns) Level.Warn else Level.Bad, 12)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(e.ip, style = MaterialTheme.typography.bodyMedium, fontFamily = FontFamily.Monospace)
                                Text(
                                    listOf(e.country, e.org).filter { it.isNotBlank() }.joinToString(" · "),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = cs.onSurfaceVariant,
                                )
                            }
                            GlassBadge(
                                stringResource(
                                    when (kind) {
                                        DnsEntryKind.Safe -> Res.string.leak_kind_safe
                                        DnsEntryKind.PublicDns -> Res.string.leak_kind_public
                                        DnsEntryKind.Leak -> Res.string.leak_kind_leak
                                    },
                                ),
                                c,
                            )
                        }
                    }
                    if (r.resolvers.isEmpty() && dnsDone) {
                        Text(stringResource(Res.string.leak_dns_none), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                    if (dnsDone && dnsVerdict != DnsVerdict.Unknown) {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            stringResource(
                                when (dnsVerdict) {
                                    DnsVerdict.Ok -> Res.string.leak_dns_ok
                                    DnsVerdict.Possible -> Res.string.leak_dns_possible
                                    else -> Res.string.leak_dns_leak
                                },
                            ),
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                        )
                    }
                } else if (dnsFailed) {
                    Text(stringResource(Res.string.leak_failed), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }

            Text(
                stringResource(Res.string.leak_note),
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 8.dp),
            )
        }
    }
}

@Composable
private fun SectionHead(title: org.jetbrains.compose.resources.StringResource, level: Level) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(stringResource(title), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        StatusDot(level, 14)
    }
}

@Composable
private fun StatusDot(level: Level, size: Int) {
    val color = when (level) {
        Level.Ok -> Green
        Level.Warn -> Amber
        Level.Bad -> Red
        else -> MaterialTheme.colorScheme.outline
    }
    if (level == Level.Pending) {
        CircularProgressIndicator(Modifier.width(size.dp).height(size.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.primary)
    } else {
        androidx.compose.foundation.layout.Box(
            Modifier.width(size.dp).height(size.dp)
                .background(color.copy(alpha = 0.22f), androidx.compose.foundation.shape.CircleShape)
                .padding((size / 4).dp)
                .background(color, androidx.compose.foundation.shape.CircleShape),
        )
    }
}

@Composable
private fun Line(label: String, value: String, mono: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.Top) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(96.dp))
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            fontFamily = if (mono) FontFamily.Monospace else null,
            modifier = Modifier.weight(1f),
        )
    }
}
