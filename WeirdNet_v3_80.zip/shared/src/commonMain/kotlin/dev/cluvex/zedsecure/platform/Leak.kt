package dev.cluvex.zedsecure.platform

/** The addresses the device's own resolver gives for [name] (empty when it cannot be resolved). */
internal expect suspend fun resolveAddresses(name: String): List<String>

/**
 * Asks a STUN server which public address it sees for a UDP packet from this device: the same question a
 * browser asks for WebRTC. Null when there is no answer (STUN blocked, or no UDP route).
 */
internal expect suspend fun stunMappedAddress(): String?
