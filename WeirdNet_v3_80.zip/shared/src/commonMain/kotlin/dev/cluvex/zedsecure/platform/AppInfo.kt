package dev.cluvex.zedsecure.platform

import kotlin.concurrent.Volatile
import kotlin.random.Random

object AppInfo {
    @Volatile
    var versionName: String = "3.0.9"

    val userAgent: String get() = "WEIRDNET/$versionName"
}

object DeviceIdentity {
    @Volatile
    var id: String = ""

    /** The device's HWID: stable, saved on the device, and sent with every subscription request. Set at start-up by each platform. */
    @Volatile
    var hwid: String = ""

    @Volatile
    var osName: String = ""

    @Volatile
    var osVersion: String = ""

    @Volatile
    var model: String = ""
}

/** The headers that tell a subscription panel which device is asking (the HWID limit of the panel counts these). */
object Hwid {
    private fun ascii(v: String) = v.filter { it.code in 32..126 }.trim()

    fun headers(): Map<String, String> {
        val id = ascii(DeviceIdentity.hwid)
        if (id.isEmpty()) return emptyMap()
        return buildMap {
            put("x-hwid", id)
            ascii(DeviceIdentity.osName).takeIf { it.isNotEmpty() }?.let { put("x-device-os", it) }
            ascii(DeviceIdentity.osVersion).takeIf { it.isNotEmpty() }?.let { put("x-ver-os", it) }
            ascii(DeviceIdentity.model).takeIf { it.isNotEmpty() }?.let { put("x-device-model", it) }
        }
    }
}

internal fun newId(): String = buildString {
    val hex = "0123456789abcdef"
    repeat(32) { append(hex[Random.nextInt(16)]) }
}
