package dev.cluvex.zedsecure.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.cluvex.zedsecure.data.account.AccountRepository
import dev.cluvex.zedsecure.shared.resources.*
import dev.cluvex.zedsecure.ui.platform.LocalPlatform
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.getString
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

/** "My account": the wallet and the doors to everything else (services, history, invites, support). */
@Composable
internal fun AccountPage(
    account: AccountRepository,
    contentPadding: PaddingValues,
    modifier: Modifier,
    onOpen: (SettingsPage) -> Unit,
) {
    val loggedIn by account.loggedIn.collectAsState()
    SettingsPageScaffold(
        title = stringResource(Res.string.account_title),
        art = SettingsArts.Account,
        subtitle = stringResource(Res.string.account_subtitle),
        contentPadding = contentPadding,
        modifier = modifier,
    ) {
        if (!loggedIn) LoginSection(account) else GlassPage { ConnectedAccount(account, onOpen) }
    }
}

@Composable
private fun ConnectedAccount(account: AccountRepository, onOpen: (SettingsPage) -> Unit) {
    val platform = LocalPlatform.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val balance by account.balanceFlow.collectAsState()
    val offline by account.offline.collectAsState()
    val services by account.servicesFlow.collectAsState()
    val syncing by account.syncing.collectAsState()
    val lastSync by account.lastSync.collectAsState()
    var reload by remember { mutableStateOf(0) }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }
    var topUp by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf<String?>(null) }

    // While the server cannot be reached, keep asking until it answers.
    LaunchedEffect(offline) {
        while (offline) {
            delay(3_000)
            reload++
        }
    }

    // While this page is open the bot is asked every few seconds, so a purchase, a deleted service or a
    // top-up made in the bot shows up here (and in the server list) without touching anything.
    LaunchedEffect(Unit) {
        while (true) {
            delay(20_000)
            account.refresh()
        }
    }

    LaunchedEffect(Unit) { account.hello(dev.cluvex.zedsecure.platform.AppInfo.versionName, "") }

    LaunchedEffect(reload) {
        loading = true
        val b = account.balance()
        val sv = account.services()
        sv.onSuccess { list ->
            // Services new on the account are added to the app, deleted ones are taken out.
            if (account.syncServices(list).changed) message = getString(Res.string.account_added_auto)
        }
        val failure = listOf(b, sv).firstOrNull { it.isFailure }?.exceptionOrNull()
        if (failure != null) message = errorText(failure)
        loading = false
    }

    val activeCount = services.count { isServiceActive(it) }

    Column(
        Modifier.padding(top = 14.dp, bottom = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        if (offline) GlassNotice(stringResource(Res.string.account_offline), Modifier.padding(horizontal = 16.dp), tone = Color(0xFFFFB84D))
        message?.let { m -> GlassNotice(m, Modifier.padding(horizontal = 16.dp), onClick = { message = null }) }

        AccountSwitcherCard(account, onChanged = { reload++ }, modifier = Modifier.padding(horizontal = 16.dp))

        AttentionNotice(services, Modifier.padding(horizontal = 16.dp)) { onOpen(SettingsPage.Services) }

        WalletHero(
            balance = balance,
            loading = loading,
            lastSync = lastSync,
            syncing = syncing || loading,
            offline = offline,
            onTopUp = { topUp = true },
            onBuy = { onOpen(SettingsPage.Buy) },
            modifier = Modifier.padding(horizontal = 16.dp),
        )

        // The services live on their own page, like support.
        GlassCard(
            Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
            padding = 16.dp,
            onClick = { onOpen(SettingsPage.Services) },
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                GlassIcon(Res.drawable.ic_inventory, planAccent(0), box = 48.dp, glyph = 26.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        stringResource(Res.string.svc_page_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        stringResource(Res.string.svc_hub_sub),
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                }
                if (services.isNotEmpty()) {
                    GlassBadge(
                        stringResource(Res.string.svc_count, services.size),
                        if (activeCount > 0) planAccent(0) else cs.onSurfaceVariant,
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Icon(
                    painterResource(Res.drawable.ic_chevron_right),
                    contentDescription = null,
                    tint = cs.onSurfaceVariant,
                    modifier = Modifier.size(22.dp),
                )
            }
        }

        GlassCard(
            Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
            padding = 16.dp,
            onClick = { onOpen(SettingsPage.Earn) },
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                GlassIcon(Res.drawable.ic_send, Color(0xFF3DD6A3), box = 48.dp, glyph = 26.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        stringResource(Res.string.earn_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        stringResource(Res.string.earn_tile_sub),
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                }
                Icon(
                    painterResource(Res.drawable.ic_chevron_right),
                    contentDescription = null,
                    tint = cs.onSurfaceVariant,
                    modifier = Modifier.size(22.dp),
                )
            }
        }

        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                GlassTile(Res.drawable.ic_schedule, stringResource(Res.string.account_tile_wallet), Modifier.weight(1f), accent = Color(0xFF4D9DFF)) {
                    onOpen(SettingsPage.Wallet)
                }
                GlassTile(Res.drawable.ic_person, stringResource(Res.string.account_tile_profile), Modifier.weight(1f), accent = Color(0xFFB197FC)) {
                    onOpen(SettingsPage.Profile)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                GlassTile(Res.drawable.ic_headset, stringResource(Res.string.account_tile_support), Modifier.weight(1f), accent = Color(0xFFFF8A65)) {
                    onOpen(SettingsPage.SupportChat)
                }
                GlassTile(Res.drawable.ic_fill_sync, stringResource(Res.string.account_sync_now), Modifier.weight(1f), accent = Color(0xFF3DD6A3)) {
                    scope.launch {
                        val rep = account.sync()
                        if (rep.changed) message = getString(Res.string.account_added_auto)
                        reload++
                    }
                }
            }
        }

        SyncCenterCard(
            account = account,
            onSync = {
                scope.launch {
                    val rep = account.sync()
                    if (rep.changed) message = getString(Res.string.account_added_auto)
                    reload++
                }
            },
            modifier = Modifier.padding(horizontal = 16.dp),
        )

        TrialCarousel(account = account, reload = reload, onDone = { reload++ })

        GlassCard(Modifier.padding(horizontal = 16.dp).fillMaxWidth(), padding = 14.dp) {
            CapsuleButton(
                text = stringResource(Res.string.account_check),
                onClick = { scope.launch { report = buildReport(account) } },
                container = cs.primary.copy(alpha = 0.14f),
                content = cs.primary,
                modifier = Modifier.fillMaxWidth(),
                height = 48.dp,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                stringResource(Res.string.account_check_sub),
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            )
            Spacer(Modifier.height(8.dp))
            LoginQrButton(account)
            Spacer(Modifier.height(8.dp))
            CapsuleButton(
                text = stringResource(Res.string.account_logout),
                onClick = { scope.launch { account.logout() } },
                container = cs.error.copy(alpha = 0.14f),
                content = cs.error,
                modifier = Modifier.fillMaxWidth(),
                height = 48.dp,
            )
        }

        report?.let { text ->
            GlassCard(Modifier.padding(horizontal = 16.dp).fillMaxWidth(), padding = 16.dp) {
                SelectionContainer {
                    Text(text, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                }
                Spacer(Modifier.height(12.dp))
                CapsuleButton(
                    text = stringResource(Res.string.account_copy_report),
                    onClick = {
                        platform.copyToClipboard(text)
                        scope.launch { platform.toast(getString(Res.string.account_report_copied)) }
                    },
                    container = cs.primary,
                    content = cs.onPrimary,
                    modifier = Modifier.fillMaxWidth(),
                    height = 46.dp,
                )
            }
        }
    }

    if (topUp) TopUpDialog(account) { topUp = false; reload++ }
}

/** Raw answers of the read-only actions, with subscription tokens hidden, for support. */
private suspend fun buildReport(account: AccountRepository): String = buildString {
    for (action in listOf("plans", "balance", "services", "custom", "panels", "profile", "tickets")) {
        append("== ").append(action).append('\n')
        val result = account.call(action)
        append(
            result.fold(
                onSuccess = { hideTokens(it.toString()) },
                onFailure = { "error: ${it.message ?: it::class.simpleName}" },
            ),
        )
        append("\n\n")
    }
    // The newest ticket as the bot sends it, to see where its replies are.
    val first = account.call("tickets").getOrNull()?.let { o ->
        (o["items"] as? kotlinx.serialization.json.JsonArray)?.firstOrNull() as? kotlinx.serialization.json.JsonObject
    }
    val id = (first?.get("id") as? kotlinx.serialization.json.JsonPrimitive)?.content
    if (id != null) {
        append("== ticket ").append(id).append('\n')
        append(account.call("tickets", mapOf("ticket_id" to id)).fold(onSuccess = { hideTokens(it.toString()) }, onFailure = { "error: ${it.message}" }))
        append("\n\n")
    }
}

private fun hideTokens(json: String): String =
    Regex("""(https?://[^/"\s]+/)[^"\s]+""").replace(json) { it.groupValues[1] + "xxx" }
