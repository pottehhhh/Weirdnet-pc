package dev.cluvex.zedsecure.ui.settings

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * A rotary volume selector. Turning it with a finger moves the value from [min] to [max] over one full
 * turn; the thumb follows the finger. The number in the middle is the selected volume. Exact values come
 * from the buttons and quick picks that sit under it, so the dial only has to be pleasant, not precise.
 */
@Composable
private fun VolumeDialBody(
    value: Int,
    min: Int,
    max: Int,
    accent: Color,
    unit: String,
    onChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val span = (max - min).coerceAtLeast(1)
    val haptics = LocalHapticFeedback.current
    val currentValue by rememberUpdatedState(value)
    val currentOnChange by rememberUpdatedState(onChange)
    var raw by remember(min, max) { mutableFloatStateOf(value.toFloat()) }
    var dragging by remember { mutableStateOf(false) }

    // The value can also change from outside (quick picks, +/- buttons): follow it.
    LaunchedEffect(value) {
        if (raw.roundToInt() != value) raw = value.toFloat()
    }

    val fraction by animateFloatAsState(
        targetValue = ((value - min).toFloat() / span).coerceIn(0f, 1f),
        animationSpec = tween(if (dragging) 60 else 220),
        label = "dial-fraction",
    )

    val track = MaterialTheme.colorScheme.surfaceContainerHighest
    val tick = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
    val thumbOuter = MaterialTheme.colorScheme.onSurface

    Box(
        modifier
            .widthIn(max = 300.dp)
            .fillMaxWidth(0.8f)
            .aspectRatio(1f)
            .pointerInput(min, max) {
                val twoPi = (2 * PI).toFloat()
                detectDragGestures(
                    onDragStart = { dragging = true },
                    onDragEnd = { dragging = false },
                    onDragCancel = { dragging = false },
                ) { change, _ ->
                    change.consume()
                    val c = Offset(size.width / 2f, size.height / 2f)
                    val now = atan2(change.position.y - c.y, change.position.x - c.x)
                    val before = atan2(change.previousPosition.y - c.y, change.previousPosition.x - c.x)
                    var d = now - before
                    if (d > PI.toFloat()) d -= twoPi
                    if (d < -PI.toFloat()) d += twoPi
                    raw = (raw + d / twoPi * span).coerceIn(min.toFloat(), max.toFloat())
                    val v = raw.roundToInt()
                    if (v != currentValue) {
                        currentOnChange(v)
                        if (v % 5 == 0) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 16.dp.toPx()
            val diameter = size.minDimension - stroke - 12.dp.toPx()
            val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
            val arcSize = Size(diameter, diameter)
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = diameter / 2f

            drawArc(track, 0f, 360f, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))

            // Fine tick ring inside the track; the ticks up to the thumb take the accent colour.
            val tickOuter = radius - stroke / 2f - 8.dp.toPx()
            repeat(60) { i ->
                val a = (i * 6f - 90f) * (PI / 180.0).toFloat()
                val long = i % 5 == 0
                val inner = tickOuter - if (long) 9.dp.toPx() else 4.dp.toPx()
                val lit = (i / 60f) <= fraction && fraction > 0f
                drawLine(
                    color = if (lit) accent else tick,
                    start = Offset(center.x + cos(a) * tickOuter, center.y + sin(a) * tickOuter),
                    end = Offset(center.x + cos(a) * inner, center.y + sin(a) * inner),
                    strokeWidth = if (long) 2.dp.toPx() else 1.dp.toPx(),
                    cap = StrokeCap.Round,
                )
            }

            val sweep = 360f * fraction
            if (sweep > 0.5f) {
                drawArc(accent, -90f, sweep, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            }

            val ang = (-90f + sweep) * (PI / 180.0).toFloat()
            val thumb = Offset(center.x + cos(ang) * radius, center.y + sin(ang) * radius)
            drawCircle(Color.Black.copy(alpha = 0.25f), radius = stroke * 0.95f, center = thumb + Offset(0f, 2.dp.toPx()))
            drawCircle(thumbOuter, radius = stroke * 0.9f, center = thumb)
            drawCircle(accent, radius = stroke * 0.5f, center = thumb)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                value.toString(),
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
                unit,
                style = MaterialTheme.typography.titleMedium,
                color = accent,
                fontWeight = FontWeight.SemiBold,
            )
        }
    }
}

/** The round volume dial, never wider than a phone-sized dial however wide the window is, and centred. */
@Composable
internal fun VolumeDial(
    value: Int,
    min: Int,
    max: Int,
    accent: Color,
    unit: String,
    onChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        VolumeDialBody(value, min, max, accent, unit, onChange, modifier)
    }
}
