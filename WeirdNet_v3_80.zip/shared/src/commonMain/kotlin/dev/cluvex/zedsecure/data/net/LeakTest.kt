package dev.cluvex.zedsecure.data.net

// The leak test follows the approach of the Kumo client (https://github.com/AbolDev/kumo-client, GPL-3.0):
// the DNS test asks bash.ws which resolvers came to it, the WebRTC-style test asks a STUN server which address it
// sees, and the verdict rules for the resolvers are the same. Ported to Kotlin for WEIRDNET.

import dev.cluvex.zedsecure.platform.httpGetText
import dev.cluvex.zedsecure.platform.resolveAddresses
import dev.cluvex.zedsecure.platform.stunMappedAddress
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlin.random.Random

/** What the public services see of this connection. */
data class LeakIp(
    val v4: String? = null,
    val v6: String? = null,
    val country: String? = null,
    val countryCode: String? = null,
    val city: String? = null,
    val isp: String? = null,
    /** Where the IPv6 address is (null when it has none, or the lookup failed). */
    val v6Country: String? = null,
    val v6Isp: String? = null,
    /** What an Iranian service sees: the user's own address when Iranian sites are reached directly. */
    val iranAddress: String? = null,
)

/** One resolver (or the address itself) that the DNS test saw. */
data class LeakEntry(val ip: String, val country: String, val org: String, val asn: String = "")

data class DnsLeakResult(val address: LeakEntry?, val resolvers: List<LeakEntry>)

enum class DnsVerdict { Ok, Possible, Leak, Unknown }

/** [Safe]: the VPN's own network or country. [PublicDns]: a big public resolver from another country. [Leak]: anything else. */
enum class DnsEntryKind { Safe, PublicDns, Leak }

object LeakTest {
    private const val UA = "WEIRDNET"
    private val json = Json { ignoreUnknownKeys = true }

    private suspend fun get(url: String, readMs: Int = 10_000): String =
        withContext(Dispatchers.Default) { httpGetText(url, UA, 8_000, readMs) }

    private suspend fun firstOf(urls: List<String>, accept: (String) -> Boolean): String? {
        for (u in urls) {
            val s = runCatching { get(u, 8_000).trim() }.getOrNull()
            if (s != null && accept(s)) return s
        }
        return null
    }

    private fun isV4(s: String) = Regex("""^\d{1,3}(\.\d{1,3}){3}$""").matches(s)
    private fun isV6(s: String) = ':' in s && Regex("""^[0-9a-fA-F:.]+$""").matches(s)

    /** The addresses and place the world's services see for this connection. */
    suspend fun fetchIp(): LeakIp = coroutineScope {
        val v4 = async { firstOf(listOf("https://api.ipify.org", "https://ipv4.icanhazip.com")) { isV4(it) } }
        val v6 = async { firstOf(listOf("https://api6.ipify.org", "https://ipv6.icanhazip.com")) { isV6(it) } }
        val iran = async {
            runCatching {
                val o = json.parseToJsonElement(get("https://api.ipmyp.ir/json", 8_000)).jsonObject
                if (o["status"]?.jsonPrimitive?.contentOrNull == "success" && o["countryCode"]?.jsonPrimitive?.contentOrNull.equals("IR", true)) {
                    o["query"]?.jsonPrimitive?.contentOrNull
                } else null
            }.getOrNull()
        }
        val a4 = v4.await()
        val a6 = v6.await()
        var country: String? = null
        var code: String? = null
        var city: String? = null
        var isp: String? = null
        (a4 ?: a6)?.let { addr ->
            runCatching {
                val o = json.parseToJsonElement(get("https://ipwho.is/$addr")).jsonObject
                if (o["success"]?.jsonPrimitive?.contentOrNull != "false") {
                    country = o["country"]?.jsonPrimitive?.contentOrNull
                    code = o["country_code"]?.jsonPrimitive?.contentOrNull
                    city = o["city"]?.jsonPrimitive?.contentOrNull
                    val c = o["connection"] as? JsonObject
                    isp = c?.get("isp")?.jsonPrimitive?.contentOrNull ?: c?.get("org")?.jsonPrimitive?.contentOrNull
                }
            }
        }
        var v6Country: String? = null
        var v6Isp: String? = null
        if (a6 != null && a4 != null) runCatching {
            val o = json.parseToJsonElement(get("https://ipwho.is/$a6")).jsonObject
            if (o["success"]?.jsonPrimitive?.contentOrNull != "false") {
                v6Country = o["country_code"]?.jsonPrimitive?.contentOrNull
                val c = o["connection"] as? JsonObject
                v6Isp = c?.get("isp")?.jsonPrimitive?.contentOrNull ?: c?.get("org")?.jsonPrimitive?.contentOrNull
            }
        }
        LeakIp(a4, a6, country, code, city, isp, v6Country, v6Isp, iran.await())
    }

    /**
     * The address a STUN request from this device exposes; null when there is no answer. This is the address a browser's
     * WebRTC would also find, but it is not a test of the browser itself.
     */
    suspend fun stunAddress(): String? = stunMappedAddress()

    /**
     * The DNS test: names of a test domain that only bash.ws answers are looked up with the device's own resolver, then
     * bash.ws says which resolvers asked. [onResult] gets the servers as they are found.
     */
    suspend fun runDns(onResult: (DnsLeakResult) -> Unit): DnsLeakResult = coroutineScope {
        val id = get("https://bash.ws/id").trim()
        require(id.isNotEmpty() && id.length <= 64) { "bad id" }
        suspend fun wave() = coroutineScope {
            (1..10).map { i -> async { resolveAddresses("${i + Random.nextInt(100000) * 10}.$id.bash.ws") } }.awaitAll()
        }
        val akamai = async { resolveAddresses("whoami.akamai.net") }
        var wavesDone = false
        launch { wave(); delay(600); wave(); wavesDone = true }

        var last: DnsLeakResult? = null
        var same = 0
        for (reads in 1..20) {
            delay(700)
            val now = runCatching { parseDns(get("https://bash.ws/dnsleak/test/$id?json")) }.getOrNull()
            if (now == null) {
                if (wavesDone && last != null && reads >= 6) break
                continue
            }
            val grew = last == null || now.resolvers.map { it.ip }.toSet().size != last.resolvers.map { it.ip }.toSet().size
            if (grew && now.resolvers.isNotEmpty()) onResult(now)
            same = if (!grew && now.resolvers.isNotEmpty()) same + 1 else 0
            last = now
            if (wavesDone && same >= 1) break
        }
        val found = last ?: throw IllegalStateException("no answer")
        // The second view: the resolver Akamai saw.
        val resolvers = found.resolvers.toMutableList()
        runCatching {
            for (ip in akamai.await()) {
                if (!isV4(ip) || resolvers.any { it.ip == ip }) continue
                val o = json.parseToJsonElement(get("https://ipwho.is/$ip")).jsonObject
                if (o["success"]?.jsonPrimitive?.contentOrNull == "false") continue
                val c = o["connection"] as? JsonObject
                resolvers += LeakEntry(
                    ip,
                    o["country"]?.jsonPrimitive?.contentOrNull.orEmpty(),
                    (c?.get("org") ?: c?.get("isp"))?.jsonPrimitive?.contentOrNull.orEmpty(),
                    c?.get("asn")?.jsonPrimitive?.contentOrNull?.let { "AS$it" }.orEmpty(),
                )
            }
        }
        DnsLeakResult(found.address, resolvers).also(onResult)
    }

    internal fun parseDns(body: String): DnsLeakResult {
        val list = json.parseToJsonElement(body) as? JsonArray ?: throw IllegalArgumentException("bad answer")
        var address: LeakEntry? = null
        val resolvers = mutableListOf<LeakEntry>()
        for (e in list) {
            val o = e as? JsonObject ?: continue
            fun s(k: String) = o[k]?.jsonPrimitive?.contentOrNull.orEmpty()
            val asn = Regex("""AS\d+""").find(s("asn"))?.value.orEmpty()
            val entry = LeakEntry(s("ip"), s("country_name"), s("org"), asn)
            when (s("type")) {
                "ip" -> address = entry
                "dns" -> resolvers += entry
            }
        }
        return DnsLeakResult(address, resolvers)
    }

    private val publicDns = listOf(
        "google", "cloudflare", "quad9", "opendns", "cisco", "adguard", "nextdns", "cleanbrowsing",
        "controld", "verisign", "level 3", "akamai", "yandex",
    )

    private fun isPublicDns(e: LeakEntry): Boolean {
        val s = "${e.org} ${e.asn}".lowercase()
        return publicDns.any { it in s }
    }

    /** Decides whether the resolvers that answered show a leak. The address the test saw is the VPN's. */
    fun judgeDns(r: DnsLeakResult): Pair<DnsVerdict, Map<LeakEntry, DnsEntryKind>> {
        val home = r.address
        if (home == null || home.country.isEmpty() || r.resolvers.isEmpty()) return DnsVerdict.Unknown to emptyMap()
        fun sameNetwork(e: LeakEntry) =
            e.ip == home.ip || (e.asn.isNotEmpty() && e.asn == home.asn) ||
                (e.org.isNotEmpty() && e.org.equals(home.org, ignoreCase = true))
        val kinds = r.resolvers.associateWith { e ->
            when {
                sameNetwork(e) || e.country.isEmpty() || e.country == home.country -> DnsEntryKind.Safe
                isPublicDns(e) -> DnsEntryKind.PublicDns
                else -> DnsEntryKind.Leak
            }
        }
        val verdict = when {
            DnsEntryKind.Leak in kinds.values -> DnsVerdict.Leak
            DnsEntryKind.PublicDns in kinds.values -> DnsVerdict.Possible
            else -> DnsVerdict.Ok
        }
        return verdict to kinds
    }
}
