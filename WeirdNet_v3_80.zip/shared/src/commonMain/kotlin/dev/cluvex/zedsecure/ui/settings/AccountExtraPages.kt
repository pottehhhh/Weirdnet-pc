package dev.cluvex.zedsecure.ui.settings

import androidx.compose.foundation.background
import org.jetbrains.compose.resources.painterResource
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import dev.cluvex.zedsecure.data.account.AccountRepository
import dev.cluvex.zedsecure.platform.currentTimeMillis
import dev.cluvex.zedsecure.shared.resources.*
import dev.cluvex.zedsecure.ui.platform.LocalPlatform
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.StringResource
import org.jetbrains.compose.resources.getString
import org.jetbrains.compose.resources.stringResource

private const val HISTORY_PAGE = 30

private val IncomeColor = Color(0xFF3DD6A3)
private val SpendColor = Color(0xFFFF8A65)
private val WaitColor = Color(0xFFFFB84D)
private val FailColor = Color(0xFFFF6B6B)

// ---- dates ----

/** Epoch seconds to [year, month, day, hour, minute] (UTC, Gregorian). */
private fun civil(sec: Long): IntArray {
    val days = sec.floorDiv(86_400L)
    val rem = sec.mod(86_400L)
    val z = days + 719_468L
    val era = z.floorDiv(146_097L)
    val doe = z - era * 146_097L
    val yoe = (doe - doe / 1_460 + doe / 36_524 - doe / 146_096) / 365
    val doy = doe - (365 * yoe + yoe / 4 - yoe / 100)
    val mp = (5 * doy + 2) / 153
    val d = doy - (153 * mp + 2) / 5 + 1
    val m = if (mp < 10) mp + 3 else mp - 9
    val y = yoe + era * 400 + (if (m <= 2) 1 else 0)
    return intArrayOf(y.toInt(), m.toInt(), d.toInt(), (rem / 3600).toInt(), (rem % 3600 / 60).toInt())
}

/** Gregorian date to the Persian (Jalali) calendar: [year, month, day]. */
private fun toJalali(gy: Int, gm: Int, gd: Int): IntArray {
    val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
    val gy2 = if (gm > 2) gy + 1 else gy
    var days = 355666 + 365 * gy + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 + gd + gdm[gm - 1]
    var jy = -1595 + 33 * (days / 12053)
    days %= 12053
    jy += 4 * (days / 1461)
    days %= 1461
    if (days > 365) {
        jy += (days - 1) / 365
        days = (days - 1) % 365
    }
    val jm: Int
    val jd: Int
    if (days < 186) {
        jm = 1 + days / 31
        jd = 1 + days % 31
    } else {
        jm = 7 + (days - 186) / 30
        jd = 1 + (days - 186) % 30
    }
    return intArrayOf(jy, jm, jd)
}

private fun two(n: Int) = n.toString().padStart(2, '0')

/** "1405/08/17" for Persian, "2026-11-08" otherwise. */
internal fun dayText(sec: Long, jalali: Boolean): String {
    if (sec <= 0) return ""
    val c = civil(sec)
    return if (jalali) {
        val j = toJalali(c[0], c[1], c[2])
        "${j[0]}/${two(j[1])}/${two(j[2])}"
    } else {
        "${c[0]}-${two(c[1])}-${two(c[2])}"
    }
}

internal fun timeText(sec: Long): String {
    if (sec <= 0) return ""
    val c = civil(sec)
    return "${two(c[3])}:${two(c[4])}"
}

// ---- what a line of the history means ----

private class Look(val income: Boolean, val label: StringResource)

/** The bot names kinds in its own way, so the line is understood by its kind, its note and its sign. */
private fun look(e: AccountRepository.WalletEntry): Look {
    val text = ((e.kind ?: "") + " " + (e.note ?: "")).lowercase()
    fun has(vararg words: String) = words.any { it in text }
    val amount = e.amount ?: 0L
    val base = when {
        has("refund", "بازگشت") -> Look(true, Res.string.wallet_kind_refund)
        has("reward", "referral", "invite", "پاداش", "دعوت") -> Look(true, Res.string.wallet_kind_reward)
        has("gift", "bonus", "هدیه") -> Look(true, Res.string.wallet_kind_gift)
        has("renew", "تمدید") -> Look(false, Res.string.wallet_kind_renew)
        has("buy", "purchase", "service", "plan", "خرید", "سرویس") -> Look(false, Res.string.wallet_kind_buy)
        has("charge", "topup", "top_up", "top-up", "deposit", "pay", "شارژ", "واریز") -> Look(true, Res.string.wallet_kind_topup)
        has("admin", "manual", "support") -> Look(amount >= 0, Res.string.wallet_kind_admin)
        amount < 0 -> Look(false, Res.string.wallet_kind_out)
        else -> Look(true, Res.string.wallet_kind_in)
    }
    // A minus sign always means money left the wallet.
    return if (amount < 0 && base.income) Look(false, Res.string.wallet_kind_out) else base
}

internal class StatusLook(val label: StringResource, val color: Color)

internal fun statusLook(raw: String?): StatusLook? {
    val s = raw?.trim()?.lowercase() ?: return null
    fun has(vararg words: String) = words.any { it in s }
    return when {
        has("paid", "success", "done", "complete", "approved", "finish", "ok", "موفق") -> StatusLook(Res.string.wallet_status_ok, IncomeColor)
        has("wait", "pend", "unpaid", "process", "انتظار") -> StatusLook(Res.string.wallet_status_wait, WaitColor)
        has("fail", "cancel", "expire", "reject", "error", "refus", "ناموفق", "منقضی") -> StatusLook(Res.string.wallet_status_fail, FailColor)
        else -> null
    }
}

private fun amountOf(e: AccountRepository.WalletEntry): Long = kotlin.math.abs(e.amount ?: 0L)

/** Wallet transactions and payments, newest first, grouped by day. */
@Composable
internal fun WalletHistoryPage(account: AccountRepository, contentPadding: PaddingValues, modifier: Modifier) {
    val loggedIn by account.loggedIn.collectAsState()
    SettingsPageScaffold(
        title = stringResource(Res.string.account_wallet_history),
        art = SettingsArts.Account,
        subtitle = stringResource(Res.string.account_wallet_history_sub),
        contentPadding = contentPadding,
        modifier = modifier,
    ) {
        if (!loggedIn) LoginSection(account) else GlassPage { WalletHistoryContent(account) }
    }
}

@Composable
private fun WalletHistoryContent(account: AccountRepository) {
    var tab by remember { mutableStateOf(0) }
    var filter by remember { mutableStateOf(0) }
    var items by remember { mutableStateOf<List<AccountRepository.WalletEntry>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var more by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val balance by account.balanceFlow.collectAsState()
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val jalali = stringResource(Res.string.wallet_use_jalali) == "true"

    suspend fun load(offset: Int) {
        loading = true
        val r = if (tab == 0) account.transactions(HISTORY_PAGE, offset) else account.payments(HISTORY_PAGE, offset)
        r.fold(
            onSuccess = { list ->
                items = if (offset == 0) list else items + list
                more = list.size >= HISTORY_PAGE
                error = null
            },
            onFailure = { error = errorText(it) },
        )
        loading = false
    }

    LaunchedEffect(tab) {
        items = emptyList()
        more = false
        filter = 0
        load(0)
    }
    LaunchedEffect(Unit) { account.balance() }

    val shown = when {
        tab == 0 && filter == 1 -> items.filter { look(it).income }
        tab == 0 && filter == 2 -> items.filter { !look(it).income }
        else -> items
    }
    val moneyIn = items.filter { look(it).income && statusLook(it.status)?.color != FailColor && statusLook(it.status)?.color != WaitColor }.sumOf { amountOf(it) }
    val moneyOut = items.filter { !look(it).income }.sumOf { amountOf(it) }
    val today = currentTimeMillis() / 1000 / 86_400
    val tomanWord = stringResource(Res.string.account_toman)

    Column(Modifier.padding(top = 14.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // The balance and what went in and out of what is listed below.
        GlassCard(Modifier.padding(horizontal = 16.dp).fillMaxWidth(), padding = 18.dp) {
            Text(stringResource(Res.string.wallet_net), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
            Text(
                balance?.let { toman(it) + " " + tomanWord } ?: "—",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
            )
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MoneyPill(stringResource(Res.string.wallet_in), moneyIn, IncomeColor, Res.drawable.ic_arrow_downward, Modifier.weight(1f))
                MoneyPill(stringResource(Res.string.wallet_out), moneyOut, SpendColor, Res.drawable.ic_arrow_upward, Modifier.weight(1f))
            }
        }

        GlassSegmented(
            options = listOf(stringResource(Res.string.account_transactions), stringResource(Res.string.account_payments)),
            selected = tab,
            onSelect = { tab = it },
            modifier = Modifier.padding(horizontal = 16.dp),
        )

        if (tab == 0) {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassChip(stringResource(Res.string.wallet_filter_all), filter == 0, { filter = 0 })
                GlassChip(stringResource(Res.string.wallet_filter_in), filter == 1, { filter = 1 }, accent = IncomeColor)
                GlassChip(stringResource(Res.string.wallet_filter_out), filter == 2, { filter = 2 }, accent = SpendColor)
            }
        }

        error?.let { e -> GlassNotice(e, Modifier.padding(horizontal = 16.dp), tone = cs.error) }

        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (shown.isEmpty()) {
                GlassCard(Modifier.fillMaxWidth(), padding = 24.dp) {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (loading) {
                            Text("…", style = MaterialTheme.typography.titleLarge, color = cs.onSurfaceVariant)
                        } else {
                            GlassIcon(Res.drawable.ic_schedule, cs.primary, box = 56.dp, glyph = 30.dp)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                stringResource(Res.string.wallet_empty_title),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Text(
                                stringResource(Res.string.wallet_empty_sub),
                                style = MaterialTheme.typography.bodyMedium,
                                color = cs.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
            }
            shown.groupBy { if (it.at > 0) it.at.floorDiv(86_400L) else -1L }.forEach { (day, entries) ->
                if (day >= 0) {
                    val header = when (day) {
                        today -> stringResource(Res.string.wallet_today)
                        today - 1 -> stringResource(Res.string.wallet_yesterday)
                        else -> dayText(day * 86_400L, jalali)
                    }
                    Text(
                        header,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(start = 8.dp, top = 6.dp),
                    )
                }
                entries.forEach { e -> HistoryRow(e, tomanWord) }
            }
            if (more) {
                CapsuleButton(
                    text = stringResource(Res.string.account_load_more),
                    onClick = { scope.launch { load(items.size) } },
                    container = cs.primary.copy(alpha = 0.16f),
                    content = cs.primary,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !loading,
                )
            }
        }
    }
}

@Composable
private fun MoneyPill(label: String, amount: Long, accent: Color, icon: org.jetbrains.compose.resources.DrawableResource, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(accent.copy(alpha = 0.12f))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        GlassIcon(icon, accent, box = 30.dp, glyph = 16.dp)
        Spacer(Modifier.width(8.dp))
        Column {
            Text(label, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1)
            Text(toman(amount), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = accent, maxLines = 1)
        }
    }
}

@Composable
private fun HistoryRow(e: AccountRepository.WalletEntry, tomanWord: String) {
    val cs = MaterialTheme.colorScheme
    val lk = look(e)
    val accent = if (lk.income) IncomeColor else SpendColor
    val status = statusLook(e.status)
    val failed = status?.color == FailColor
    val title = stringResource(lk.label)
    // The note only helps when it says more than the title already does.
    val note = e.note?.trim()?.takeIf { it.isNotEmpty() && !it.equals(e.kind, ignoreCase = true) }
    GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), padding = 14.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GlassIcon(if (lk.income) Res.drawable.ic_arrow_downward else Res.drawable.ic_arrow_upward, accent)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold, maxLines = 1)
                val sub = listOfNotNull(note, timeText(e.at).takeIf { it.isNotBlank() }).joinToString(" · ")
                if (sub.isNotBlank()) {
                    Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 2)
                }
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                e.amount?.let {
                    Text(
                        (if (lk.income) "+" else "−") + toman(amountOf(e)),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (failed) cs.onSurfaceVariant else accent,
                        maxLines = 1,
                    )
                }
                if (status != null) GlassBadge(stringResource(status.label), status.color) else {
                    Text(tomanWord, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
            }
        }
    }
}

/** The account summary, the invite link with its counters, and the state of the API key. */
@Composable
internal fun ProfilePage(account: AccountRepository, contentPadding: PaddingValues, modifier: Modifier) {
    val loggedIn by account.loggedIn.collectAsState()
    SettingsPageScaffold(
        title = stringResource(Res.string.account_profile),
        art = SettingsArts.Account,
        subtitle = stringResource(Res.string.account_profile_sub),
        contentPadding = contentPadding,
        modifier = modifier,
    ) {
        if (!loggedIn) LoginSection(account) else GlassPage { ProfileContent(account) }
    }
}

@Composable
internal fun Stat(label: String, value: String, modifier: Modifier = Modifier) {
    GlassCard(modifier, shape = RoundedCornerShape(24.dp), padding = 14.dp) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        Spacer(Modifier.height(2.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
private fun ProfileContent(account: AccountRepository) {
    val platform = LocalPlatform.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var profile by remember { mutableStateOf<AccountRepository.Profile?>(null) }
    var referral by remember { mutableStateOf<AccountRepository.Referral?>(null) }
    var key by remember { mutableStateOf<AccountRepository.ApiKeyInfo?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        account.profile().fold(onSuccess = { profile = it }, onFailure = { error = errorText(it) })
        account.referral().fold(onSuccess = { referral = it }, onFailure = { })
        account.apiKey().fold(onSuccess = { key = it }, onFailure = { })
    }

    Column(Modifier.padding(top = 14.dp, bottom = 12.dp, start = 16.dp, end = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        error?.let { e ->
            GlassCard(Modifier.fillMaxWidth(), padding = 14.dp) { Text(e, color = cs.error, style = MaterialTheme.typography.bodyMedium) }
        }

        profile?.let { p ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                p.balance?.let { Stat(stringResource(Res.string.account_balance), toman(it), Modifier.weight(1f)) }
                p.serviceCount?.let { Stat(stringResource(Res.string.account_services_count), it.toString(), Modifier.weight(1f)) }
            }
        }

        key?.let { k ->
            GlassCard(Modifier.fillMaxWidth(), padding = 16.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(Res.string.account_key_status), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text(
                        if (k.hasKey && k.allowed != false) stringResource(Res.string.account_key_active) else stringResource(Res.string.account_key_none),
                        style = MaterialTheme.typography.labelLarge,
                        color = if (k.hasKey && k.allowed != false) cs.primary else cs.onSurfaceVariant,
                    )
                }
            }
        }

        referral?.let { r ->
            GlassSectionTitle(stringResource(Res.string.account_referral))
            r.link?.let { link ->
                InviteCard(
                    link = link,
                    onCopy = {
                        platform.copyToClipboard(link)
                        scope.launch { platform.toast(getString(Res.string.account_link_copied)) }
                    },
                    onShare = { platform.shareText(link) },
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                r.clicks?.let { Stat(stringResource(Res.string.account_ref_clicks), it.toString(), Modifier.weight(1f)) }
                r.invited?.let { Stat(stringResource(Res.string.account_ref_invited), it.toString(), Modifier.weight(1f)) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                r.reward?.let { Stat(stringResource(Res.string.account_ref_reward), toman(it), Modifier.weight(1f)) }
                r.points?.let { Stat(stringResource(Res.string.account_ref_points), it.toString(), Modifier.weight(1f)) }
            }
        }

        profile?.fields?.takeIf { it.isNotEmpty() }?.let { fields ->
            val shown = setOf("balance", "wallet")
            val rest = fields.filter { (k, v) ->
                k.substringAfterLast('.').lowercase() !in shown && !v.startsWith("http", ignoreCase = true) &&
                    !k.startsWith("referral.") && !k.startsWith("api.") && !k.startsWith("services_")
            }.take(14)
            if (rest.isNotEmpty()) {
                GlassSectionTitle(stringResource(Res.string.account_details))
                GlassCard(Modifier.fillMaxWidth(), padding = 16.dp) {
                    rest.forEach { (k, v) ->
                        val name = k.replace("_", " ").replace(".", " · ")
                        if (v.length > 22) {
                            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(name, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                                Text(v, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                            }
                        } else {
                            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(name, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
                                Spacer(Modifier.width(12.dp))
                                Text(v, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, textAlign = TextAlign.End)
                            }
                        }
                    }
                }
            }
        }
    }
}


/** The invite link on a gradient glass card: the link in a pill, then copy and share. */
@Composable
internal fun InviteCard(link: String, onCopy: () -> Unit, onShare: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(32.dp)
    val a = cs.primary
    val b = androidx.compose.ui.graphics.lerp(cs.primary, cs.tertiary, 0.6f)
    val edge = androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.5f), Color.White.copy(alpha = 0.05f)))
    Box(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(a, b)))
            .border(1.dp, edge, shape),
    ) {
        Box(
            Modifier.matchParentSize().background(
                androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.20f), Color.Transparent), endY = 240f),
            ),
        )
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Color.White.copy(alpha = 0.22f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(painterResource(Res.drawable.ic_link), contentDescription = null, tint = cs.onPrimary, modifier = Modifier.size(24.dp))
                }
                Spacer(Modifier.width(12.dp))
                Text(
                    stringResource(Res.string.account_ref_link),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = cs.onPrimary,
                )
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.18f))
                    .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 14.dp, vertical = 12.dp),
            ) {
                androidx.compose.foundation.text.selection.SelectionContainer {
                    Text(
                        link,
                        color = cs.onPrimary,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        maxLines = 2,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                CapsuleButton(
                    text = stringResource(Res.string.account_copy_link),
                    onClick = onCopy,
                    container = cs.onPrimary,
                    content = cs.primary,
                    modifier = Modifier.weight(1f),
                )
                CapsuleButton(
                    text = stringResource(Res.string.invite_share),
                    onClick = onShare,
                    container = cs.onPrimary.copy(alpha = 0.22f),
                    content = cs.onPrimary,
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}
