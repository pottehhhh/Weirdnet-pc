# WEIRDNET — Beyond Limits. Beyond Lag. ⚡️
Fork of [ZedSecure](https://github.com/CluvexStudio/ZedSecure) (AGPL-3.0) with WEIRDNET branding.
Support: @WeirdNetSup · Buy VPN: @WeirdNet_Bot
License: AGPL-3.0 — see LICENSE and NOTICE. Source must stay public.
