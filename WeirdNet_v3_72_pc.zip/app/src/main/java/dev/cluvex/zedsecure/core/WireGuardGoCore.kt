package dev.cluvex.zedsecure.core

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.VpnService
import android.os.IBinder
import android.os.Parcel
import android.os.ParcelFileDescriptor
import dev.cluvex.zedsecure.core.AppLog as Log
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * The "gaming tunnel": a WireGuard server runs on wireguard-go, the engine inside the official
 * WireGuard app, over plain UDP.
 *
 * wireguard-go runs in its own process (see [WireGuardProcessService]) because the main process
 * already has a Go runtime. This object is the main-process side: it sends the TUN device across,
 * protects the engine's UDP sockets from the VPN, and reads traffic counters.
 *
 * Every running tunnel has a generation number. A late "turn off" for an old generation does
 * nothing, so a slow teardown can never kill a connection that started after it.
 */
object WireGuardGoCore {
    private const val TAG = "WireGuardGo"
    internal const val DESCRIPTOR = "dev.cluvex.zedsecure.core.WireGuardGoCore"
    internal const val TX_START = IBinder.FIRST_CALL_TRANSACTION
    internal const val TX_STOP = IBinder.FIRST_CALL_TRANSACTION + 1
    internal const val TX_STATS = IBinder.FIRST_CALL_TRANSACTION + 2
    private const val BIND_TIMEOUT_S = 10L

    private val ioLock = Any()
    private val stateLock = Any()

    @Volatile private var activeGen = -1L
    private var startedGen = 0L
    private var counter = 0L

    @Volatile private var remote: IBinder? = null
    private var connection: ServiceConnection? = null

    @Volatile private var lastRx = 0L
    @Volatile private var lastTx = 0L
    @Volatile private var handshakeSeen = false

    val isRunning: Boolean
        get() = activeGen >= 0 && remote?.isBinderAlive == true

    class Settings(
        val privateKey: String,
        val publicKey: String,
        val presharedKey: String?,
        val endpointIp: String,
        val port: Int,
        val keepalive: Int?,
        val allowedIps: List<String>,
    )

    /** Same text the official app builds with Config.toWgUserspaceString(). */
    fun userspaceConfig(s: Settings): String = buildString {
        append("private_key=").append(hex(s.privateKey)).append('\n')
        append("replace_peers=true\n")
        append("public_key=").append(hex(s.publicKey)).append('\n')
        s.presharedKey?.takeIf { it.isNotBlank() }?.let { append("preshared_key=").append(hex(it)).append('\n') }
        val host = if (s.endpointIp.contains(':') && !s.endpointIp.startsWith("[")) "[${s.endpointIp}]" else s.endpointIp
        append("endpoint=").append(host).append(':').append(s.port).append('\n')
        s.keepalive?.takeIf { it > 0 }?.let { append("persistent_keepalive_interval=").append(it).append('\n') }
        append("replace_allowed_ips=true\n")
        s.allowedIps.forEach { append("allowed_ip=").append(it.trim()).append('\n') }
    }

    private fun hex(base64Key: String): String {
        val bytes = android.util.Base64.decode(base64Key.trim().replace('-', '+').replace('_', '/'), android.util.Base64.DEFAULT)
        require(bytes.size == 32) { "WireGuard key must be 32 bytes" }
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun ensureBound(context: Context): IBinder? {
        remote?.takeIf { it.isBinderAlive }?.let { return it }
        unbind(context)
        val latch = CountDownLatch(1)
        val conn = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, service: IBinder) {
                remote = service
                latch.countDown()
            }

            override fun onServiceDisconnected(name: ComponentName) {
                Log.w(TAG, "the WireGuard process went away")
                remote = null
                synchronized(stateLock) { activeGen = -1L }
            }
        }
        val app = context.applicationContext
        val bound = app.bindService(
            Intent(app, WireGuardProcessService::class.java),
            conn,
            Context.BIND_AUTO_CREATE or Context.BIND_IMPORTANT,
        )
        if (!bound || !latch.await(BIND_TIMEOUT_S, TimeUnit.SECONDS)) {
            runCatching { app.unbindService(conn) }
            Log.w(TAG, "could not reach the WireGuard process")
            return null
        }
        connection = conn
        return remote
    }

    private fun unbind(context: Context) {
        val conn = connection ?: return
        connection = null
        remote = null
        runCatching { context.applicationContext.unbindService(conn) }
    }

    /** Frees the helper process once nothing runs. Safe to call from any thread. */
    fun release(context: Context) = synchronized(ioLock) {
        if (activeGen < 0) unbind(context)
    }

    private inline fun <T> transact(binder: IBinder, code: Int, fill: (Parcel) -> Unit = {}, read: (Parcel) -> T): T {
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken(DESCRIPTOR)
            fill(data)
            binder.transact(code, data, reply, 0)
            return read(reply)
        } finally {
            data.recycle()
            reply.recycle()
        }
    }

    /**
     * Starts the tunnel on [tun]. Returns the generation number of the new tunnel, or -1.
     * Must not be called on the main thread.
     */
    fun start(service: VpnService, tun: ParcelFileDescriptor, ifName: String, config: String): Long =
        synchronized(ioLock) {
            val gen = ++counter
            startedGen = gen
            synchronized(stateLock) { activeGen = -1L }
            val binder = ensureBound(service) ?: return@synchronized -1L
            val ok = try {
                transact(binder, TX_STOP) { it.readInt() }
                transact(
                    binder, TX_START,
                    fill = { d ->
                        d.writeString(ifName)
                        d.writeString(config)
                        tun.writeToParcel(d, 0)
                    },
                ) { r ->
                    if (r.readInt() != 1) {
                        false
                    } else {
                        val v4 = if (r.readInt() == 1) ParcelFileDescriptor.CREATOR.createFromParcel(r) else null
                        val v6 = if (r.readInt() == 1) ParcelFileDescriptor.CREATOR.createFromParcel(r) else null
                        listOf(v4, v6).forEach { sock ->
                            if (sock != null) {
                                if (!service.protect(sock.fd)) Log.w(TAG, "could not protect a WireGuard socket")
                                runCatching { sock.close() }
                            }
                        }
                        true
                    }
                }
            } catch (e: Throwable) {
                Log.e(TAG, "could not start wireguard-go", e)
                false
            }
            if (!ok) return@synchronized -1L
            lastRx = 0L
            lastTx = 0L
            handshakeSeen = false
            synchronized(stateLock) { activeGen = gen }
            gen
        }

    /** Takes the running tunnel out of service and returns its generation (or -1). Cheap, any thread. */
    fun detach(): Long = synchronized(stateLock) {
        val g = activeGen
        activeGen = -1L
        g
    }

    /** Stops the tunnel of generation [gen]; does nothing if a newer one has replaced it. Safe on any thread. */
    fun turnOff(gen: Long) {
        if (gen < 0) return
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            Thread({ turnOffNow(gen) }, "wg-off").start()
        } else {
            turnOffNow(gen)
        }
    }

    private fun turnOffNow(gen: Long) {
        synchronized(ioLock) {
            if (gen != startedGen) return
            val binder = remote?.takeIf { it.isBinderAlive } ?: return
            try {
                transact(binder, TX_STOP) { it.readInt() }
            } catch (e: Throwable) {
                Log.w(TAG, "stopping wireguard-go failed", e)
            }
        }
    }

    fun stop() = turnOff(detach())

    private fun counters(): LongArray? {
        if (activeGen < 0) return null
        val binder = remote?.takeIf { it.isBinderAlive } ?: return null
        return try {
            transact(binder, TX_STATS) { r ->
                if (r.readInt() != 1) null else longArrayOf(r.readLong(), r.readLong(), r.readLong())
            }
        } catch (e: Throwable) {
            null
        }
    }

    /** Bytes (down, up) since the last call. */
    fun trafficDelta(): Pair<Long, Long> {
        val c = counters() ?: return 0L to 0L
        if (c[2] > 0L) handshakeSeen = true
        val down = (c[0] - lastRx).coerceAtLeast(0L)
        val up = (c[1] - lastTx).coerceAtLeast(0L)
        lastRx = c[0]
        lastTx = c[1]
        return down to up
    }

    /** True once the peer has answered a handshake. */
    fun hasHandshake(): Boolean {
        if (handshakeSeen) return true
        val c = counters() ?: return false
        if (c[2] > 0L) handshakeSeen = true
        return handshakeSeen
    }
}
