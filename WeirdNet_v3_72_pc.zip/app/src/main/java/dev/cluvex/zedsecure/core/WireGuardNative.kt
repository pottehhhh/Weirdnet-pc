package dev.cluvex.zedsecure.core

import android.os.ParcelFileDescriptor
import android.util.Base64
import android.util.Log
import java.io.IOException

/**
 * wireguard-go, exactly as the official WireGuard app ships it (com.wireguard.android:tunnel).
 *
 * This only ever runs inside the separate ":wg" process (see [WireGuardProcessService]). The app
 * already carries one Go runtime in the main process (the Xray core); Go does not support two
 * runtimes in one process, so wireguard-go lives in its own.
 *
 * wireguard-go's handle table has no locking, so every native call goes through [lock].
 */
internal object WireGuardNative {
    private const val TAG = "WireGuardNative"
    private val lock = Any()
    private var handle = -1

    private val backend: Class<*> by lazy {
        System.loadLibrary("wg-go")
        Class.forName("com.wireguard.android.backend.GoBackend")
    }

    private val intType = Int::class.javaPrimitiveType!!

    private fun native(name: String, vararg types: Class<*>) =
        backend.getDeclaredMethod(name, *types).apply { isAccessible = true }

    class Started(val v4: ParcelFileDescriptor?, val v6: ParcelFileDescriptor?)

    /** Starts the tunnel on [tun] (the caller keeps its own copy). Returns the two UDP sockets to protect. */
    fun start(tun: ParcelFileDescriptor, ifName: String, config: String): Started? = synchronized(lock) {
        stopLocked()
        try {
            val turnOn = native("wgTurnOn", String::class.java, intType, String::class.java)
            val fd = tun.dup().detachFd()
            val h = turnOn.invoke(null, ifName.take(15).ifBlank { "wg0" }, fd, config) as Int
            if (h < 0) {
                Log.w(TAG, "wgTurnOn failed: $h")
                return@synchronized null
            }
            handle = h
            val v4 = native("wgGetSocketV4", intType).invoke(null, h) as Int
            val v6 = native("wgGetSocketV6", intType).invoke(null, h) as Int
            Started(dupSocket(v4), dupSocket(v6))
        } catch (e: Throwable) {
            Log.e(TAG, "could not start wireguard-go", e)
            stopLocked()
            null
        }
    }

    fun stop() = synchronized(lock) { stopLocked() }

    private fun stopLocked() {
        val h = handle
        if (h < 0) return
        handle = -1
        try {
            native("wgTurnOff", intType).invoke(null, h)
        } catch (e: Throwable) {
            Log.w(TAG, "wgTurnOff failed", e)
        }
    }

    /** rx bytes, tx bytes, last handshake (unix seconds, 0 = none); null when nothing runs. */
    fun counters(): LongArray? = synchronized(lock) {
        val h = handle
        if (h < 0) return@synchronized null
        val text = try {
            native("wgGetConfig", intType).invoke(null, h) as? String
        } catch (e: Throwable) {
            null
        } ?: return@synchronized null
        var rx = 0L
        var tx = 0L
        var hs = 0L
        text.lineSequence().forEach { line ->
            when {
                line.startsWith("rx_bytes=") -> rx += line.substring(9).trim().toLongOrNull() ?: 0L
                line.startsWith("tx_bytes=") -> tx += line.substring(9).trim().toLongOrNull() ?: 0L
                line.startsWith("last_handshake_time_sec=") ->
                    hs = maxOf(hs, line.substring(24).trim().toLongOrNull() ?: 0L)
            }
        }
        longArrayOf(rx, tx, hs)
    }

    /** A duplicate of a socket owned by wireguard-go, so another process can protect() it. */
    private fun dupSocket(fd: Int): ParcelFileDescriptor? {
        if (fd < 0) return null
        val adopted = ParcelFileDescriptor.adoptFd(fd)
        return try {
            ParcelFileDescriptor.dup(adopted.fileDescriptor)
        } catch (e: IOException) {
            null
        } finally {
            adopted.detachFd()
        }
    }
}
