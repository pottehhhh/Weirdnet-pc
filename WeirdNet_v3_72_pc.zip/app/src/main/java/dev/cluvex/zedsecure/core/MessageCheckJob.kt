package dev.cluvex.zedsecure.core

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import dev.cluvex.zedsecure.MainActivity
import dev.cluvex.zedsecure.R
import dev.cluvex.zedsecure.ZedSecureApp
import dev.cluvex.zedsecure.core.AppLog as Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Checks the WEIRDNET inbox now and then and shows a notification for new messages. */
object MessageCheckScheduler {
    private const val JOB_ID = 0x4D53
    private const val PERIOD_MS = 20 * 60 * 1000L
    const val CHANNEL_ID = "weirdnet_messages"

    fun ensure(context: Context) {
        val scheduler = context.getSystemService(JobScheduler::class.java) ?: return
        if (scheduler.getPendingJob(JOB_ID) != null) return
        val job = JobInfo.Builder(JOB_ID, ComponentName(context, MessageCheckJobService::class.java))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            .setPersisted(true)
            .setPeriodic(PERIOD_MS)
            .build()
        val result = runCatching { scheduler.schedule(job) }.getOrDefault(JobScheduler.RESULT_FAILURE)
        if (result != JobScheduler.RESULT_SUCCESS) Log.w("MessageCheck", "could not schedule the message check")
    }

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            context.getString(R.string.msg_channel_name),
            NotificationManager.IMPORTANCE_DEFAULT,
        ).apply { description = context.getString(R.string.msg_channel_desc) }
        context.getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
    }
}

class MessageCheckJobService : JobService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var running: Job? = null

    override fun onStartJob(params: JobParameters): Boolean {
        val account = (application as ZedSecureApp).container.configRepository.account
        if (!account.loggedIn.value) return false
        running = scope.launch {
            val fresh = account.newMessages().getOrNull()
            if (fresh != null) {
                if (fresh.notes.isNotEmpty()) show(fresh.notes)
                if (fresh.replies.isNotEmpty()) showReplies(fresh.replies)
            }
            jobFinished(params, false)
        }
        return true
    }

    private fun show(notes: List<dev.cluvex.zedsecure.data.account.AccountRepository.Note>) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        MessageCheckScheduler.createChannel(this)
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val manager = NotificationManagerCompat.from(this)
        // At most three separate notifications; anything beyond that is folded into one summary.
        val shown = notes.takeLast(3)
        shown.forEach { n ->
            val b = NotificationCompat.Builder(this, MessageCheckScheduler.CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_tile_zed)
                .setContentTitle(n.title)
                .setContentText(n.body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(n.body))
                .setContentIntent(open)
                .setAutoCancel(true)
            runCatching { manager.notify(NOTIFICATION_BASE + (n.id % 1000).toInt(), b.build()) }
        }
        if (notes.size > shown.size) {
            val b = NotificationCompat.Builder(this, MessageCheckScheduler.CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_tile_zed)
                .setContentTitle(getString(R.string.msg_more_title))
                .setContentText(getString(R.string.msg_more_text, notes.size - shown.size))
                .setContentIntent(open)
                .setAutoCancel(true)
            runCatching { manager.notify(NOTIFICATION_BASE + 1000, b.build()) }
        }
    }

    private fun showReplies(replies: List<dev.cluvex.zedsecure.data.account.AccountRepository.ChatMessage>) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        MessageCheckScheduler.createChannel(this)
        val open = PendingIntent.getActivity(
            this,
            1,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        // Support replies belong to one conversation, so they share a single notification showing the newest.
        val last = replies.last()
        val b = NotificationCompat.Builder(this, MessageCheckScheduler.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_tile_zed)
            .setContentTitle(getString(R.string.msg_support_title))
            .setContentText(last.body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(last.body))
            .setNumber(replies.size)
            .setContentIntent(open)
            .setAutoCancel(true)
        runCatching { NotificationManagerCompat.from(this).notify(NOTIFICATION_BASE + 2000, b.build()) }
    }

    override fun onStopJob(params: JobParameters): Boolean {
        running?.cancel()
        return true
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private companion object {
        const val NOTIFICATION_BASE = 0x4D500
    }
}
