package dev.cluvex.zedsecure.core

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.os.Parcel
import android.os.ParcelFileDescriptor

/**
 * Hosts wireguard-go in its own process (":wg"). The main process establishes the TUN device and
 * sends it here; see [WireGuardGoCore] for the other side of the conversation.
 */
class WireGuardProcessService : Service() {
    private val binder = object : Binder() {
        override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
            if (reply == null) return super.onTransact(code, data, reply, flags)
            when (code) {
                WireGuardGoCore.TX_START -> {
                    data.enforceInterface(WireGuardGoCore.DESCRIPTOR)
                    val name = data.readString().orEmpty()
                    val config = data.readString().orEmpty()
                    val tun = ParcelFileDescriptor.CREATOR.createFromParcel(data)
                    val started = try {
                        WireGuardNative.start(tun, name, config)
                    } finally {
                        runCatching { tun.close() }
                    }
                    if (started == null) {
                        reply.writeInt(0)
                    } else {
                        reply.writeInt(1)
                        writeSocket(reply, started.v4)
                        writeSocket(reply, started.v6)
                    }
                }
                WireGuardGoCore.TX_STOP -> {
                    data.enforceInterface(WireGuardGoCore.DESCRIPTOR)
                    WireGuardNative.stop()
                    reply.writeInt(1)
                }
                WireGuardGoCore.TX_STATS -> {
                    data.enforceInterface(WireGuardGoCore.DESCRIPTOR)
                    val c = WireGuardNative.counters()
                    if (c == null) {
                        reply.writeInt(0)
                    } else {
                        reply.writeInt(1)
                        c.forEach { reply.writeLong(it) }
                    }
                }
                else -> return super.onTransact(code, data, reply, flags)
            }
            return true
        }
    }

    private fun writeSocket(reply: Parcel, pfd: ParcelFileDescriptor?) {
        if (pfd == null) {
            reply.writeInt(0)
        } else {
            reply.writeInt(1)
            pfd.writeToParcel(reply, 0)
            runCatching { pfd.close() }
        }
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        WireGuardNative.stop()
        super.onDestroy()
    }
}
