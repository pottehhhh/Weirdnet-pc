package dev.cluvex.zedsecure.data.account

import dev.cluvex.zedsecure.platform.HttpTextResponse
import dev.cluvex.zedsecure.platform.KeyValueStore
import kotlinx.coroutines.test.runTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

private class MemoryStore : KeyValueStore {
    val map = mutableMapOf<String, String>()
    override fun getString(key: String): String? = map[key]
    override fun putString(key: String, value: String?) { if (value == null) map.remove(key) else map[key] = value }
    override fun getInt(key: String, default: Int): Int = map[key]?.toIntOrNull() ?: default
    override fun putInt(key: String, value: Int) { map[key] = value.toString() }
    override fun getBoolean(key: String, default: Boolean): Boolean = map[key]?.toBooleanStrictOrNull() ?: default
    override fun putBoolean(key: String, value: Boolean) { map[key] = value.toString() }
    override fun remove(key: String) { map.remove(key) }
}

/** A stand-in for the bot's API: records every request and answers with whatever [handler] returns. */
private class FakeBot {
    val calls = mutableListOf<Map<String, String>>()
    var fail: Throwable? = null
    var handler: (Map<String, String>) -> String = { """{"ok":true}""" }
    fun actions(): List<String> = calls.map { it["action"].orEmpty() }
}

private const val API_KEY_SLOT = "account_api_key"

private fun decode(s: String): String {
    val bytes = ArrayList<Byte>()
    var i = 0
    while (i < s.length) {
        if (s[i] == '%') { bytes.add(s.substring(i + 1, i + 3).toInt(16).toByte()); i += 3 }
        else { bytes.add(s[i].code.toByte()); i++ }
    }
    return bytes.toByteArray().decodeToString()
}

private fun parseForm(form: String): Map<String, String> =
    form.split("&").filter { it.isNotEmpty() }.associate {
        val (k, v) = it.split("=", limit = 2)
        decode(k) to decode(v)
    }

private fun newRepo(
    bot: FakeBot,
    store: MemoryStore = MemoryStore(),
    wireguard: Boolean = false,
    loggedIn: Boolean = true,
): AccountRepository {
    if (loggedIn) store.putString(API_KEY_SLOT, "KEY123")
    val repo = AccountRepository(
        rootStore = store,
        importer = { _, _ -> Result.success(null) },
        appHasLink = { false },
        appRemoveLink = {},
        linkIsWireguard = { wireguard },
    )
    repo.send = { _, form ->
        bot.fail?.let { throw it }
        val fields = parseForm(form)
        bot.calls += fields
        HttpTextResponse(200, bot.handler(fields), emptyMap())
    }
    return repo
}


/** A repo whose "app" is a plain set of subscription links, so the sync can be watched. */
private fun syncRepo(inApp: MutableSet<String>, store: MemoryStore = MemoryStore()): AccountRepository {
    store.putString(API_KEY_SLOT, "KEY123")
    return AccountRepository(
        rootStore = store,
        importer = { url, _ -> inApp.add(url); Result.success(null) },
        appHasLink = { url -> inApp.any { it.equals(url, ignoreCase = true) } },
        appRemoveLink = { url -> inApp.removeAll { it.equals(url, ignoreCase = true) } },
    )
}


/** A repo with a fake bot and a fake "app" (a set of links), for the tests that use more than one account. */
private fun multiRepo(inApp: MutableSet<String>, bot: FakeBot, store: MemoryStore = MemoryStore()): AccountRepository {
    store.putString(API_KEY_SLOT, "KEY123")
    val repo = AccountRepository(
        rootStore = store,
        importer = { url, _ -> inApp.add(url); Result.success(null) },
        appHasLink = { url -> inApp.any { it.equals(url, ignoreCase = true) } },
        appRemoveLink = { url -> inApp.removeAll { it.equals(url, ignoreCase = true) } },
    )
    repo.send = { _, form ->
        val fields = parseForm(form)
        bot.calls += fields
        HttpTextResponse(200, bot.handler(fields), emptyMap())
    }
    return repo
}

/** The bot of two people: KEY123 owns service 1, KEY999 owns service 2. */
private fun twoPeople(): FakeBot = FakeBot().apply {
    handler = { f ->
        when (f["action"]) {
            "services" ->
                if (f["key"] == "KEY999") """{"ok":true,"services":[{"code":"2","sub_link":"https://h/two"}]}"""
                else """{"ok":true,"services":[{"code":"1","sub_link":"https://h/one"}]}"""
            "balance" -> """{"ok":true,"balance":5}"""
            else -> """{"ok":true}"""
        }
    }
}

private fun service(code: String = "1", plan: String? = null, link: String? = null, panel: String? = null) =
    AccountRepository.Service(
        code = code, email = null, subLink = link, plan = plan, status = null, enabled = null,
        usedBytes = null, totalBytes = null, expiryMs = null, panel = panel,
    )

class AccountRepositoryTest {

    // ---- sign-in ----

    @Test
    fun loginSendsTheKeyWithABalanceCheckAndKeepsIt() = runTest {
        val bot = FakeBot().apply { handler = { """{"ok":true,"balance":50000.0}""" } }
        val store = MemoryStore()
        val repo = newRepo(bot, store, loggedIn = false)

        assertFalse(repo.loggedIn.value)
        assertTrue(repo.login("  KEY123 \n").isSuccess)

        assertEquals("KEY123", bot.calls.single()["key"])
        assertEquals("balance", bot.calls.single()["action"])
        assertEquals("KEY123", store.getString(API_KEY_SLOT))
        assertTrue(repo.loggedIn.value)
        assertEquals(50000L, repo.balanceFlow.value)
    }

    @Test
    fun loginWithAWrongKeyStoresNothing() = runTest {
        val bot = FakeBot().apply { handler = { """{"ok":false,"error":"invalid_api_key"}""" } }
        val store = MemoryStore()
        val repo = newRepo(bot, store, loggedIn = false)

        val result = repo.login("nope")

        val e = assertIs<AccountRepository.AccountException>(result.exceptionOrNull())
        assertEquals(AccountRepository.AccountException.Kind.Unauthorized, e.kind)
        assertNull(store.getString(API_KEY_SLOT))
        assertFalse(repo.loggedIn.value)
    }

    @Test
    fun loginWithABlankKeyDoesNotTouchTheNetwork() = runTest {
        val bot = FakeBot()
        val repo = newRepo(bot, loggedIn = false)

        assertTrue(repo.login("   ").isFailure)
        assertTrue(bot.calls.isEmpty())
    }

    @Test
    fun loginWhenOfflineFailsAndKeepsNoKey() = runTest {
        val bot = FakeBot().apply { fail = RuntimeException("down") }
        val store = MemoryStore()
        val repo = newRepo(bot, store, loggedIn = false)

        val e = assertIs<AccountRepository.AccountException>(repo.login("KEY123").exceptionOrNull())
        assertEquals(AccountRepository.AccountException.Kind.Network, e.kind)
        assertNull(store.getString(API_KEY_SLOT))
    }

    @Test
    fun aRevokedKeyLogsTheUserOutMidSession() = runTest {
        val bot = FakeBot().apply { handler = { """{"ok":false,"error":"invalid_api_key"}""" } }
        val store = MemoryStore()
        val repo = newRepo(bot, store)
        assertTrue(repo.loggedIn.value)

        assertTrue(repo.services().isFailure)

        assertFalse(repo.loggedIn.value)
        assertNull(store.getString(API_KEY_SLOT))
    }

    @Test
    fun logoutForgetsTheKeyAndTheBalance() = runTest {
        val bot = FakeBot().apply { handler = { """{"ok":true,"balance":10}""" } }
        val store = MemoryStore()
        val repo = newRepo(bot, store)
        repo.balance()

        repo.logout()

        assertFalse(repo.loggedIn.value)
        assertNull(repo.balanceFlow.value)
        assertNull(store.getString(API_KEY_SLOT))
    }

    // ---- requests ----

    @Test
    fun parametersAreFormEncodedAndSurviveSpecialCharacters() = runTest {
        val bot = FakeBot()
        val repo = newRepo(bot)
        val tricky = "سلام & x=1 %41 +"

        repo.call("ticket", mapOf("text" to tricky, "subject" to "a b"))

        val sent = bot.calls.single()
        assertEquals(tricky, sent["text"])
        assertEquals("a b", sent["subject"])
        assertEquals("KEY123", sent["key"])
        assertEquals("ticket", sent["action"])
    }

    @Test
    fun deleteSendsOnlyTheServiceCode() = runTest {
        val bot = FakeBot()
        val repo = newRepo(bot)

        assertTrue(repo.delete("123456789").isSuccess)

        val sent = bot.calls.single()
        assertEquals("delete", sent["action"])
        assertEquals("123456789", sent["service"])
        assertFalse("confirm" in sent)
    }

    @Test
    fun errorsKeepTheBotsErrorCode() = runTest {
        val bot = FakeBot().apply { handler = { """{"ok":false,"error":"balance_insufficient"}""" } }
        val repo = newRepo(bot)

        val e = assertIs<AccountRepository.AccountException>(repo.buy("3", "ref-1").exceptionOrNull())

        assertEquals("balance_insufficient", e.message)
        assertEquals(AccountRepository.AccountException.Kind.Server, e.kind)
    }

    // ---- offline cache ----

    @Test
    fun readOnlyAnswersComeFromTheCacheWhenTheBotIsUnreachable() = runTest {
        val bot = FakeBot().apply { handler = { """{"ok":true,"services":[{"code":"9","sub_link":"https://h/s/9"}]}""" } }
        val repo = newRepo(bot)
        assertEquals("9", repo.services().getOrThrow().single().code)
        assertFalse(repo.offline.value)

        bot.fail = RuntimeException("down")
        val again = repo.services().getOrThrow()

        assertEquals("9", again.single().code)
        assertTrue(repo.offline.value)
    }

    @Test
    fun withoutACacheANetworkFailureIsReported() = runTest {
        val bot = FakeBot().apply { fail = RuntimeException("down") }
        val repo = newRepo(bot)

        val e = assertIs<AccountRepository.AccountException>(repo.services().exceptionOrNull())

        assertEquals(AccountRepository.AccountException.Kind.Network, e.kind)
    }

    @Test
    fun purchasesAreNeverAnsweredFromTheCache() = runTest {
        val bot = FakeBot().apply { fail = RuntimeException("down") }
        val repo = newRepo(bot)

        assertTrue(repo.buy("3", "ref-1").isFailure)
    }

    // ---- buying ----

    private val boughtReply =
        """{"ok":true,"charged":150000,"balance":50000.0,"service":{"code":"123","email":"e","sub_link":"https://h/sub/x"}}"""

    @Test
    fun buyingSendsThePlanAndTheRefAndRemembersTheServiceAsBoughtInTheApp() = runTest {
        val bot = FakeBot().apply {
            handler = { f ->
                when (f["action"]) {
                    "buy" -> boughtReply
                    "services" -> """{"ok":true,"services":[{"code":"123"},{"code":"456"}]}"""
                    else -> """{"ok":true}"""
                }
            }
        }
        val repo = newRepo(bot)

        val result = repo.buy("3", "order-1001", code = " OFF10 ").getOrThrow()

        val sent = bot.calls.single()
        assertEquals("buy", sent["action"])
        assertEquals("3", sent["plan_id"])
        assertEquals("order-1001", sent["ref"])
        assertEquals("OFF10", sent["discount_code"])
        assertEquals("123", result.service?.code)
        assertEquals(150000L, result.charged)
        assertEquals(50000L, result.balance)
        assertEquals(50000L, repo.balanceFlow.value)

        val list = repo.services().getOrThrow()
        assertTrue(list.first { it.code == "123" }.appBought)
        assertFalse(list.first { it.code == "456" }.appBought)
    }

    @Test
    fun aCustomPlanSendsVolumeAndDaysInsteadOfAPlanId() = runTest {
        val bot = FakeBot().apply { handler = { boughtReply } }
        val repo = newRepo(bot)

        repo.buy(null, "order-2", gb = 50, days = 30, panel = "STANDARD")

        val sent = bot.calls.single()
        assertEquals("50", sent["gb"])
        assertEquals("30", sent["days"])
        // The app says STANDARD; the bot wants its own panel id.
        assertEquals("pasarguard#4", sent["panel"])
        assertFalse("plan_id" in sent)
    }

    @Test
    fun aChangedPriceStopsThePurchaseBeforeAnythingIsCharged() = runTest {
        val bot = FakeBot().apply {
            handler = { f -> if (f["action"] == "quote") """{"ok":true,"final_price":150000}""" else boughtReply }
        }
        val repo = newRepo(bot)

        val e = assertIs<AccountRepository.AccountException>(repo.buy("3", "order-3", expect = 100000).exceptionOrNull())

        assertEquals("price_changed", e.message)
        assertFalse("buy" in bot.actions())
    }

    @Test
    fun anUnchangedPriceLetsThePurchaseThrough() = runTest {
        val bot = FakeBot().apply {
            handler = { f -> if (f["action"] == "quote") """{"ok":true,"final_price":150000}""" else boughtReply }
        }
        val repo = newRepo(bot)

        assertTrue(repo.buy("3", "order-4", expect = 150000).isSuccess)
        assertEquals(listOf("quote", "buy"), bot.actions())
    }

    @Test
    fun aQuoteThatCannotBeReadDoesNotBlockThePurchase() = runTest {
        val bot = FakeBot().apply {
            handler = { f -> if (f["action"] == "quote") """{"ok":false,"error":"error_panel"}""" else boughtReply }
        }
        val repo = newRepo(bot)

        assertTrue(repo.buy("3", "order-5", expect = 150000).isSuccess)
    }

    @Test
    fun topUpAndItsStatusUseTheDocumentedFields() = runTest {
        val bot = FakeBot().apply {
            handler = { f ->
                if (f["action"] == "charge") """{"ok":true,"order_id":"77","pay_url":"https://pay/77"}"""
                else """{"ok":true,"status":"paid"}"""
            }
        }
        val repo = newRepo(bot)

        val charge = repo.charge(200000).getOrThrow()
        assertEquals("200000", bot.calls[0]["amount"])
        assertEquals("77", charge.orderId)
        assertEquals("https://pay/77", charge.payUrl)

        assertEquals("paid", repo.chargeStatus("77").getOrThrow())
        assertEquals("77", bot.calls[1]["order_id"])
    }

    @Test
    fun plansAreReadFromTheDocumentedFields() = runTest {
        val bot = FakeBot().apply {
            handler = { """{"ok":true,"plans":[{"id":3,"title":"50GB","volume_gb":50,"days":30,"price":150000}]}""" }
        }
        val plan = newRepo(bot).plans().getOrThrow().single()

        assertEquals("3", plan.id)
        assertEquals("50GB", plan.title)
        assertEquals("50", plan.volumeGb)
        assertEquals("30", plan.days)
        assertEquals(150000L, plan.price)
    }


    // ---- the bot's real answers (panels are ids like "pasarguard#2", lists are called "items") ----

    private val realCustom =
        """{"ok":true,"count":3,"items":[""" +
            """{"panel":"pasarguard#2","price_per_gb":5000,"price_per_day":0,"min_gb":10,"max_gb":1000,"min_days":30,"max_days":30},""" +
            """{"panel":"nodex","price_per_gb":5000,"price_per_day":0,"min_gb":10,"max_gb":1000,"min_days":30,"max_days":30},""" +
            """{"panel":"pasarguard#4","price_per_gb":3000,"price_per_day":0,"min_gb":20,"max_gb":1000,"min_days":30,"max_days":30}]}"""

    @Test
    fun customPlanLimitsAreMappedFromPanelIdsToPlanKinds() = runTest {
        val bot = FakeBot().apply { handler = { realCustom } }

        val info = newRepo(bot).custom().getOrThrow()

        assertEquals(setOf("GAMING", "OMEGA", "STANDARD"), info.panels.map { it.type }.toSet())
        val standard = info.panels.first { it.type == "STANDARD" }
        assertEquals(3000L, standard.perGb)
        assertEquals(20, standard.minGb)
        assertEquals(1000, standard.maxGb)
        assertEquals(30, standard.minDays)
        assertEquals(5000L, info.panels.first { it.type == "GAMING" }.perGb)
        assertTrue(info.panels.all { it.found })
    }

    @Test
    fun aVolumePlanOfEachKindIsBoughtOnItsOwnPanel() = runTest {
        val bot = FakeBot().apply { handler = { boughtReply } }
        val repo = newRepo(bot)

        repo.buy(null, "r-1", gb = 10, days = 30, panel = "GAMING")
        repo.buy(null, "r-2", gb = 10, days = 30, panel = "OMEGA")
        repo.buy(null, "r-3", gb = 20, days = 30, panel = "STANDARD")

        assertEquals(listOf("pasarguard#2", "nodex", "pasarguard#4"), bot.calls.map { it["panel"] })
    }

    @Test
    fun theQuoteAsksAboutTheSamePanelThePurchaseUses() = runTest {
        val bot = FakeBot().apply { handler = { """{"ok":true,"final_price":50000}""" } }

        newRepo(bot).quote(null, gb = 10, days = 30, panel = "GAMING")

        assertEquals("pasarguard#2", bot.calls.single()["panel"])
        assertEquals("quote", bot.calls.single()["action"])
    }

    @Test
    fun anUnknownPanelNameIsPassedThroughUntouched() = runTest {
        val bot = FakeBot().apply { handler = { boughtReply } }

        newRepo(bot).buy(null, "r-4", gb = 10, days = 30, panel = "pasarguard#9")

        assertEquals("pasarguard#9", bot.calls.single()["panel"])
    }

    private val realServices =
        """{"ok":true,"count":2,"items":[""" +
            """{"id":30482,"code":"794746312","email":"GamingWeirdnetSupamd","plan":"حجم دلخواه 10 گیگ / 30 روز","volume_gb":10,"volume_mb":null,"days":30,"panel":"pasarguard#2","sub_link":"https://h.example/a","expires_at":"2026-12-04T13:18:38","status":"active"},""" +
            """{"id":30281,"code":"705002896","email":"EWeirdnetSup8bj","plan":"دو کاربر","volume_gb":300,"days":30,"panel":"pasarguard","sub_link":"https://h.example/b","expires_at":"2026-12-04T03:54:47","status":"active"}]}"""

    @Test
    fun servicesAreReadFromTheRealReplyWithVolumeAndExpiry() = runTest {
        val bot = FakeBot().apply { handler = { realServices } }

        val list = newRepo(bot).services().getOrThrow()

        val gaming = list.first { it.code == "794746312" }
        assertEquals(10L * 1_073_741_824L, gaming.totalBytes)
        assertEquals(1796390318L * 1000, gaming.expiryMs)
        assertEquals("active", gaming.status)
        assertEquals("pasarguard#2", gaming.panel)
        assertEquals("https://h.example/a", gaming.subLink)
    }

    @Test
    fun theBotsPanelIdTellsThePlanFamilyOfAService() = runTest {
        val repo = newRepo(FakeBot().apply { handler = { realServices } })
        val list = repo.services().getOrThrow()

        assertEquals(2, repo.kindOf(list.first { it.code == "794746312" }))
        // The plain "pasarguard" panel with a "N users" plan is the unlimited family.
        assertEquals(3, repo.kindOf(list.first { it.code == "705002896" }))
        assertEquals(0, repo.kindOf(service(code = "x", plan = "حجم دلخواه 25 گیگ / 30 روز", panel = "pasarguard#4")))
        assertEquals(1, repo.kindOf(service(code = "y", plan = "حجم دلخواه 20 گیگ / 30 روز", panel = "nodex")))
    }

    @Test
    fun unlimitedPlansAreReadFromTheRealPlanList() = runTest {
        val bot = FakeBot().apply {
            handler = {
                """{"ok":true,"count":1,"items":[{"id":1333,"title":"دو کاربر","volume_gb":300,"days":30,"price":110000,"base_price":110000,"category":"UNLIMITED","panel":"pasarguard","ip_limit":2}]}"""
            }
        }

        val plan = newRepo(bot).plans().getOrThrow().single()

        assertEquals("1333", plan.id)
        assertEquals(110000L, plan.price)
        assertEquals(2, plan.ipLimit)
        assertTrue(plan.isUnlimited)
    }

    @Test
    fun theBalanceIsReadFromTheRealReply() = runTest {
        val bot = FakeBot().apply { handler = { """{"ok":true,"balance":8332000.0,"currency":"TOMAN"}""" } }

        assertEquals(8332000L, newRepo(bot).balance().getOrThrow())
    }

    // ---- support tickets ----

    @Test
    fun theFirstMessageOpensATicketAndLaterOnesReplyToIt() = runTest {
        val bot = FakeBot().apply {
            handler = { f -> if (f["action"] == "ticket") """{"ok":true,"ticket":{"id":7}}""" else """{"ok":true}""" }
        }
        val repo = newRepo(bot)

        assertTrue(repo.supportSend("first").isSuccess)
        assertTrue(repo.supportSend("second").isSuccess)

        assertEquals(listOf("ticket", "ticket_reply"), bot.actions())
        assertEquals("first", bot.calls[0]["text"])
        assertEquals("7", bot.calls[1]["ticket_id"])
        assertEquals("second", bot.calls[1]["text"])
    }

    @Test
    fun aClosedTicketIsReplacedByANewOne() = runTest {
        var replies = 0
        val bot = FakeBot().apply {
            handler = { f ->
                when (f["action"]) {
                    "ticket" -> """{"ok":true,"id":8}"""
                    "ticket_reply" -> { replies++; """{"ok":false,"error":"ticket_closed"}""" }
                    else -> """{"ok":true}"""
                }
            }
        }
        val repo = newRepo(bot)
        repo.supportSend("one")

        assertTrue(repo.supportSend("two").isSuccess)

        assertEquals(listOf("ticket", "ticket_reply", "ticket"), bot.actions())
        assertEquals(1, replies)
    }

    @Test
    fun aLostConnectionNeverCreatesADuplicateTicket() = runTest {
        val bot = FakeBot().apply {
            handler = { f -> if (f["action"] == "ticket") """{"ok":true,"ticket":{"id":7}}""" else """{"ok":true}""" }
        }
        val repo = newRepo(bot)
        repo.supportSend("one")
        bot.calls.clear()

        bot.fail = RuntimeException("down")
        assertTrue(repo.supportSend("two").isFailure)
        bot.fail = null

        assertFalse("ticket" in bot.actions())
    }

    private fun ticketBot(extraSupportReply: Boolean = false) = FakeBot().apply {
        val extra = if (extraSupportReply) ",{\"text\":\"one more\",\"admin\":1}" else ""
        val detail = "{\"ok\":true," +
            "\"ticket\":{\"id\":7,\"text\":\"hello\",\"created_at\":\"2026-11-04 12:30:00\"}," +
            "\"replies\":[{\"text\":\"hi\",\"admin\":1,\"created_at\":\"2026-11-04 12:35:00\"}," +
            "{\"text\":\"thanks\",\"admin\":0}" + extra + "]}"
        handler = { f ->
            when {
                f["action"] == "tickets" && "ticket_id" !in f -> """{"ok":true,"tickets":[{"id":7,"subject":"s"}]}"""
                f["action"] == "tickets" -> detail
                else -> """{"ok":true}"""
            }
        }
    }

    @Test
    fun aTicketBecomesAConversationWithTheSupportRepliesMarked() = runTest {
        val repo = newRepo(ticketBot())

        val chat = repo.supportMessages().getOrThrow()

        assertEquals(listOf("hello", "hi", "thanks"), chat.map { it.body })
        assertEquals(listOf(false, true, false), chat.map { it.fromSupport })
        assertEquals(listOf(7000L, 7001L, 7002L), chat.map { it.id })
        assertEquals(1793795400L, chat.first().at)
    }

    @Test
    fun aListAnswerForADetailCallIsNotMixedIntoThreads() = runTest {
        // The real bot answers the plain list when it does not know the parameter; replies of other tickets must not leak in.
        val list = """{"ok":true,"count":2,"items":[{"id":2,"status":"answered","subject":"b","text":"second"},{"id":1,"status":"closed","subject":"a","text":"first"}]}"""
        val bot = FakeBot().apply { handler = { list } }
        val repo = newRepo(bot)
        val msgs = repo.ticketConversation("1").getOrThrow()
        assertEquals(listOf("first"), msgs.map { it.text })
    }

    @Test
    fun anUnreadableDateDoesNotBreakTheChat() = runTest {
        val bot = FakeBot().apply {
            handler = { f ->
                if (f["action"] == "tickets" && "ticket_id" !in f) """{"ok":true,"tickets":[{"id":1}]}"""
                else """{"ok":true,"ticket":{"id":1,"text":"hello","created_at":"yesterday"},"replies":[]}"""
            }
        }
        val chat = newRepo(bot).supportMessages().getOrThrow()

        assertEquals("hello", chat.single().body)
        assertEquals(0L, chat.single().at)
    }

    @Test
    fun theSupportBadgeCountsOnlyRepliesArrivingAfterTheFirstLook() = runTest {
        val bot = ticketBot()
        val repo = newRepo(bot)

        repo.refreshUnread()
        assertEquals(0, repo.unreadSupport.value)

        val bigger = ticketBot(extraSupportReply = true)
        bot.handler = bigger.handler
        repo.refreshUnread()
        assertEquals(1, repo.unreadSupport.value)

        repo.supportMessages()
        assertEquals(0, repo.unreadSupport.value)
    }

    @Test
    fun backgroundCheckOnlyReportsNewRepliesAndStartsQuiet() = runTest {
        val bot = ticketBot()
        val repo = newRepo(bot)

        val first = repo.newMessages().getOrThrow()
        assertTrue(first.replies.isEmpty())

        bot.handler = ticketBot(extraSupportReply = true).handler
        val second = repo.newMessages().getOrThrow()
        assertEquals(listOf("one more"), second.replies.map { it.body })

        val third = repo.newMessages().getOrThrow()
        assertTrue(third.replies.isEmpty())
    }

    @Test
    fun theTrialReturnsTheNewServiceAndMarksItAsBoughtHere() = runTest {
        val bot = FakeBot().apply {
            handler = { f ->
                if (f["action"] == "trial") """{"ok":true,"service":{"code":"55","sub_link":"https://h/55"}}"""
                else """{"ok":true,"services":[{"code":"55"}]}"""
            }
        }
        val repo = newRepo(bot)

        val trial = repo.trial().getOrThrow()
        assertNotNull(trial)
        assertEquals("55", trial.code)
        assertTrue(repo.services().getOrThrow().single().appBought)
    }

    @Test
    fun trialErrorsAreHandedBackAsCodes() = runTest {
        val bot = FakeBot().apply { handler = { """{"ok":false,"error":"trial_already_used"}""" } }

        assertEquals("trial_already_used", newRepo(bot).trial().exceptionOrNull()?.message)
    }

    // ---- plan family on the "my services" list ----

    @Test
    fun planFamiliesAreRecognisedFromTheirNames() {
        val repo = newRepo(FakeBot())

        assertEquals(0, repo.kindOf(service(plan = "50GB")))
        assertEquals(1, repo.kindOf(service(plan = "Omega 100")))
        assertEquals(1, repo.kindOf(service(panel = "nodex")))
        assertEquals(2, repo.kindOf(service(plan = "Gaming 30")))
        assertEquals(2, repo.kindOf(service(plan = "پلن گیم")))
        assertEquals(3, repo.kindOf(service(plan = "Unlimited 3 users")))
    }

    @Test
    fun aServiceHandingOutWireguardServersIsGaming() {
        assertEquals(2, newRepo(FakeBot(), wireguard = true).kindOf(service(plan = "50GB", panel = "pasarguard", link = "https://h/s")))
        assertEquals(0, newRepo(FakeBot(), wireguard = false).kindOf(service(plan = "50GB", panel = "pasarguard", link = "https://h/s")))
    }

    @Test
    fun aFamilyLearnedAtPurchaseWinsAndSpreadsToTheSameHost() {
        val repo = newRepo(FakeBot())
        val bought = service(code = "1", plan = "50GB", link = "https://gaming.example/sub/a")
        repo.learnKind(bought, 2)

        assertEquals(2, repo.kindOf(bought))
        assertEquals(2, repo.kindOf(service(code = "2", plan = "50GB", link = "https://gaming.example/sub/b")))
        assertEquals(0, repo.kindOf(service(code = "3", plan = "50GB", link = "https://other.example/sub/c")))
    }

    @Test
    fun theOldTelegramLoginSessionIsDropped() {
        val store = MemoryStore().apply { putString("account_session_token", "old") }
        newRepo(FakeBot(), store, loggedIn = false)

        assertNull(store.getString("account_session_token"))
    }

    // ---- the app follows the account ----

    @Test
    fun everyServiceOfTheAccountIsAddedNotOnlyTheOnesBoughtInTheApp() = runTest {
        val inApp = mutableSetOf<String>()
        val repo = syncRepo(inApp)

        val report = repo.syncServices(
            listOf(
                service(code = "1", link = "https://sub.shopfastpro.ir/sub/aaa"),
                service(code = "2", link = "https://sub.sefrtasad.com/sub/bbb"),
                service(code = "3", link = null),
            ),
        )

        assertEquals(2, report.added)
        assertEquals(setOf("https://sub.shopfastpro.ir/sub/aaa", "https://sub.sefrtasad.com/sub/bbb"), inApp)
    }

    @Test
    fun aServiceDeletedOnTheAccountIsTakenOutOfTheApp() = runTest {
        val inApp = mutableSetOf<String>()
        val repo = syncRepo(inApp)
        val one = service(code = "1", link = "https://sub.shopfastpro.ir/sub/aaa")
        val two = service(code = "2", link = "https://sub.sefrtasad.com/sub/bbb")
        repo.syncServices(listOf(one, two))

        val report = repo.syncServices(listOf(two))

        assertEquals(1, report.removed)
        assertEquals(setOf("https://sub.sefrtasad.com/sub/bbb"), inApp)
    }

    @Test
    fun aLinkTheUserPastedByHandIsNeverTakenOut() = runTest {
        val inApp = mutableSetOf("https://sub.sefrtasad.com/sub/mine")
        val repo = syncRepo(inApp)

        repo.syncServices(listOf(service(code = "1", link = "https://sub.shopfastpro.ir/sub/aaa")))
        repo.syncServices(emptyList())

        assertEquals(setOf("https://sub.sefrtasad.com/sub/mine"), inApp)
    }

    @Test
    fun aServiceTheUserRemovedFromTheAppIsNotBroughtBack() = runTest {
        val inApp = mutableSetOf<String>()
        val repo = syncRepo(inApp)
        val one = service(code = "1", link = "https://sub.shopfastpro.ir/sub/aaa")
        repo.syncServices(listOf(one))

        repo.removeFromApp("https://sub.shopfastpro.ir/sub/aaa")
        val report = repo.syncServices(listOf(one))

        assertFalse(report.changed)
        assertTrue(inApp.isEmpty())
    }

    @Test
    fun aNewLinkOnTheServerReplacesTheOldOne() = runTest {
        val inApp = mutableSetOf<String>()
        val repo = syncRepo(inApp)
        repo.syncServices(listOf(service(code = "1", link = "https://sub.sefrtasad.com/sub/old")))

        val report = repo.syncServices(listOf(service(code = "1", link = "https://sub.shopfastpro.ir/sub/new")))

        assertEquals(1, report.relinked)
        assertEquals(setOf("https://sub.shopfastpro.ir/sub/new"), inApp)
    }

    @Test
    fun aServiceOnTheNewStandardHostIsAStandardPlan() {
        val repo = newRepo(FakeBot())
        assertEquals(0, repo.kindOf(service(code = "9", plan = "50GB", link = "https://sub.shopfastpro.ir/sub/abc")))
    }

    // ---- the newer bot actions ----

    @Test
    fun trialCanBeAskedForOnAChosenPlan() = runTest {
        val bot = FakeBot().apply {
            handler = { f ->
                if (f["action"] == "trial") """{"ok":true,"service":{"code":"77","sub_link":"https://h/77"}}"""
                else """{"ok":true}"""
            }
        }
        val trial = newRepo(bot).trial("nodex").getOrThrow()

        assertEquals("77", trial?.code)
        assertEquals("nodex", bot.calls.last()["panel"])
    }

    @Test
    fun trialWithoutAPlanSendsNoPanel() = runTest {
        val bot = FakeBot().apply { handler = { """{"ok":true,"service":{"code":"1","sub_link":"https://h/1"}}""" } }
        newRepo(bot).trial()
        assertNull(bot.calls.last()["panel"])
    }

    @Test
    fun panelsTellWhichOnesHaveATrial() = runTest {
        val bot = FakeBot().apply {
            handler = {
                """{"ok":true,"panels":[
                    {"id":"pasarguard#4","panel":"std","name":"Standard","custom_enabled":true,"trial_enabled":true},
                    {"id":"nodex","panel":"omega","name":"Omega","custom_enabled":false,"trial_enabled":0}
                ]}"""
            }
        }
        val list = newRepo(bot).panels().getOrThrow()

        assertEquals(2, list.size)
        assertEquals("std", list[0].ref)
        assertEquals("STANDARD", list[0].label)
        assertTrue(list[0].trialEnabled)
        assertFalse(list[1].trialEnabled)
    }

    @Test
    fun walletHistoryAsksWithAClampedPage() = runTest {
        val bot = FakeBot().apply {
            handler = { """{"ok":true,"transactions":[{"id":5,"kind":"buy","amount":-150000,"created_at":"2026-11-04 12:30:00"}]}""" }
        }
        val list = newRepo(bot).transactions(limit = 500, offset = -3, kind = "buy").getOrThrow()

        assertEquals("100", bot.calls.last()["limit"])
        assertEquals("0", bot.calls.last()["offset"])
        assertEquals("buy", bot.calls.last()["kind"])
        assertEquals(-150000L, list.single().amount)
        assertTrue(list.single().at > 0)
    }

    @Test
    fun ticketsCanBeOpenedListedAndAnswered() = runTest {
        val bot = FakeBot().apply {
            handler = { f ->
                when (f["action"]) {
                    "ticket" -> """{"ok":true,"ticket":{"id":9}}"""
                    "tickets" -> """{"ok":true,"tickets":[{"id":3,"subject":"a"},{"id":9,"subject":"b"}]}"""
                    else -> """{"ok":true}"""
                }
            }
        }
        val repo = newRepo(bot)

        assertEquals("9", repo.openTicket("hi", "text").getOrThrow())
        assertEquals(listOf("9", "3"), repo.tickets().getOrThrow().map { it.id })
        assertTrue(repo.replyTicket("9", "more").isSuccess)
        assertEquals("9", bot.calls.last()["ticket_id"])
    }

    @Test
    fun referralAndProfileAreReadFromWhateverShapeTheBotSends() = runTest {
        val bot = FakeBot().apply {
            handler = { f ->
                when (f["action"]) {
                    "referral" -> """{"ok":true,"referral":{"link":"https://t.me/b?start=r1","clicks":4,"invited":2,"reward":30000}}"""
                    "profile" -> """{"ok":true,"balance":50000,"services":3,"api_key_state":"active"}"""
                    else -> """{"ok":true}"""
                }
            }
        }
        val repo = newRepo(bot)

        val ref = repo.referral().getOrThrow()
        assertEquals("https://t.me/b?start=r1", ref.link)
        assertEquals(2L, ref.invited)
        assertEquals(30000L, ref.reward)
        val prof = repo.profile().getOrThrow()
        assertEquals(50000L, prof.balance)
        assertEquals(3, prof.serviceCount)
    }

    @Test
    fun refreshFillsTheLiveListAndTheSyncTime() = runTest {
        val bot = FakeBot().apply {
            handler = { f ->
                when (f["action"]) {
                    "services" -> """{"ok":true,"services":[{"code":"1","sub_link":"https://h/1"}]}"""
                    "balance" -> """{"ok":true,"balance":10}"""
                    else -> """{"ok":true}"""
                }
            }
        }
        val repo = newRepo(bot)

        repo.refresh()

        assertEquals(1, repo.servicesFlow.value.size)
        assertEquals(10L, repo.balanceFlow.value)
        assertTrue(repo.lastSync.value > 0)
    }

    // ---- the sync center ----

    @Test
    fun theSyncRemembersWhatItChanged() = runTest {
        val inApp = mutableSetOf<String>()
        val repo = syncRepo(inApp)
        val one = service(code = "1", link = "https://sub.shopfastpro.ir/sub/aaa")

        repo.syncServices(listOf(one))
        repo.syncServices(emptyList())

        val kinds = repo.events.value.map { it.kind }
        assertEquals(
            listOf(AccountRepository.SyncEvent.Kind.Removed, AccountRepository.SyncEvent.Kind.Added),
            kinds,
        )
    }

    @Test
    fun aKeyIsRecognisedOnTheClipboard() {
        val repo = newRepo(FakeBot())
        assertTrue(repo.looksLikeKey("AbCdEf1234567890xyz"))
        assertFalse(repo.looksLikeKey("short"))
        assertFalse(repo.looksLikeKey("https://sub.shopfastpro.ir/sub/abcdefghijklmnop"))
        assertFalse(repo.looksLikeKey("two words here that are long enough"))
        assertFalse(repo.looksLikeKey(null))
    }

    // ---- several accounts ----

    @Test
    fun aSecondAccountKeepsItsOwnServicesAndBothStayInTheApp() = runTest {
        val inApp = mutableSetOf<String>()
        val repo = multiRepo(inApp, twoPeople())
        repo.refresh()
        assertEquals(setOf("https://h/one"), inApp)

        assertTrue(repo.addAccount("KEY999").isSuccess)
        assertEquals(2, repo.accounts.value.size)
        repo.refresh()
        assertEquals(setOf("https://h/one", "https://h/two"), inApp)

        // Back on the first account: the second one's service is not "gone", it just is not this account's.
        assertTrue(repo.switchAccount("main"))
        repo.refresh()
        assertEquals(setOf("https://h/one", "https://h/two"), inApp)
    }

    @Test
    fun theAccountsOffScreenAreSyncedInTheBackground() = runTest {
        val inApp = mutableSetOf<String>()
        val repo = multiRepo(inApp, twoPeople())
        repo.addAccount("KEY999")
        repo.switchAccount("main")
        assertTrue(inApp.isEmpty())

        repo.syncOthers(minGapSec = 0)

        assertEquals(setOf("https://h/two"), inApp)
    }

    @Test
    fun removingTheActiveAccountHandsOverToTheNextOne() = runTest {
        val store = MemoryStore()
        val repo = multiRepo(mutableSetOf(), twoPeople(), store)
        repo.addAccount("KEY999")
        val second = repo.activeId.value

        repo.removeAccount(second)

        assertEquals("main", repo.activeId.value)
        assertTrue(repo.loggedIn.value)
        assertEquals(1, repo.accounts.value.size)
        assertTrue(store.map.keys.none { it.startsWith("acc_$second") })

        repo.removeAccount("main")
        assertFalse(repo.loggedIn.value)
        assertTrue(repo.accounts.value.isEmpty())
    }

    @Test
    fun aRevokedKeySignsOutOnlyThatAccount() = runTest {
        val bot = twoPeople()
        val repo = multiRepo(mutableSetOf(), bot)
        repo.addAccount("KEY999")
        bot.handler = { """{"ok":false,"error":"invalid_api_key"}""" }

        assertTrue(repo.balance().isFailure)

        assertEquals("main", repo.activeId.value)
        assertTrue(repo.loggedIn.value)
        assertEquals(1, repo.accounts.value.size)
    }

    @Test
    fun theSameKeyCannotBeAddedTwice() = runTest {
        val repo = multiRepo(mutableSetOf(), twoPeople())
        val result = repo.addAccount("KEY123")
        assertTrue(result.isFailure)
        assertEquals(1, repo.accounts.value.size)
    }

    @Test
    fun aKeyTheBotRefusesIsNotKept() = runTest {
        val bot = FakeBot().apply { handler = { """{"ok":false,"error":"invalid_api_key"}""" } }
        val repo = multiRepo(mutableSetOf(), bot)
        assertTrue(repo.addAccount("WRONGKEY").isFailure)
        assertEquals(1, repo.accounts.value.size)
    }
}
