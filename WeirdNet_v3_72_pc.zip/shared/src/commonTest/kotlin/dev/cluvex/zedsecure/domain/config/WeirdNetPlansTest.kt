package dev.cluvex.zedsecure.domain.config

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class WeirdNetPlansTest {
    @Test
    fun newMainStandardHostIsAcceptedAndIsTheMainHost() {
        assertEquals("WEIRDNET STANDARD", WeirdNetPlans.match("https://standard.mikewave.ir/sub/abc")?.name)
        assertEquals(0, WeirdNetPlans.familyOf("https://standard.mikewave.ir/sub/abc"))
        assertEquals("standard.mikewave.ir", WeirdNetPlans.all[0].host)
    }

    @Test
    fun bothStandardHostsAreAcceptedAsStandard() {
        assertEquals("WEIRDNET STANDARD", WeirdNetPlans.match("https://sub.sefrtasad.com/sub/abc")?.name)
        assertEquals(
            "WEIRDNET STANDARD",
            WeirdNetPlans.match("https://sub.shopfastpro.ir/sub/djMsNDAxNzg4LDE3OTQwNjgxNjU.idLQ2zACCdMlBKpOTfDWfm4kwppl01jOxTlSdMBjqAY")?.name,
        )
        assertEquals(0, WeirdNetPlans.familyOf("https://sub.shopfastpro.ir/sub/abc"))
    }

    @Test
    fun otherHostsAndBareHostsAreRejected() {
        assertNull(WeirdNetPlans.match("https://shopfastpro.ir/sub/abc"))
        assertNull(WeirdNetPlans.match("https://sub.shopfastpro.ir/"))
        assertNull(WeirdNetPlans.match("https://evil@sub.shopfastpro.ir/sub/abc"))
    }
}
