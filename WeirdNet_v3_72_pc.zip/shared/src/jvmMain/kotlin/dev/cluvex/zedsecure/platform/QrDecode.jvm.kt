package dev.cluvex.zedsecure.platform

import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import java.awt.image.BufferedImage

/** Reads the text of a QR code found anywhere in [image], or null when there is none. */
object QrDecode {
    private val hints = mapOf(
        DecodeHintType.TRY_HARDER to true,
        DecodeHintType.POSSIBLE_FORMATS to listOf(com.google.zxing.BarcodeFormat.QR_CODE),
    )

    fun decode(image: BufferedImage): String? {
        val w = image.width
        val h = image.height
        if (w <= 0 || h <= 0) return null
        val pixels = IntArray(w * h)
        image.getRGB(0, 0, w, h, pixels, 0, w)
        val source = RGBLuminanceSource(w, h, pixels)
        for (bitmap in listOf(BinaryBitmap(HybridBinarizer(source)), BinaryBitmap(HybridBinarizer(source.invert())))) {
            val text = runCatching { MultiFormatReader().decode(bitmap, hints).text }.getOrNull()
            if (text != null) return text
        }
        return null
    }

    fun decode(bytes: ByteArray): String? =
        runCatching { javax.imageio.ImageIO.read(bytes.inputStream()) }.getOrNull()?.let { decode(it) }

    /** Looks for a QR code on every screen (the user has the code open in another window or app). */
    fun decodeScreens(): String? = runCatching {
        val robot = java.awt.Robot()
        java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().screenDevices.firstNotNullOfOrNull { device ->
            decode(robot.createScreenCapture(device.defaultConfiguration.bounds))
        }
    }.getOrNull()
}
