package dev.cluvex.zedsecure.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.cluvex.zedsecure.data.account.AccountRepository
import dev.cluvex.zedsecure.shared.resources.*
import dev.cluvex.zedsecure.ui.platform.LocalPlatform
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.getString
import org.jetbrains.compose.resources.stringResource

private sealed interface TopUp {
    data object Form : TopUp
    data object Starting : TopUp
    data class Waiting(val orderId: String?, val url: String, val amount: Long) : TopUp
    data class Paid(val balance: Long?) : TopUp
}

private const val MIN_TOPUP = 10_000L

private val BigCardShape = RoundedCornerShape(26.dp)

/**
 * Wallet top-up on a glass sheet, in three steps: the amount, the payment and the result. The user pays
 * on the bank page the bot gives; the sheet keeps the payment link at hand (open again, copy), watches
 * the invoice, and shows the new balance by itself when it is paid.
 */
@Composable
internal fun TopUpDialog(account: AccountRepository, onClose: () -> Unit) {
    val platform = LocalPlatform.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var amount by remember { mutableStateOf("100000") }
    var phase by remember { mutableStateOf<TopUp>(TopUp.Form) }
    var error by remember { mutableStateOf<String?>(null) }
    var checking by remember { mutableStateOf(false) }
    var notYet by remember { mutableStateOf(false) }
    val value = amount.toLongOrNull()
    val valid = value != null && value >= MIN_TOPUP

    suspend fun settle(order: String): Boolean {
        val state = account.chargeStatus(order).getOrNull()
        if (!state.equals("paid", ignoreCase = true)) return false
        val fresh = account.balance().getOrNull()
        phase = TopUp.Paid(fresh)
        return true
    }

    val waiting = phase as? TopUp.Waiting
    LaunchedEffect(waiting?.orderId) {
        val order = waiting?.orderId ?: return@LaunchedEffect
        var tries = 0
        while (tries < 225) { // about 15 minutes
            delay(4_000)
            tries++
            if (settle(order)) return@LaunchedEffect
        }
    }

    val step = when (phase) {
        is TopUp.Waiting -> 1
        is TopUp.Paid -> 2
        else -> 0
    }

    AlertDialog(
        onDismissRequest = { if (phase !is TopUp.Starting) onClose() },
        containerColor = glassDialogColor(),
        shape = GlassShape,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                GlassIcon(Res.drawable.ic_wallet, cs.primary)
                Spacer(Modifier.width(12.dp))
                Text(stringResource(Res.string.account_topup), fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                TopUpSteps(step)
                when (val p = phase) {
                    is TopUp.Paid -> PaidBody(p.balance)
                    is TopUp.Waiting -> WaitingBody(
                        waiting = p,
                        checking = checking,
                        notYet = notYet,
                        onOpen = { platform.openUri(p.url) },
                        onCopy = {
                            platform.copyToClipboard(p.url)
                            scope.launch { platform.toast(getString(Res.string.topup_copied)) }
                        },
                        onCheck = {
                            val order = p.orderId
                            if (order != null && !checking) {
                                checking = true
                                notYet = false
                                scope.launch {
                                    if (!settle(order)) notYet = true
                                    checking = false
                                }
                            }
                        },
                    )
                    else -> {
                        Text(
                            stringResource(Res.string.topup_sub),
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.onSurfaceVariant,
                        )
                        // The amount, big, like a payment app.
                        GlassCard(Modifier.fillMaxWidth(), padding = 16.dp, shape = BigCardShape) {
                            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    stringResource(Res.string.topup_pick),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = cs.onSurfaceVariant,
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    value?.let { toman(it) } ?: "0",
                                    fontSize = 36.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (valid) cs.primary else cs.error,
                                )
                                Text(
                                    stringResource(Res.string.account_toman),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = cs.onSurfaceVariant,
                                )
                            }
                        }
                        listOf(listOf(50_000L, 100_000L), listOf(200_000L, 500_000L)).forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                row.forEach { preset ->
                                    val selected = value == preset
                                    CapsuleButton(
                                        text = toman(preset),
                                        onClick = { amount = preset.toString() },
                                        container = if (selected) cs.primary else cs.surfaceContainerHighest.copy(alpha = 0.7f),
                                        content = if (selected) cs.onPrimary else cs.onSurface,
                                        modifier = Modifier.weight(1f),
                                        height = 42.dp,
                                    )
                                }
                            }
                        }
                        GlassField(
                            value = amount,
                            onValueChange = { amount = it.filter(Char::isDigit).take(9) },
                            label = stringResource(Res.string.topup_custom),
                            keyboardType = KeyboardType.Number,
                            supporting = stringResource(Res.string.topup_min),
                        )
                        error?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall) }
                        Text(
                            stringResource(Res.string.topup_secure),
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                        )
                        CapsuleButton(
                            text = if (phase is TopUp.Starting) stringResource(Res.string.topup_checking) else stringResource(Res.string.account_topup_go),
                            onClick = {
                                phase = TopUp.Starting
                                error = null
                                val pay = value ?: 0L
                                scope.launch {
                                    account.charge(pay).fold(
                                        onSuccess = { charge ->
                                            val url = charge.payUrl
                                            if (url == null) {
                                                error = getString(Res.string.account_err_generic)
                                                phase = TopUp.Form
                                            } else {
                                                platform.openUri(url)
                                                phase = TopUp.Waiting(charge.orderId, url, pay)
                                            }
                                        },
                                        onFailure = { error = errorText(it); phase = TopUp.Form },
                                    )
                                }
                            },
                            container = cs.primary,
                            content = cs.onPrimary,
                            modifier = Modifier.fillMaxWidth(),
                            enabled = valid && phase is TopUp.Form,
                            height = 52.dp,
                        )
                    }
                }
            }
        },
        confirmButton = {
            if (phase is TopUp.Paid) {
                TextButton(onClick = onClose) { Text(stringResource(Res.string.topup_close), fontWeight = FontWeight.Bold) }
            }
        },
        dismissButton = {
            if (phase !is TopUp.Paid) {
                TextButton(onClick = onClose, enabled = phase !is TopUp.Starting) { Text(stringResource(Res.string.account_close)) }
            }
        },
    )
}

/** Amount, Payment, Done: where the user is in the top-up. */
@Composable
private fun TopUpSteps(current: Int) {
    val cs = MaterialTheme.colorScheme
    val labels = listOf(
        stringResource(Res.string.topup_step_amount),
        stringResource(Res.string.topup_step_pay),
        stringResource(Res.string.topup_step_done),
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        labels.forEachIndexed { i, label ->
            val tone = when {
                i == current -> cs.primary
                i < current -> Color(0xFF3DD6A3)
                else -> cs.onSurfaceVariant.copy(alpha = 0.6f)
            }
            GlassBadge(label, tone, Modifier.weight(1f))
        }
    }
}

/** The "waiting link" state: the amount, the order, and the payment page one tap away, again and again. */
@Composable
private fun WaitingBody(
    waiting: TopUp.Waiting,
    checking: Boolean,
    notYet: Boolean,
    onOpen: () -> Unit,
    onCopy: () -> Unit,
    onCheck: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        GlassCard(Modifier.fillMaxWidth(), padding = 18.dp, shape = BigCardShape) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(modifier = Modifier.size(34.dp), strokeWidth = 3.dp)
                Spacer(Modifier.height(12.dp))
                Text(
                    stringResource(Res.string.account_topup_waiting),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    toman(waiting.amount) + " " + stringResource(Res.string.account_toman),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = cs.primary,
                )
                waiting.orderId?.let {
                    Spacer(Modifier.height(2.dp))
                    Text(
                        stringResource(Res.string.topup_order, it),
                        style = MaterialTheme.typography.labelMedium,
                        color = cs.onSurfaceVariant,
                    )
                }
            }
        }
        Text(
            stringResource(Res.string.account_topup_hint),
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        CapsuleButton(
            text = stringResource(Res.string.topup_reopen),
            onClick = onOpen,
            container = cs.primary,
            content = cs.onPrimary,
            modifier = Modifier.fillMaxWidth(),
            height = 50.dp,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            CapsuleButton(
                text = stringResource(Res.string.topup_copy),
                onClick = onCopy,
                container = cs.surfaceContainerHighest.copy(alpha = 0.8f),
                content = cs.onSurface,
                modifier = Modifier.weight(1f),
                height = 44.dp,
            )
            CapsuleButton(
                text = if (checking) stringResource(Res.string.topup_checking) else stringResource(Res.string.topup_check),
                onClick = onCheck,
                container = cs.primary.copy(alpha = 0.16f),
                content = cs.primary,
                modifier = Modifier.weight(1f),
                enabled = waiting.orderId != null && !checking,
                height = 44.dp,
            )
        }
        if (notYet) {
            Text(
                stringResource(Res.string.topup_not_yet),
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFFFB84D),
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun PaidBody(balance: Long?) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        GlassIcon(Res.drawable.ic_check_circle, Color(0xFF3DD6A3), box = 72.dp, glyph = 44.dp)
        Text(
            stringResource(Res.string.account_topup_paid),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
        )
        if (balance != null) {
            GlassCard(Modifier.fillMaxWidth(), padding = 16.dp, shape = BigCardShape) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        stringResource(Res.string.topup_new_balance),
                        style = MaterialTheme.typography.labelMedium,
                        color = cs.onSurfaceVariant,
                    )
                    Text(
                        toman(balance) + " " + stringResource(Res.string.account_toman),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = cs.primary,
                    )
                }
            }
        }
    }
}
