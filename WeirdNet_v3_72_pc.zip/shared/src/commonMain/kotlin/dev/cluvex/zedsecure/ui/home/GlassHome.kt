package dev.cluvex.zedsecure.ui.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.cluvex.zedsecure.data.net.NetworkInfo
import dev.cluvex.zedsecure.domain.model.ConnectionState
import dev.cluvex.zedsecure.shared.resources.*
import dev.cluvex.zedsecure.ui.connection.ConnectionUiState
import dev.cluvex.zedsecure.ui.format.formatBytes
import dev.cluvex.zedsecure.ui.format.formatElapsed
import dev.cluvex.zedsecure.ui.format.formatRate
import dev.cluvex.zedsecure.ui.settings.GlassCard
import dev.cluvex.zedsecure.ui.settings.GlassIcon
import dev.cluvex.zedsecure.ui.theme.BrandRose
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

private const val SECRET_TAPS = 5
private const val SECRET_WINDOW_MS = 1_200L

private class Star(val x: Float, val y: Float, val r: Float, val a: Float)

/**
 * WEIRDNET home. One idea, said quietly: the badge is the control, and the light around it tells the state.
 * Order of importance, top to bottom: the state, the one control, the server, then (only while connected)
 * how the session is going. Everything is on one 24dp column, one corner radius, one accent colour; red is
 * kept for the logo and for errors.
 */
@Composable
internal fun GlassHome(
    ui: ConnectionUiState,
    info: NetworkInfo,
    activeConfigName: String?,
    activeConfigDetail: String?,
    activeLocked: Boolean,
    lockedNote: String?,
    showConnectionInfo: Boolean,
    reduceMotion: Boolean,
    contentPadding: PaddingValues,
    onToggleConnection: () -> Unit,
    onBrowseConfigs: () -> Unit,
    onRefreshInfo: () -> Unit,
    onShowLogs: () -> Unit,
    onOpenMap: () -> Unit,
    onBuyVpn: () -> Unit,
    onBurst: () -> Unit,
    onStatusTap: () -> Unit,
    onSecretUnlocked: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.surface.luminance() < 0.5f
    val state = ui.state
    val live = state == ConnectionState.Connected
    val busy = state == ConnectionState.Connecting || state == ConnectionState.Reconnecting ||
        state == ConnectionState.Disconnecting
    val failed = state == ConnectionState.Error
    val blue = cs.primary
    val red = BrandRose

    val energy by animateFloatAsState(if (live) 1f else if (busy) 0.55f else 0.15f, tween(900), label = "energy")
    val tone by animateColorAsState(if (failed) red else blue, tween(500), label = "tone")
    val stars = remember {
        val rnd = Random(11)
        List(22) { Star(rnd.nextFloat(), rnd.nextFloat() * 0.8f, 0.5f + rnd.nextFloat() * 0.9f, 0.08f + rnd.nextFloat() * 0.18f) }
    }

    Box(
        modifier
            .fillMaxSize()
            .background(cs.surface)
            .drawBehind { brandBackdrop(blue, tone, energy, dark, stars) },
    ) {
        // Nothing scrolls: the whole home is one screen, connected or not. The connect control takes whatever
        // height the other parts leave, so a short phone gets a smaller badge instead of a longer page.
        Column(
            Modifier
                .fillMaxSize()
                .padding(
                    top = contentPadding.calculateTopPadding() + 4.dp,
                    bottom = contentPadding.calculateBottomPadding() + 8.dp,
                    start = 24.dp,
                    end = 24.dp,
                ),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            BrandHeader(onSecretUnlocked = onSecretUnlocked, onShowLogs = onShowLogs)

            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                val target = minOf(maxWidth, maxHeight - 8.dp, 248.dp).coerceAtLeast(96.dp)
                val diameter by animateDpAsState(target, spring(dampingRatio = 0.85f, stiffness = 300f), label = "reactor-size")
                Reactor(
                    state = state,
                    diameter = diameter,
                    tone = tone,
                    energy = energy,
                    reduceMotion = reduceMotion,
                    onClick = {
                        onBurst()
                        onToggleConnection()
                    },
                )
            }

            val title = when (state) {
                ConnectionState.Idle -> stringResource(Res.string.state_idle)
                ConnectionState.Connecting -> stringResource(Res.string.state_connecting)
                ConnectionState.Connected -> stringResource(Res.string.state_connected)
                ConnectionState.Reconnecting -> stringResource(Res.string.state_reconnecting)
                ConnectionState.Disconnecting -> stringResource(Res.string.state_disconnecting)
                ConnectionState.Error -> stringResource(Res.string.state_error)
            }
            Column(
                Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onStatusTap),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(title, fontSize = 28.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, textAlign = TextAlign.Center)
                when {
                    live -> Text(
                        formatElapsed(ui.elapsedSeconds),
                        fontSize = 17.sp,
                        fontFamily = FontFamily.Monospace,
                        color = cs.onSurfaceVariant,
                    )
                    failed -> Text(
                        ui.error?.take(90).orEmpty(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = red,
                        textAlign = TextAlign.Center,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    state == ConnectionState.Idle -> Text(
                        stringResource(Res.string.home_glass_tap),
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            ServerCard(
                name = activeConfigName ?: stringResource(Res.string.home_select_config),
                detail = (if (activeLocked) lockedNote else null) ?: activeConfigDetail ?: stringResource(Res.string.home_tap_to_change),
                accent = blue,
                onClick = onBrowseConfigs,
            )

            AnimatedVisibility(
                visible = live,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically(),
            ) {
                Column {
                    Spacer(Modifier.height(12.dp))
                    SessionCard(ui = ui, info = info, showExit = showConnectionInfo, blue = blue, red = red, onRefresh = onRefreshInfo)
                }
            }
        }
    }
}

/** Deep space with one blue light high up and the planet's rim along the bottom edge. */
private fun DrawScope.brandBackdrop(blue: Color, tone: Color, energy: Float, dark: Boolean, stars: List<Star>) {
    drawRect(
        Brush.radialGradient(
            listOf(tone.copy(alpha = 0.14f + 0.26f * energy), Color.Transparent),
            center = Offset(size.width * 0.5f, size.height * 1.10f),
            radius = size.width * 1.2f,
        ),
    )
    drawRect(
        Brush.radialGradient(
            listOf(blue.copy(alpha = 0.06f + 0.14f * energy), Color.Transparent),
            center = Offset(size.width * 0.5f, size.height * 0.28f),
            radius = size.width * 0.9f,
        ),
    )
    if (dark) {
        stars.forEach { s ->
            drawCircle(Color.White.copy(alpha = s.a), s.r.dp.toPx(), Offset(s.x * size.width, s.y * size.height))
        }
    }
}

/** The wordmark and the slogan, left-aligned and quiet, with the logs as a bare icon. Five quick taps on the name unlock the vault. */
@Composable
private fun BrandHeader(onSecretUnlocked: () -> Unit, onShowLogs: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.surface.luminance() < 0.5f
    val haptics = LocalHapticFeedback.current
    var taps by remember { mutableIntStateOf(0) }
    var lastTap by remember { mutableLongStateOf(0L) }
    val chrome = if (dark) {
        Brush.linearGradient(listOf(Color(0xFFFFFFFF), Color(0xFFA9C2E6), Color(0xFFEAF2FF)))
    } else {
        Brush.linearGradient(listOf(Color(0xFF0B2A66), cs.primary))
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = stringResource(Res.string.app_name),
                style = MaterialTheme.typography.titleLarge.copy(
                    brush = chrome,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 4.sp,
                ),
                maxLines = 1,
                modifier = Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                    val now = System.currentTimeMillis()
                    taps = if (now - lastTap < SECRET_WINDOW_MS) taps + 1 else 1
                    lastTap = now
                    if (taps >= SECRET_TAPS) {
                        taps = 0
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        onSecretUnlocked()
                    }
                },
            )
            Text(
                text = stringResource(Res.string.app_slogan),
                fontSize = 12.sp,
                color = cs.primary.copy(alpha = 0.9f),
                maxLines = 1,
            )
        }
        Box(
            Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onShowLogs),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                painterResource(Res.drawable.ic_description),
                contentDescription = stringResource(Res.string.logs_title),
                tint = cs.onSurfaceVariant,
                modifier = Modifier.size(22.dp),
            )
        }
    }
}

/**
 * The connect control: the badge, inside one thin ring. Idle the ring is only a track; connecting, one arc
 * circles it; connected, it closes into a glowing circle that breathes slowly; on error it turns red.
 */
@Composable
private fun Reactor(
    state: ConnectionState,
    diameter: Dp,
    tone: Color,
    energy: Float,
    reduceMotion: Boolean,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val haptics = LocalHapticFeedback.current
    val live = state == ConnectionState.Connected
    val busy = state == ConnectionState.Connecting || state == ConnectionState.Reconnecting ||
        state == ConnectionState.Disconnecting
    val failed = state == ConnectionState.Error

    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.96f else 1f,
        spring(dampingRatio = 0.6f, stiffness = 400f),
        label = "reactor-press",
    )

    // Each loop runs only while it is visible: the arc while connecting, the glow while connected. Nothing
    // keeps the GPU busy when idle, in the background or with the animation budget paused.
    val budget = dev.cluvex.zedsecure.ui.theme.LocalMotionBudget.current
    val loops = !reduceMotion && budget != dev.cluvex.zedsecure.ui.theme.MotionBudget.Paused
    val spinState = if (busy && loops) {
        rememberInfiniteTransition(label = "reactor-spin").animateFloat(
            0f, 360f, infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Restart), label = "spin",
        )
    } else {
        remember { mutableFloatStateOf(0f) }
    }
    val breathState = if (live && loops) {
        rememberInfiniteTransition(label = "reactor-breath").animateFloat(
            0f, 1f, infiniteRepeatable(tween(2600, easing = androidx.compose.animation.core.FastOutSlowInEasing), RepeatMode.Reverse), label = "breath",
        )
    } else {
        remember { mutableFloatStateOf(0.5f) }
    }
    val spin by spinState
    val breath by breathState

    Box(
        Modifier
            .size(diameter)
            .clip(CircleShape)
            .semantics { contentDescription = "connect" }
            .clickable(interactionSource = source, indication = null, role = Role.Button) {
                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val radius = size.minDimension / 2f
            val ringR = radius - 6.dp.toPx()
            val stroke = 3.dp.toPx()
            val pulse = if (reduceMotion) 0.5f else breath

            drawCircle(
                Brush.radialGradient(
                    listOf(tone.copy(alpha = (0.06f + 0.22f * pulse) * energy + 0.04f), Color.Transparent),
                    center = c,
                    radius = radius,
                ),
                radius,
                c,
            )

            drawCircle(cs.onSurface.copy(alpha = 0.10f), ringR, c, style = Stroke(stroke))

            when {
                live -> {
                    drawCircle(tone.copy(alpha = 0.10f + 0.08f * pulse), ringR, c, style = Stroke(stroke * 4.5f))
                    drawCircle(tone.copy(alpha = 0.22f), ringR, c, style = Stroke(stroke * 2.2f))
                    drawCircle(tone, ringR, c, style = Stroke(stroke, cap = StrokeCap.Round))
                }
                busy -> rotate(if (reduceMotion) 0f else spin, c) {
                    drawArc(
                        tone, 0f, 80f, false,
                        Offset(c.x - ringR, c.y - ringR), Size(ringR * 2, ringR * 2),
                        style = Stroke(stroke, cap = StrokeCap.Round),
                    )
                }
                failed -> drawCircle(tone.copy(alpha = 0.9f), ringR, c, style = Stroke(stroke))
            }
        }

        // The badge: it is the brand, and it is the button.
        Image(
            painterResource(Res.drawable.ic_weirdnet_home),
            contentDescription = null,
            alpha = if (busy) 0.85f else 1f,
            modifier = Modifier
                .size(diameter * 0.79f)
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .clip(CircleShape),
        )
    }
}

@Composable
private fun ServerCard(name: String, detail: String, accent: Color, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    GlassCard(Modifier.fillMaxWidth(), padding = 16.dp, shape = RoundedCornerShape(24.dp), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GlassIcon(Res.drawable.ic_dns, accent)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    detail,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Icon(
                painterResource(Res.drawable.ic_chevron_right),
                contentDescription = null,
                tint = cs.onSurfaceVariant,
                modifier = Modifier.size(22.dp),
            )
        }
    }
}

/** One card for the running session: the speeds and totals, then (if enabled) where it comes out. */
@Composable
private fun SessionCard(
    ui: ConnectionUiState,
    info: NetworkInfo,
    showExit: Boolean,
    blue: Color,
    red: Color,
    onRefresh: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    GlassCard(Modifier.fillMaxWidth(), padding = 14.dp, shape = RoundedCornerShape(24.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            RateColumn(Res.drawable.ic_arrow_downward, stringResource(Res.string.home_download), ui.downloadBps, ui.totalDownload, blue, Modifier.weight(1f))
            RateColumn(Res.drawable.ic_arrow_upward, stringResource(Res.string.home_upload), ui.uploadBps, ui.totalUpload, red, Modifier.weight(1f))
        }
        if (showExit) {
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(cs.onSurface.copy(alpha = 0.08f)))
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.fillMaxWidth().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onRefresh),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ExitCell(
                    stringResource(Res.string.home_glass_place),
                    listOfNotNull(info.city, info.country).joinToString(", ").ifBlank { if (info.loading) "…" else "—" },
                    Modifier.weight(1.3f),
                )
                ExitCell(
                    stringResource(Res.string.home_glass_ip),
                    info.ipv4 ?: if (info.loading) "…" else "—",
                    Modifier.weight(1.2f),
                )
                ExitCell(
                    stringResource(Res.string.map_ping),
                    info.pingMs?.let { "$it ms" } ?: if (info.pingLoading) "…" else "—",
                    Modifier.weight(0.8f),
                )
            }
        }
    }
}

@Composable
private fun RateColumn(icon: DrawableResource, label: String, bps: Long, total: Long, accent: Color, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val (value, unit) = formatRate(bps)
    Column(modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(painterResource(icon), contentDescription = null, tint = accent, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text(label, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
        }
        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(unit, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 4.dp))
        }
        Text(formatBytes(total), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
    }
}

@Composable
private fun ExitCell(label: String, value: String, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    Column(modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1)
        Text(
            value,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
