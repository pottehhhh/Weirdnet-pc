package dev.cluvex.zedsecure.ui.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.cluvex.zedsecure.data.account.AccountRepository
import dev.cluvex.zedsecure.shared.resources.*
import dev.cluvex.zedsecure.ui.platform.LocalPlatform
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.getString
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

/** "My services": every service of the account, its usage and expiry, opened from My account or Support. */
@Composable
internal fun ServicesPage(
    account: AccountRepository,
    contentPadding: PaddingValues,
    modifier: Modifier,
    onOpen: (SettingsPage) -> Unit,
) {
    val loggedIn by account.loggedIn.collectAsState()
    SettingsPageScaffold(
        title = stringResource(Res.string.svc_page_title),
        art = SettingsArts.Services,
        subtitle = stringResource(Res.string.svc_page_sub),
        contentPadding = contentPadding,
        modifier = modifier,
    ) {
        if (!loggedIn) LoginSection(account) else GlassPage { ServicesContent(account, onOpen) }
    }
}

internal fun isServiceActive(svc: AccountRepository.Service): Boolean {
    val left = daysLeft(svc.expiryMs)
    val expired = left != null && left < 0
    return !expired && svc.enabled != false && (svc.status == null || svc.status == "active")
}

@Composable
private fun ServicesContent(account: AccountRepository, onOpen: (SettingsPage) -> Unit) {
    val platform = LocalPlatform.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val services by account.servicesFlow.collectAsState()
    val offline by account.offline.collectAsState()
    var reload by remember { mutableStateOf(0) }
    var loading by remember { mutableStateOf(true) }
    var inAppTick by remember { mutableStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }
    var filter by remember { mutableStateOf(0) }
    var detail by remember { mutableStateOf<AccountRepository.Service?>(null) }
    var confirmDelete by remember { mutableStateOf<AccountRepository.Service?>(null) }
    var finalDelete by remember { mutableStateOf<AccountRepository.Service?>(null) }
    var deleting by remember { mutableStateOf(false) }
    var renewing by remember { mutableStateOf<AccountRepository.Service?>(null) }

    // While the server cannot be reached, keep asking until it answers.
    LaunchedEffect(offline) {
        while (offline) {
            delay(3_000)
            reload++
        }
    }

    // While this page is open the bot is asked every few seconds, so a purchase or a deleted service
    // shows up here (and in the server list) without touching anything.
    LaunchedEffect(Unit) {
        while (true) {
            delay(20_000)
            if (account.refresh().changed) inAppTick++
        }
    }

    LaunchedEffect(reload) {
        loading = true
        account.services().fold(
            onSuccess = { list ->
                val report = account.syncServices(list)
                if (report.changed) {
                    message = getString(Res.string.account_added_auto)
                    inAppTick++
                }
            },
            onFailure = { message = errorText(it) },
        )
        loading = false
    }

    suspend fun addService(svc: AccountRepository.Service) {
        if (svc.subLink == null) {
            message = getString(Res.string.account_no_link)
            return
        }
        val r = account.addService(svc)
        message = if (r.isSuccess) getString(Res.string.account_added) else getString(Res.string.account_add_failed)
        inAppTick++
    }

    val activeCount = services.count { isServiceActive(it) }
    val leftBytes = services
        .filter { !isUnlimitedService(it) && it.totalBytes != null && it.usedBytes != null }
        .sumOf { ((it.totalBytes ?: 0L) - (it.usedBytes ?: 0L)).coerceAtLeast(0L) }
    val hasVolume = services.any { !isUnlimitedService(it) && it.totalBytes != null && it.usedBytes != null }
    val shown = when (filter) {
        1 -> services.filter { isServiceActive(it) }
        2 -> services.filter { !isServiceActive(it) }
        else -> services
    }

    Column(
        Modifier.padding(top = 14.dp, bottom = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        if (offline) GlassNotice(stringResource(Res.string.account_offline), Modifier.padding(horizontal = 16.dp), tone = Color(0xFFFFB84D))
        message?.let { m -> GlassNotice(m, Modifier.padding(horizontal = 16.dp), onClick = { message = null }) }

        AttentionNotice(services, Modifier.padding(horizontal = 16.dp)) { filter = 1 }

        // Summary
        GlassCard(Modifier.padding(horizontal = 16.dp).fillMaxWidth(), padding = 18.dp) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                SummaryStat(stringResource(Res.string.svc_stat_active), activeCount.toString(), planAccent(0), Modifier.weight(1f))
                SummaryStat(stringResource(Res.string.svc_stat_total), services.size.toString(), planAccent(1), Modifier.weight(1f))
                SummaryStat(
                    stringResource(Res.string.svc_stat_left),
                    if (hasVolume) gbText(leftBytes) + " GB" else "—",
                    planAccent(3),
                    Modifier.weight(1f),
                )
            }
        }

        // Filters
        if (services.isNotEmpty()) {
            Row(
                Modifier.padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                GlassChip(stringResource(Res.string.svc_filter_all), filter == 0, { filter = 0 })
                GlassChip(stringResource(Res.string.svc_filter_active), filter == 1, { filter = 1 })
                GlassChip(stringResource(Res.string.svc_filter_expired), filter == 2, { filter = 2 })
            }
        }

        // List
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (services.isEmpty()) {
                GlassCard(Modifier.fillMaxWidth(), padding = 24.dp) {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        if (loading) {
                            Text("…", style = MaterialTheme.typography.titleLarge, color = cs.onSurfaceVariant)
                        } else {
                            GlassIcon(Res.drawable.ic_inventory, cs.primary, box = 56.dp, glyph = 30.dp)
                            Spacer(Modifier.height(12.dp))
                            Text(
                                stringResource(Res.string.svc_empty_title),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.Center,
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                stringResource(Res.string.svc_empty_sub),
                                style = MaterialTheme.typography.bodyMedium,
                                color = cs.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
            } else if (shown.isEmpty()) {
                GlassCard(Modifier.fillMaxWidth()) {
                    Text(stringResource(Res.string.svc_empty_filter), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                }
            }
            shown.forEach { svc ->
                val tick = inAppTick
                ServiceGlassCard(svc, kind = account.kindOf(svc), inApp = tick >= 0 && svc.subLink?.let { account.isInApp(it) } == true) {
                    detail = svc
                    // Replace the list data with live data as soon as it arrives.
                    scope.launch {
                        account.status(svc.code).onSuccess { live ->
                            if (detail?.code == svc.code) detail = live.copy(subLink = live.subLink ?: svc.subLink)
                        }
                    }
                }
            }
        }

        CapsuleButton(
            text = stringResource(Res.string.svc_buy_more),
            onClick = { onOpen(SettingsPage.Buy) },
            container = cs.primary,
            content = cs.onPrimary,
            modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
            height = 52.dp,
        )
    }

    detail?.let { svc ->
        val tick = inAppTick
        val inApp = tick >= 0 && svc.subLink?.let { account.isInApp(it) } == true
        AlertDialog(
            onDismissRequest = { detail = null },
            containerColor = glassDialogColor(),
            shape = GlassShape,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PlanBadge(account.kindOf(svc))
                    Text(svc.email ?: svc.code, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    StatusChip(svc)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    svc.plan?.let { Text(it, color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium) }
                    ServiceStats(svc)
                    svc.subLink?.let { link ->
                        if (inApp) {
                            CapsuleButton(
                                text = stringResource(Res.string.account_remove_from_app),
                                onClick = { account.removeFromApp(link); inAppTick++; message = null; detail = null },
                                container = cs.primary.copy(alpha = 0.16f),
                                content = cs.primary,
                                modifier = Modifier.fillMaxWidth(),
                                height = 46.dp,
                            )
                        } else {
                            CapsuleButton(
                                text = stringResource(Res.string.account_add_to_app),
                                onClick = { detail = null; scope.launch { addService(svc) } },
                                container = cs.primary,
                                content = cs.onPrimary,
                                modifier = Modifier.fillMaxWidth(),
                                height = 46.dp,
                            )
                        }
                        CapsuleButton(
                            text = stringResource(Res.string.svc_copy_link),
                            onClick = {
                                platform.copyToClipboard(link)
                                scope.launch { platform.toast(getString(Res.string.svc_link_copied)) }
                            },
                            container = cs.surfaceContainerHighest.copy(alpha = 0.8f),
                            content = cs.onSurface,
                            modifier = Modifier.fillMaxWidth(),
                            height = 46.dp,
                        )
                    }
                    if (RENEW_ENABLED) CapsuleButton(
                        text = stringResource(Res.string.renew_button),
                        onClick = { renewing = svc; detail = null },
                        container = Color(0xFF34C759).copy(alpha = 0.18f),
                        content = Color(0xFF34C759),
                        modifier = Modifier.fillMaxWidth(),
                        height = 46.dp,
                        enabled = !offline,
                    )
                    HorizontalDivider(color = cs.outlineVariant)
                    OutlinedButton(
                        onClick = { confirmDelete = svc; detail = null },
                        modifier = Modifier.fillMaxWidth().height(46.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = cs.error),
                        border = BorderStroke(1.dp, cs.error.copy(alpha = 0.6f)),
                    ) { Text(stringResource(Res.string.account_delete)) }
                }
            },
            confirmButton = { TextButton(onClick = { detail = null }) { Text(stringResource(Res.string.account_close)) } },
        )
    }

    renewing?.let { svc ->
        RenewDialog(account, svc) { renewed ->
            renewing = null
            if (renewed) { reload++; inAppTick++ }
        }
    }

    // Deleting is permanent, so it takes two separate warnings. The first lists what is lost; the second
    // makes the final button wait three seconds before it can be pressed.
    confirmDelete?.let { svc ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            containerColor = glassDialogColor(),
            shape = GlassShape,
            title = { Text(stringResource(Res.string.del_warn1_title), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(svc.email ?: svc.code, fontWeight = FontWeight.SemiBold)
                    Text(stringResource(Res.string.del_warn1_intro), color = cs.onSurfaceVariant)
                    listOf(
                        Res.string.del_warn1_a, Res.string.del_warn1_b,
                        Res.string.del_warn1_c, Res.string.del_warn1_d,
                    ).forEach { line ->
                        Row(verticalAlignment = Alignment.Top) {
                            Text("•  ", color = cs.error, fontWeight = FontWeight.Bold)
                            Text(stringResource(line), style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { finalDelete = svc; confirmDelete = null }) {
                    Text(stringResource(Res.string.del_continue), color = cs.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text(stringResource(Res.string.del_keep)) } },
        )
    }

    finalDelete?.let { svc ->
        var left by remember(svc.code) { mutableStateOf(3) }
        LaunchedEffect(svc.code) {
            while (left > 0) {
                delay(1_000)
                left--
            }
        }
        AlertDialog(
            onDismissRequest = { if (!deleting) finalDelete = null },
            containerColor = glassDialogColor(),
            shape = GlassShape,
            icon = { GlassIcon(Res.drawable.ic_delete, cs.error, box = 56.dp, glyph = 30.dp) },
            title = { Text(stringResource(Res.string.del_warn2_title), fontWeight = FontWeight.Bold, color = cs.error, textAlign = TextAlign.Center) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(svc.email ?: svc.code, fontWeight = FontWeight.SemiBold)
                    Text(stringResource(Res.string.del_warn2_body), color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !deleting && left <= 0,
                    onClick = {
                        deleting = true
                        scope.launch {
                            account.delete(svc.code).fold(
                                onSuccess = {
                                    svc.subLink?.let { account.removeFromApp(it) }
                                    message = getString(Res.string.account_deleted)
                                    inAppTick++
                                    reload++
                                },
                                onFailure = { message = errorText(it) },
                            )
                            deleting = false
                            finalDelete = null
                        }
                    },
                ) {
                    Text(
                        if (left > 0) stringResource(Res.string.del_wait, left) else stringResource(Res.string.del_final),
                        color = if (left > 0) cs.onSurfaceVariant else cs.error,
                        fontWeight = FontWeight.Bold,
                    )
                }
            },
            dismissButton = { TextButton(enabled = !deleting, onClick = { finalDelete = null }) { Text(stringResource(Res.string.del_keep)) } },
        )
    }
}

@Composable
private fun SummaryStat(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = accent, maxLines = 1)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}


/** Renewal is switched off: the bot's renewal rules (e.g. 30–90 days) don't match what the API offers. Set to true to bring it back. */
private const val RENEW_ENABLED = false
