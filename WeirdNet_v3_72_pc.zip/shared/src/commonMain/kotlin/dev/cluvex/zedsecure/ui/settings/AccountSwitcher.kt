package dev.cluvex.zedsecure.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.cluvex.zedsecure.data.account.AccountRepository
import dev.cluvex.zedsecure.shared.resources.*
import dev.cluvex.zedsecure.ui.platform.LocalPlatform
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

@Composable
private fun accountName(entry: AccountRepository.AccountEntry?, index: Int): String =
    entry?.label?.takeIf { it.isNotBlank() } ?: stringResource(Res.string.account_multi_default, index.toString())

@Composable
private fun AccountAvatar(name: String, index: Int, size: androidx.compose.ui.unit.Dp = 44.dp) {
    val accent = planAccent(index % 4)
    Box(
        Modifier.size(size).clip(CircleShape).background(accent.copy(alpha = 0.20f)),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            name.firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "•",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = accent,
        )
    }
}

private sealed interface AccountsMode {
    data object Listing : AccountsMode
    data object Adding : AccountsMode
    data class Renaming(val id: String) : AccountsMode
    data class Removing(val id: String) : AccountsMode
}

/**
 * Who is signed in. Shows the account on screen; a tap opens the list to switch, add, rename or remove one.
 * [onChanged] runs after anything that makes the screen's data stale (a switch, an added or removed account).
 */
@Composable
internal fun AccountSwitcherCard(account: AccountRepository, onChanged: () -> Unit, modifier: Modifier = Modifier) {
    val accounts by account.accounts.collectAsState()
    val activeId by account.activeId.collectAsState()
    var open by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    val index = accounts.indexOfFirst { it.id == activeId }.coerceAtLeast(0)
    val active = accounts.getOrNull(index)
    val name = accountName(active, index + 1)

    GlassCard(modifier.fillMaxWidth(), padding = 14.dp, shape = RoundedCornerShape(26.dp), onClick = { open = true }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AccountAvatar(name, index)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(
                    if (accounts.size > 1) stringResource(Res.string.account_multi_count, accounts.size.toString())
                    else stringResource(Res.string.account_multi_single),
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 1,
                )
            }
            Icon(
                painterResource(Res.drawable.ic_expand_more),
                contentDescription = null,
                tint = cs.onSurfaceVariant,
                modifier = Modifier.size(22.dp),
            )
        }
    }

    if (open) AccountsDialog(account, onClose = { open = false }, onChanged = onChanged)
}

@Composable
private fun AccountsDialog(account: AccountRepository, onClose: () -> Unit, onChanged: () -> Unit) {
    val platform = LocalPlatform.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val accounts by account.accounts.collectAsState()
    val activeId by account.activeId.collectAsState()
    var mode by remember { mutableStateOf<AccountsMode>(AccountsMode.Listing) }
    var key by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var clip by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(mode) {
        if (mode is AccountsMode.Adding) {
            clip = runCatching { platform.readClipboard() }.getOrNull()?.trim()?.takeIf { account.looksLikeKey(it) }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onClose() },
        containerColor = glassDialogColor(),
        shape = GlassShape,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                GlassIcon(Res.drawable.ic_person, cs.primary)
                Spacer(Modifier.width(12.dp))
                Text(stringResource(Res.string.account_multi_title), fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (val m = mode) {
                    AccountsMode.Listing -> {
                        accounts.forEachIndexed { i, entry ->
                            val label = accountName(entry, i + 1)
                            val isActive = entry.id == activeId
                            GlassCard(
                                Modifier.fillMaxWidth(),
                                padding = 12.dp,
                                shape = RoundedCornerShape(22.dp),
                                onClick = {
                                    if (!isActive && account.switchAccount(entry.id)) onChanged()
                                    onClose()
                                },
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    AccountAvatar(label, i, size = 40.dp)
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                                        Text(label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                        Text(
                                            listOfNotNull(
                                                "••••" + entry.keyHint,
                                                entry.balance?.let { toman(it) + " " + stringResource(Res.string.account_toman) },
                                            ).joinToString(" · "),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = cs.onSurfaceVariant,
                                            maxLines = 1,
                                        )
                                    }
                                    if (isActive) GlassBadge(stringResource(Res.string.account_multi_active), planAccent(0))
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                    TextButton(onClick = { name = entry.label; error = null; mode = AccountsMode.Renaming(entry.id) }) {
                                        Text(stringResource(Res.string.account_multi_rename))
                                    }
                                    TextButton(onClick = { mode = AccountsMode.Removing(entry.id) }) {
                                        Text(stringResource(Res.string.account_multi_remove), color = cs.error)
                                    }
                                }
                            }
                        }
                        CapsuleButton(
                            text = stringResource(Res.string.account_multi_add),
                            onClick = { key = ""; error = null; mode = AccountsMode.Adding },
                            container = cs.primary,
                            content = cs.onPrimary,
                            modifier = Modifier.fillMaxWidth(),
                            height = 48.dp,
                        )
                        Text(
                            stringResource(Res.string.account_multi_note),
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                        )
                    }

                    AccountsMode.Adding -> {
                        GlassField(
                            value = key,
                            onValueChange = { key = it.filter { c -> !c.isWhitespace() }.take(256); error = null },
                            label = stringResource(Res.string.account_key_label),
                            mono = true,
                        )
                        clip?.let { found ->
                            if (key.isBlank()) {
                                CapsuleButton(
                                    text = stringResource(Res.string.account_multi_clip),
                                    onClick = { key = found },
                                    container = cs.primary.copy(alpha = 0.14f),
                                    content = cs.primary,
                                    modifier = Modifier.fillMaxWidth(),
                                    height = 44.dp,
                                )
                            }
                        }
                        error?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall) }
                        CapsuleButton(
                            text = if (busy) stringResource(Res.string.topup_checking) else stringResource(Res.string.account_multi_add),
                            onClick = {
                                busy = true
                                scope.launch {
                                    account.addAccount(key).fold(
                                        onSuccess = { busy = false; onChanged(); onClose() },
                                        onFailure = { error = errorText(it); busy = false },
                                    )
                                }
                            },
                            container = cs.primary,
                            content = cs.onPrimary,
                            modifier = Modifier.fillMaxWidth(),
                            enabled = key.isNotBlank() && !busy,
                            height = 48.dp,
                        )
                    }

                    is AccountsMode.Renaming -> {
                        GlassField(
                            value = name,
                            onValueChange = { name = it.take(24) },
                            label = stringResource(Res.string.account_multi_name),
                        )
                        CapsuleButton(
                            text = stringResource(Res.string.account_multi_save),
                            onClick = { account.renameAccount(m.id, name); mode = AccountsMode.Listing },
                            container = cs.primary,
                            content = cs.onPrimary,
                            modifier = Modifier.fillMaxWidth(),
                            height = 48.dp,
                        )
                    }

                    is AccountsMode.Removing -> {
                        Text(stringResource(Res.string.account_multi_remove_q), style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(2.dp))
                        CapsuleButton(
                            text = stringResource(Res.string.account_multi_remove),
                            onClick = {
                                val wasOnly = accounts.size <= 1
                                account.removeAccount(m.id)
                                onChanged()
                                if (wasOnly) onClose() else mode = AccountsMode.Listing
                            },
                            container = cs.error.copy(alpha = 0.16f),
                            content = cs.error,
                            modifier = Modifier.fillMaxWidth(),
                            height = 48.dp,
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (mode == AccountsMode.Listing) onClose() else { error = null; mode = AccountsMode.Listing } }) {
                Text(
                    if (mode == AccountsMode.Listing) stringResource(Res.string.account_multi_close)
                    else stringResource(Res.string.account_multi_cancel),
                )
            }
        },
    )
}
