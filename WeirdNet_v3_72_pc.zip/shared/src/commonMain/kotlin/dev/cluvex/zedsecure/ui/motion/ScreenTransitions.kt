package dev.cluvex.zedsecure.ui.motion

import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.EnterExitState
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import dev.cluvex.zedsecure.domain.model.ScreenTransition
import kotlin.math.abs

/** Material "emphasized" curves: a quick start that settles softly. One set for every screen change. */
private val Emphasized = CubicBezierEasing(0.2f, 0f, 0f, 1f)
private val EmphasizedAccelerate = CubicBezierEasing(0.3f, 0f, 0.8f, 0.15f)

private const val ENTER_MS = 320
private const val EXIT_MS = 220

/** The leaving screen fades quickly, the arriving one waits a moment, so the two never blur into each other. */
private fun fadeInSoft() = fadeIn(tween(200, delayMillis = 70, easing = LinearOutSlowInEasing))
private fun fadeOutQuick() = fadeOut(tween(110, easing = LinearEasing))

fun screenTransition(
    style: ScreenTransition,
    forward: Boolean,

    direction: Int = 1,

    reduceMotion: Boolean = false,
): ContentTransform {
    if (reduceMotion) return fadeIn(tween(120)) togetherWith fadeOut(tween(90))
    val sign = (if (forward) 1 else -1) * direction
    return when (style) {
        ScreenTransition.Fade -> fadeInSoft() togetherWith fadeOutQuick()

        ScreenTransition.Slide ->
            (slideInHorizontally(tween(ENTER_MS, easing = Emphasized)) { w -> sign * w / 4 } + fadeInSoft()) togetherWith
                (slideOutHorizontally(tween(EXIT_MS, easing = EmphasizedAccelerate)) { w -> -sign * w / 4 } + fadeOutQuick())

        ScreenTransition.Push ->
            (slideInHorizontally(tween(ENTER_MS + 20, easing = Emphasized)) { w -> sign * w } + fadeIn(tween(90))) togetherWith
                (slideOutHorizontally(tween(ENTER_MS + 20, easing = Emphasized)) { w -> -sign * w / 4 } +
                    fadeOut(tween(220, delayMillis = 100, easing = LinearEasing)))

        ScreenTransition.Depth -> if (forward) {
            (scaleIn(tween(ENTER_MS, easing = Emphasized), initialScale = 0.9f) + fadeInSoft()) togetherWith
                (scaleOut(tween(EXIT_MS, easing = EmphasizedAccelerate), targetScale = 1.1f) + fadeOutQuick())
        } else {
            (scaleIn(tween(ENTER_MS, easing = Emphasized), initialScale = 1.1f) + fadeInSoft()) togetherWith
                (scaleOut(tween(EXIT_MS, easing = EmphasizedAccelerate), targetScale = 0.9f) + fadeOutQuick())
        }

        // A soft spring with only a hint of overshoot: it lands without the content shaking at the end.
        ScreenTransition.Elastic ->
            (
                slideInVertically(
                    spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMediumLow),
                ) { h -> h / 10 } +
                    scaleIn(
                        spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMediumLow),
                        initialScale = 0.94f,
                    ) + fadeInSoft()
                ) togetherWith
                (scaleOut(tween(EXIT_MS, easing = EmphasizedAccelerate), targetScale = 0.97f) + fadeOutQuick())

        ScreenTransition.Curtain -> if (forward) {
            (slideInVertically(tween(ENTER_MS + 40, easing = Emphasized)) { h -> h / 2 } + fadeIn(tween(160))) togetherWith
                (scaleOut(tween(ENTER_MS + 40, easing = Emphasized), targetScale = 0.95f) + fadeOut(tween(240, delayMillis = 60, easing = LinearEasing)))
        } else {
            (scaleIn(tween(ENTER_MS + 40, easing = Emphasized), initialScale = 0.95f) + fadeIn(tween(200))) togetherWith
                (slideOutVertically(tween(EXIT_MS + 60, easing = EmphasizedAccelerate)) { h -> h / 2 } + fadeOut(tween(240, delayMillis = 60, easing = LinearEasing)))
        }

        ScreenTransition.Flip -> fadeIn(tween(220, delayMillis = 90, easing = LinearOutSlowInEasing)) togetherWith fadeOut(tween(140, easing = LinearEasing))
    }
}

@Composable
fun AnimatedVisibilityScope.transitionDecoration(
    style: ScreenTransition,
    forward: Boolean,
    direction: Int = 1,
    reduceMotion: Boolean = false,
): Modifier {
    if (style != ScreenTransition.Flip || reduceMotion) return Modifier
    val sign = (if (forward) 1 else -1) * direction
    val angle by transition.animateFloat(
        transitionSpec = { tween(360, easing = Emphasized) },
        label = "flip-angle",
    ) { state ->
        when (state) {
            EnterExitState.PreEnter -> 78f * sign
            EnterExitState.Visible -> 0f
            EnterExitState.PostExit -> -78f * sign
        }
    }
    return Modifier.graphicsLayer {
        rotationY = angle

        cameraDistance = 14f * density
        transformOrigin = TransformOrigin(if (sign > 0) 0.15f else 0.85f, 0.5f)

        alpha = 1f - (abs(angle) / 110f)
    }
}

@Composable
fun layoutSign(): Int = if (LocalLayoutDirection.current == LayoutDirection.Rtl) -1 else 1
