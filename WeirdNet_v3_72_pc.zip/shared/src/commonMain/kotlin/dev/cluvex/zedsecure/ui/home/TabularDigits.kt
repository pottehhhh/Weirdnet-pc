package dev.cluvex.zedsecure.ui.home

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString

private const val TABULAR = "tnum"

/** Digits with fixed width, so a ticking number does not make the text next to it jump. */
internal fun tabularDigits(text: String): AnnotatedString = buildAnnotatedString {
    var start = 0
    while (start < text.length) {
        val digits = text[start].isDigit()
        var end = start + 1
        while (end < text.length && text[end].isDigit() == digits) end++
        val from = length
        append(text, start, end)
        if (digits) addStyle(SpanStyle(fontFeatureSettings = TABULAR), from, length)
        start = end
    }
}
