@file:OptIn(kotlin.io.encoding.ExperimentalEncodingApi::class)

package dev.cluvex.zedsecure.domain.config

import kotlin.io.encoding.Base64

data class SubscriptionMeta(
    val upload: Long? = null,
    val download: Long? = null,

    val total: Long? = null,

    val expireAt: Long? = null,
    val title: String? = null,
    val updateIntervalHours: Int? = null,
    val supportUrl: String? = null,
    val webPageUrl: String? = null,

    /** Plain `announce` text (Happ: max 200 chars, plain or `base64:`). */
    val announce: String? = null,

    /** Happ "advanced announcements": coloured info block (`sub-info-*`). */
    val subInfoText: String? = null,
    val subInfoColor: String? = null,
    val subInfoButtonText: String? = null,
    val subInfoButtonLink: String? = null,

    /** Happ `sub-expire`: show the expiry banner 3 days before / after expiry. */
    val subExpire: Boolean = false,
    val subExpireButtonLink: String? = null,
) {
    val isEmpty: Boolean
        get() = upload == null && download == null && total == null && expireAt == null &&
            title == null && updateIntervalHours == null && supportUrl == null && webPageUrl == null &&
            announce == null && subInfoText == null && !subExpire
}

/**
 * Subscription metadata, delivered the way Happ documents it: either as HTTP response headers
 * or as `#key: value` lines at the top of the subscription body. When the same key arrives both
 * ways the body wins (Happ: "parameters specified in the subscription body take precedence over
 * those passed through HTTP headers").
 */
object SubscriptionHeaders {
    fun parse(headers: Map<String, String>, body: String? = null): SubscriptionMeta {
        val byName = HashMap<String, String>()
        headers.forEach { (k, v) -> byName[k.trim().lowercase()] = v }
        if (body != null) byName.putAll(parseBodyDirectives(body))

        val info = (byName["subscription-userinfo"] ?: byName["x-subscription-userinfo"] ?: byName["userinfo"])
            ?.let(::parseUserInfo) ?: UserInfo()
        return SubscriptionMeta(
            upload = info.upload,
            download = info.download,
            total = info.total,
            expireAt = info.expireAt,
            title = byName["profile-title"]?.let { decodeText(it, MAX_TITLE) },
            updateIntervalHours = byName["profile-update-interval"]?.let(::parseInterval),
            supportUrl = byName["support-url"]?.let(::linkOrNull),
            webPageUrl = byName["profile-web-page-url"]?.let(::linkOrNull),
            announce = byName["announce"]?.let(::decodeToggleText),
            subInfoText = byName["sub-info-text"]?.let(::decodeToggleText),
            subInfoColor = byName["sub-info-color"]?.trim()?.lowercase()
                ?.takeIf { it == "red" || it == "blue" || it == "green" },
            subInfoButtonText = byName["sub-info-button-text"]?.let { decodeText(it, MAX_BUTTON) },
            subInfoButtonLink = byName["sub-info-button-link"]?.trim()?.takeIf { it.isNotEmpty() && it != "0" },
            subExpire = byName["sub-expire"]?.let(::isTruthy) ?: false,
            subExpireButtonLink = byName["sub-expire-button-link"]?.trim()?.takeIf { it.isNotEmpty() && it != "0" },
        )
    }

    /**
     * `#key: value` lines at the head of the body. Reading stops at the first line that is
     * neither blank nor a `#` directive, so a server link or a JSON body is never scanned.
     */
    fun parseBodyDirectives(body: String): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        var seen = 0
        for (raw in body.lineSequence()) {
            val line = raw.trim().trimStart('\uFEFF')
            if (line.isEmpty()) continue
            if (!line.startsWith("#") || ++seen > MAX_DIRECTIVE_LINES) break
            val colon = line.indexOf(':')
            if (colon <= 1) continue
            val key = line.substring(1, colon).trim().lowercase()
            if (key.isEmpty() || key.any { it.isWhitespace() }) continue
            out[key] = line.substring(colon + 1).trim()
        }
        return out
    }

    data class UserInfo(
        val upload: Long? = null,
        val download: Long? = null,
        val total: Long? = null,
        val expireAt: Long? = null,
    )

    /** `upload=0; download=2153701362; total=0; expire=1790951622` — `total=0` / `expire=0` mean "none". */
    fun parseUserInfo(value: String): UserInfo {
        val fields = value.split(';', ',')
            .mapNotNull { part ->
                val eq = part.indexOf('=')
                if (eq <= 0) return@mapNotNull null
                val key = part.substring(0, eq).trim().lowercase()
                val number = part.substring(eq + 1).trim().toDoubleOrNull()
                    ?.takeIf { !it.isNaN() && it >= 0 && it < Long.MAX_VALUE.toDouble() }
                    ?.toLong() ?: return@mapNotNull null
                key to number
            }
            .toMap()
        return UserInfo(
            upload = fields["upload"],
            download = fields["download"],
            total = fields["total"]?.takeIf { it > 0 },
            expireAt = fields["expire"]?.takeIf { it > 0 }?.let { seconds ->

                if (seconds >= 100_000_000_000L) seconds else seconds * 1000
            },
        )
    }

    fun decodeTitle(value: String): String? = decodeText(value, MAX_TITLE)

    /** Happ passes names / announcements as plain text or `base64:<utf-8>`. */
    fun decodeText(value: String, max: Int): String? {
        val raw = value.trim()
        if (raw.isEmpty()) return null
        val decoded = if (raw.startsWith("base64:", ignoreCase = true)) {
            val payload = raw.substring("base64:".length).trim()
            runCatching {
                Base64.withPadding(Base64.PaddingOption.ABSENT_OPTIONAL).decode(payload).decodeToString()
            }.recoverCatching {
                Base64.UrlSafe.withPadding(Base64.PaddingOption.ABSENT_OPTIONAL).decode(payload).decodeToString()
            }.getOrNull() ?: return null
        } else if (raw.all { it.code < 256 } && raw.any { it.code >= 128 }) {
            val bytes = ByteArray(raw.length) { raw[it].code.toByte() }
            bytes.decodeToString().takeIf { '\uFFFD' !in it } ?: raw
        } else {
            raw
        }
        return decoded.trim().replace(Regex("[ \\t]+"), " ").take(max).takeIf { it.isNotEmpty() }
    }

    /** Announcement-style values: `0` switches the block off (Happ: "send the value 0"). */
    private fun decodeToggleText(value: String): String? =
        value.trim().takeIf { it != "0" }?.let { decodeText(it, MAX_ANNOUNCE) }

    private fun isTruthy(value: String): Boolean = value.trim().lowercase().let { it == "1" || it == "true" }

    private fun parseInterval(value: String): Int? =
        value.trim().toDoubleOrNull()?.toInt()?.takeIf { it > 0 }?.coerceAtMost(168)

    /** http(s) links, plus `tg://` so a Telegram deep link keeps its Telegram icon. */
    private fun linkOrNull(value: String): String? {
        val v = value.trim()
        if (v.any(Char::isWhitespace)) return null
        val ok = (v.startsWith("https://", ignoreCase = true) && v.length > "https://".length) ||
            (v.startsWith("http://", ignoreCase = true) && v.length > "http://".length) ||
            (v.startsWith("tg://", ignoreCase = true) && v.length > "tg://".length)
        return v.takeIf { ok }
    }

    /** True when the link opens Telegram — Happ then shows the Telegram glyph instead of a generic link icon. */
    fun isTelegramLink(url: String): Boolean {
        val u = url.trim().lowercase()
        if (u.startsWith("tg://")) return true
        val host = u.substringAfter("://", "").substringBefore('/').substringBefore('?').substringAfter('@').substringBefore(':')
        return host == "t.me" || host == "telegram.me" || host == "telegram.dog" || host.endsWith(".t.me")
    }

    private const val MAX_TITLE = 25
    private const val MAX_ANNOUNCE = 200
    private const val MAX_BUTTON = 25
    private const val MAX_DIRECTIVE_LINES = 64
}

object SubscriptionSchedule {
    private const val EARLY_SLACK_MS = 10 * 60 * 1000L

    fun intervalHours(sub: Subscription, globalHours: Int): Int =
        (sub.updateIntervalHours ?: globalHours).coerceIn(1, 168)

    fun isDue(sub: Subscription, globalHours: Int, nowMs: Long): Boolean {
        if (!sub.enabled || sub.url.isBlank()) return false
        if (sub.lastUpdated <= 0L) return true
        return nowMs - sub.lastUpdated >= intervalHours(sub, globalHours) * 3_600_000L - EARLY_SLACK_MS
    }

    fun periodHours(subscriptions: List<Subscription>, globalHours: Int): Int =
        subscriptions.filter { it.enabled }
            .minOfOrNull { intervalHours(it, globalHours) }
            ?: globalHours.coerceIn(1, 168)
}

/**
 * Fallback for providers whose subscription endpoint only exposes usage / expiry inside the
 * HTML info page (e.g. the "pulse" template) and not in the `subscription-userinfo` header.
 * Looks for an embedded userinfo string first, then for common JSON field names.
 */
object SubscriptionPageInfo {
    fun parse(html: String): SubscriptionMeta? {
        if (html.isBlank()) return null

        Regex("""(?:upload|download|total|expire)\s*=\s*\d+(?:\s*[;,]\s*(?:upload|download|total|expire)\s*=\s*\d+)+""",
            RegexOption.IGNORE_CASE).find(html)?.let { m ->
            val info = SubscriptionHeaders.parseUserInfo(m.value)
            if (info.upload != null || info.download != null || info.total != null || info.expireAt != null) {
                return SubscriptionMeta(info.upload, info.download, info.total, info.expireAt)
            }
        }

        val upload = number(html, "upload", "uploaded")
        val download = number(html, "download", "downloaded")
        val used = number(html, "current_usage", "used", "used_traffic", "usedTraffic", "usedTrafficBytes", "consumed", "total_usage")
        val total = number(html, "limit_usage", "total", "data_limit", "dataLimit", "trafficLimitBytes", "traffic_limit", "limit", "quota")
            ?.takeIf { it > 0 }
        val expire = expiry(html)

        val usedBytes = used ?: if (upload != null || download != null) (upload ?: 0L) + (download ?: 0L) else null
        if (usedBytes == null && total == null && expire == null) return null
        return SubscriptionMeta(
            upload = if (used == null) upload else null,
            download = if (used == null) download else usedBytes,
            total = total,
            expireAt = expire,
        )
    }

    private fun keyPattern(names: Array<out String>) = names.joinToString("|") { Regex.escape(it) }

    private fun number(text: String, vararg names: String): Long? {
        val re = Regex("""["']?(?:${keyPattern(names)})["']?\s*[:=]\s*["']?(\d+(?:\.\d+)?)""", RegexOption.IGNORE_CASE)
        return re.find(text)?.groupValues?.get(1)?.toDoubleOrNull()
            ?.takeIf { it >= 0 && it < Long.MAX_VALUE.toDouble() }?.toLong()
    }

    private fun expiry(text: String): Long? {
        val keys = arrayOf("limit_expire", "expire", "expire_at", "expireAt", "expires_at", "expiresAt", "expiry", "expiration", "expire_date")
        val numeric = Regex("""["']?(?:${keyPattern(keys)})["']?\s*[:=]\s*["']?(\d{9,})""", RegexOption.IGNORE_CASE)
            .find(text)?.groupValues?.get(1)?.toLongOrNull()
        if (numeric != null && numeric > 0) {
            return if (numeric >= 100_000_000_000L) numeric else numeric * 1000
        }
        val iso = Regex("""["']?(?:${keyPattern(keys)})["']?\s*[:=]\s*["'](\d{4})-(\d{2})-(\d{2})""", RegexOption.IGNORE_CASE)
            .find(text) ?: return null
        val (y, m, d) = iso.destructured
        return epochDay(y.toInt(), m.toInt(), d.toInt()) * 86_400_000L
    }

    private fun epochDay(year: Int, month: Int, day: Int): Long {
        val y = if (month <= 2) year - 1 else year
        val era = Math.floorDiv(y, 400)
        val yoe = y - era * 400
        val mp = (month + 9) % 12
        val doy = (153 * mp + 2) / 5 + day - 1
        val doe = yoe * 365 + yoe / 4 - yoe / 100 + doy
        return era * 146_097L + doe - 719_468L
    }
}
