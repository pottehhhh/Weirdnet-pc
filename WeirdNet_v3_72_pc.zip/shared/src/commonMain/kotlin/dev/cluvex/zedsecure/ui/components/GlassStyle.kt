package dev.cluvex.zedsecure.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/** The bright-to-faint edge line every glass surface in the app shares. */
fun glassHairline(strength: Float = 1f): Brush =
    Brush.verticalGradient(
        listOf(
            Color.White.copy(alpha = 0.26f * strength),
            Color.White.copy(alpha = 0.05f * strength),
        ),
    )

/** A one-dp glass edge, for the `border` of a Surface. */
fun glassBorder(strength: Float = 1f): BorderStroke = BorderStroke(1.dp, glassHairline(strength))

/** The glass edge as a modifier, for boxes that are not a Surface. */
fun Modifier.glassEdge(shape: Shape, strength: Float = 1f): Modifier = border(1.dp, glassHairline(strength), shape)
