package dev.cluvex.zedsecure.ui.home

import androidx.compose.runtime.compositionLocalOf

/** True while the active profile is an Auto-select group: its (long) title is then shown in full. */
val LocalFullConfigName = compositionLocalOf { false }
