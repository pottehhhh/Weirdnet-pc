package dev.cluvex.zedsecure.ui.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import dev.cluvex.zedsecure.data.account.AccountRepository
import dev.cluvex.zedsecure.shared.resources.*
import kotlin.random.Random
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.getString
import org.jetbrains.compose.resources.stringResource

/**
 * The four kinds of plan the shop sells. The three volume kinds are bought by choosing a volume; the
 * unlimited kind is bought by choosing how many users it has. [type] is what the bot calls the panel.
 */
private enum class Kind(val type: String, val accent: Color, val volume: Boolean) {
    STANDARD("STANDARD", Color(0xFF5EE0B5), true),
    OMEGA("OMEGA", Color(0xFF4D9DFF), true),
    GAMING("GAMING", Color(0xFFFF8A65), true),
    UNLIMITED("UNLIMITED", Color(0xFFB197FC), false),
}

@Composable
private fun Kind.label(): String = stringResource(
    when (this) {
        Kind.STANDARD -> Res.string.plan_name_standard
        Kind.OMEGA -> Res.string.plan_name_omega
        Kind.GAMING -> Res.string.plan_name_gaming
        Kind.UNLIMITED -> Res.string.plan_name_unlimited
    },
)

private fun newRef() = "app-" + Random.nextLong().toULong().toString(16)

private val CardShape = RoundedCornerShape(24.dp)
private val ChipShape = RoundedCornerShape(20.dp)

@Composable
internal fun BuyPage(account: AccountRepository, contentPadding: PaddingValues, modifier: Modifier) {
    val loggedIn by account.loggedIn.collectAsState()
    SettingsPageScaffold(
        title = stringResource(Res.string.buy_title),
        art = SettingsArts.Update,
        subtitle = stringResource(Res.string.buy_subtitle),
        contentPadding = contentPadding,
        modifier = modifier,
    ) {
        if (!loggedIn) LoginSection(account, stringResource(Res.string.buy_login_reason))
        else GlassPage { BuyContent(account) }
    }
}

@Composable
private fun BuyContent(account: AccountRepository) {
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val balance by account.balanceFlow.collectAsState()
    val offline by account.offline.collectAsState()

    var loading by remember { mutableStateOf(true) }
    var reload by remember { mutableStateOf(0) }
    var plans by remember { mutableStateOf<List<AccountRepository.Plan>>(emptyList()) }
    var custom by remember { mutableStateOf<AccountRepository.CustomInfo?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var topUp by remember { mutableStateOf(false) }

    // What is selected: a kind (null when one of the "other" plans is picked) and, for plans, which plan.
    var kind by remember { mutableStateOf<Kind?>(Kind.STANDARD) }
    var planId by remember { mutableStateOf<String?>(null) }
    var gb by remember { mutableStateOf(50) }
    var days by remember { mutableStateOf(30) }
    var codeText by remember { mutableStateOf("") }
    var applied by remember { mutableStateOf<String?>(null) }
    var quoted by remember { mutableStateOf<AccountRepository.Quote?>(null) }
    var quoting by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var success by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf(false) }

    // While the server cannot be reached, keep asking until it answers.
    LaunchedEffect(offline) {
        while (offline) {
            kotlinx.coroutines.delay(3_000)
            reload++
        }
    }

    LaunchedEffect(reload) {
        loading = true
        val b = account.balance()
        val p = account.plans()
        val c = account.custom()
        p.onSuccess { plans = it }
        c.onSuccess { custom = it }
        message = listOf(b, p).firstOrNull { it.isFailure }?.exceptionOrNull()?.let { errorText(it) }
        loading = false
    }

    val unlimited = remember(plans) { plans.filter { it.isUnlimited }.sortedBy { it.ipLimit ?: Int.MAX_VALUE } }
    val others = remember(plans) { plans.filter { !it.isUnlimited } }

    // The limits the bot gives for the selected volume kind. An older server that does not list panels
    // leaves the general limits in place.
    val info = custom
    val limits = kind?.takeIf { it.volume }?.let { k -> info?.panels?.firstOrNull { it.type == k.type } }
    val volumeAvailable = kind?.volume != true || info == null || info.panels.isEmpty() || limits?.found == true
    val minGb = limits?.minGb ?: info?.minGb ?: 1
    val maxGb = limits?.maxGb ?: info?.maxGb ?: 1000
    val minDays = limits?.minDays ?: info?.minDays ?: 1
    val maxDays = limits?.maxDays ?: info?.maxDays ?: 365
    val perGb = limits?.perGb ?: info?.perGb

    // Keep the numbers inside what the bot allows whenever the kind or the limits change.
    LaunchedEffect(kind, minGb, maxGb, minDays, maxDays) {
        gb = gb.coerceIn(minGb, maxGb)
        days = days.coerceIn(minDays, maxDays)
    }
    LaunchedEffect(kind, unlimited) {
        if (kind == Kind.UNLIMITED && unlimited.none { it.id == planId }) planId = unlimited.firstOrNull()?.id
    }

    val plan: AccountRepository.Plan? = if (kind?.volume == true) null else plans.firstOrNull { it.id == planId }
    val isVolume = kind?.volume == true
    val volumeValid = isVolume && volumeAvailable && gb in minGb..maxGb && days in minDays..maxDays
    val ready = if (isVolume) volumeValid else plan != null

    // The exact price comes from the bot. A volume plan asks again (a moment after the last change);
    // a plan only needs it when a discount code was applied.
    LaunchedEffect(kind, planId, gb, days, applied, volumeValid) {
        quoted = null
        if (isVolume) {
            if (!volumeValid) return@LaunchedEffect
            delay(350)
            quoting = true
            account.quote(null, gb, days, kind?.type, applied).fold(
                onSuccess = { quoted = it; error = null },
                onFailure = { error = errorText(it) },
            )
            quoting = false
        } else if (plan != null && applied != null) {
            quoting = true
            account.quote(plan.id, null, null, null, applied).fold(
                onSuccess = { quoted = it; error = null },
                onFailure = { error = errorText(it) },
            )
            quoting = false
        }
    }

    val listPrice: Long? = if (isVolume) quoted?.basePrice else plan?.price
    val estimate: Long? = if (isVolume && perGb != null) perGb * gb else null
    val payable: Long? = when {
        isVolume -> quoted?.finalPrice
        applied != null -> quoted?.finalPrice
        else -> plan?.appPrice ?: plan?.price
    }
    val shownPrice = payable ?: estimate
    val notEnough = balance != null && payable != null && balance!! < payable
    var ref by remember(applied, gb, days, kind, planId) { mutableStateOf(newRef()) }

    if (offline) GlassNotice(stringResource(Res.string.account_offline), Modifier.padding(horizontal = 16.dp, vertical = 8.dp), tone = Color(0xFFFFB84D))

    Column(Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TrialCarousel(account = account, reload = reload, onDone = { reload++ })
    }
    message?.let { m -> GlassNotice(m, Modifier.padding(horizontal = 16.dp, vertical = 8.dp), tone = cs.error) }

    Column(
        Modifier.padding(horizontal = 16.dp).padding(top = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // Wallet
        GlassCard(Modifier.fillMaxWidth(), shape = CardShape, padding = 16.dp) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(Res.string.account_balance), style = MaterialTheme.typography.labelLarge)
                    Text(
                        balance?.let { toman(it) + " " + stringResource(Res.string.account_toman) } ?: if (loading) "…" else "—",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                }
                CapsuleButton(
                    text = stringResource(Res.string.account_topup),
                    onClick = { topUp = true },
                    container = cs.primary,
                    content = cs.onPrimary,
                    height = 44.dp,
                    modifier = Modifier.padding(start = 12.dp).width(150.dp),
                )
            }
        }

        // 1. Kind
        Text(stringResource(Res.string.buy_pick_plan), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(listOf(Kind.STANDARD, Kind.OMEGA), listOf(Kind.GAMING, Kind.UNLIMITED)).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    row.forEach { k ->
                        val sub: String? = if (k.volume) {
                            info?.panels?.firstOrNull { it.type == k.type }?.perGb?.let { stringResource(Res.string.buy_per_gb, toman(it)) }
                        } else {
                            unlimited.mapNotNull { it.price }.minOrNull()?.let { toman(it) + " " + stringResource(Res.string.account_toman) }
                        }
                        KindCard(
                            label = k.label(),
                            sub = sub,
                            accent = k.accent,
                            selected = kind == k,
                            enabled = !k.volume || info == null || info.panels.isEmpty() || info.panels.firstOrNull { it.type == k.type }?.found == true,
                            modifier = Modifier.weight(1f),
                        ) { kind = k; error = null }
                    }
                }
            }
        }

        // 2. What the kind needs
        val accent = kind?.accent ?: cs.primary
        if (kind != null && isVolume) {
            if (!volumeAvailable) {
                Text(stringResource(Res.string.buy_kind_missing), color = cs.error, style = MaterialTheme.typography.bodyMedium)
            } else {
                VolumeSection(
                    gb = gb, minGb = minGb, maxGb = maxGb, accent = accent,
                    days = days, minDays = minDays, maxDays = maxDays,
                    onGb = { gb = it }, onDays = { days = it },
                )
            }
        } else if (kind == Kind.UNLIMITED) {
            UsersSection(unlimited, planId, accent) { planId = it }
        }

        if (others.isNotEmpty()) {
            Text(stringResource(Res.string.buy_other_plans), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            others.forEach { p ->
                OtherPlanRow(p, selected = kind == null && planId == p.id) { kind = null; planId = p.id }
            }
        }

        if (plans.isEmpty() && custom == null) {
            Text(
                if (loading) "…" else stringResource(Res.string.account_no_plans),
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
            )
        }

        if (ready) {
            // 3. Discount code
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = codeText,
                    onValueChange = { codeText = it.filter { c -> c.isLetterOrDigit() || c == '_' || c == '-' }.take(32); applied = null },
                    label = { Text(stringResource(Res.string.buy_discount_code)) },
                    singleLine = true,
                    shape = ChipShape,
                    modifier = Modifier.weight(1f),
                )
                OutlinedButton(
                    enabled = codeText.isNotBlank() && applied != codeText && !busy,
                    onClick = {
                        scope.launch {
                            quoting = true
                            error = null
                            account.quote(
                                plan?.id, gb.takeIf { isVolume }, days.takeIf { isVolume }, kind?.type?.takeIf { isVolume }, codeText,
                            ).fold(
                                onSuccess = { quoted = it; applied = codeText },
                                onFailure = { error = errorText(it) },
                            )
                            quoting = false
                        }
                    },
                    modifier = Modifier.height(56.dp),
                ) { Text(stringResource(Res.string.buy_discount_apply)) }
            }
            if (applied != null) {
                Text(stringResource(Res.string.buy_discount_applied), color = cs.tertiary, style = MaterialTheme.typography.bodySmall)
            }

            // 4. Order summary
            GlassCard(Modifier.fillMaxWidth(), shape = CardShape, padding = 18.dp) {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(Res.string.buy_summary_title), style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                    Text(summaryTitle(kind, plan), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(summaryDetail(isVolume, gb, days, plan), color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                    if (listPrice != null && payable != null && payable < listPrice) {
                        SummaryRow(stringResource(Res.string.buy_row_price), toman(listPrice) + " " + stringResource(Res.string.account_toman), strike = true)
                        SummaryRow(stringResource(Res.string.buy_row_discount), "− " + toman(listPrice - payable) + " " + stringResource(Res.string.account_toman))
                    }
                    Surface(shape = ChipShape, color = accent.copy(alpha = 0.14f).compositeOver(cs.surfaceContainerHighest), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                            Text(stringResource(Res.string.buy_final_price), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                            Text(
                                when {
                                    quoting -> stringResource(Res.string.buy_calculating)
                                    shownPrice != null -> (if (payable == null) "≈ " else "") + toman(shownPrice) + " " + stringResource(Res.string.account_toman)
                                    else -> "—"
                                },
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color = accent,
                            )
                        }
                    }
                    if (balance != null && payable != null) {
                        SummaryRow(stringResource(Res.string.buy_row_wallet), toman(balance!!) + " " + stringResource(Res.string.account_toman))
                        if (!notEnough) {
                            SummaryRow(stringResource(Res.string.buy_row_after), toman(balance!! - payable) + " " + stringResource(Res.string.account_toman))
                        }
                    }
                    if (notEnough) {
                        Text(stringResource(Res.string.buy_low_balance), color = cs.error, style = MaterialTheme.typography.bodySmall)
                    }
                    error?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall) }
                }
            }

            // 5. Buy (or top up first)
            if (notEnough) {
                CapsuleButton(
                    text = stringResource(Res.string.account_topup),
                    onClick = { topUp = true },
                    container = cs.primary,
                    content = cs.onPrimary,
                    modifier = Modifier.fillMaxWidth(),
                    height = 54.dp,
                )
            } else {
                CapsuleButton(
                    text = stringResource(Res.string.buy_now),
                    onClick = { confirm = true },
                    container = accent,
                    content = Color.White,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy && !quoting && !offline && payable != null,
                    height = 54.dp,
                )
            }
        }
    }

    if (confirm && payable != null) {
        AlertDialog(
            onDismissRequest = { if (!busy) confirm = false },
            containerColor = glassDialogColor(),
            shape = GlassShape,
            title = { Text(stringResource(Res.string.account_buy_confirm_title)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(summaryTitle(kind, plan), fontWeight = FontWeight.SemiBold)
                    Text(summaryDetail(isVolume, gb, days, plan), color = cs.onSurfaceVariant)
                    Text(toman(payable) + " " + stringResource(Res.string.account_toman), color = cs.tertiary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(Res.string.account_buy_confirm_body), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            },
            confirmButton = {
                Button(
                    enabled = !busy,
                    onClick = {
                        busy = true
                        error = null
                        scope.launch {
                            account.buy(
                                planId = plan?.id,
                                ref = ref,
                                gb = gb.takeIf { isVolume },
                                days = days.takeIf { isVolume },
                                panel = kind?.type?.takeIf { isVolume },
                                code = applied,
                                expect = payable,
                            ).fold(
                                onSuccess = { result ->
                                    confirm = false
                                    applied = null
                                    codeText = ""
                                    val svc = result.service
                                    if (svc != null) kind?.let { account.learnKind(svc, it.ordinal) }
                                    message = when {
                                        svc == null -> getString(Res.string.account_bought)
                                        account.addPurchased(svc) -> getString(Res.string.account_added_auto)
                                        else -> getString(Res.string.account_add_failed)
                                    }
                                    success = message
                                    message = null
                                    reload++
                                },
                                onFailure = { e ->
                                    confirm = false
                                    error = errorText(e)
                                    // The price moved: show the new one and let the user decide again.
                                    if ((e as? AccountRepository.AccountException)?.message == "price_changed") {
                                        account.quote(plan?.id, gb.takeIf { isVolume }, days.takeIf { isVolume }, kind?.type?.takeIf { isVolume }, applied)
                                            .onSuccess { quoted = it }
                                        ref = newRef()
                                    }
                                },
                            )
                            busy = false
                        }
                    },
                ) { Text(stringResource(Res.string.account_buy_confirm)) }
            },
            dismissButton = { TextButton(enabled = !busy, onClick = { confirm = false }) { Text(stringResource(Res.string.account_cancel)) } },
        )
    }

    success?.let { text ->
        val pop by androidx.compose.animation.core.animateFloatAsState(
            targetValue = 1f,
            animationSpec = androidx.compose.animation.core.spring(dampingRatio = 0.45f, stiffness = 300f),
            label = "success-pop",
        )
        AlertDialog(
            onDismissRequest = { success = null },
            containerColor = glassDialogColor(),
            shape = GlassShape,
            icon = {
                androidx.compose.material3.Icon(
                    org.jetbrains.compose.resources.painterResource(Res.drawable.ic_check_circle),
                    contentDescription = null,
                    tint = androidx.compose.ui.graphics.Color(0xFF4CAF50),
                    modifier = Modifier.size(64.dp).graphicsLayer { scaleX = pop; scaleY = pop },
                )
            },
            title = { Text(stringResource(Res.string.buy_success_title), textAlign = androidx.compose.ui.text.style.TextAlign.Center) },
            text = { Text(text, color = cs.onSurfaceVariant, textAlign = androidx.compose.ui.text.style.TextAlign.Center) },
            confirmButton = { Button(onClick = { success = null }) { Text(stringResource(Res.string.buy_success_ok)) } },
        )
    }

    if (topUp) TopUpDialog(account) { topUp = false }
}

@Composable
private fun summaryTitle(kind: Kind?, plan: AccountRepository.Plan?): String = when {
    kind == Kind.UNLIMITED && plan != null -> Kind.UNLIMITED.label() + " · " + usersText(plan)
    kind != null -> kind.label()
    else -> plan?.let { it.title.ifBlank { it.id } }.orEmpty()
}

@Composable
private fun summaryDetail(isVolume: Boolean, gb: Int, days: Int, plan: AccountRepository.Plan?): String {
    val d = stringResource(Res.string.account_days)
    return when {
        isVolume -> "$gb GB  ·  $days $d"
        plan?.isUnlimited == true -> listOfNotNull(stringResource(Res.string.buy_unlimited), plan.days?.let { "$it $d" }).joinToString("  ·  ")
        plan != null -> listOfNotNull(plan.volumeGb?.let { "$it GB" }, plan.days?.let { "$it $d" }).joinToString("  ·  ")
        else -> ""
    }
}

@Composable
internal fun usersText(plan: AccountRepository.Plan): String {
    val n = plan.ipLimit
    return when {
        n == null -> plan.title.ifBlank { plan.id }
        n == 1 -> stringResource(Res.string.buy_user_one)
        else -> stringResource(Res.string.buy_users_many, n)
    }
}

@Composable
private fun KindCard(
    label: String,
    sub: String?,
    accent: Color,
    selected: Boolean,
    enabled: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick,
        shape = ChipShape,
        color = if (selected) accent.copy(alpha = 0.20f) else cs.surfaceContainerHighest.copy(alpha = 0.55f),
        border = BorderStroke(if (selected) 1.5.dp else 1.dp, if (selected) accent else cs.outlineVariant),
        modifier = modifier.height(72.dp),
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.Center) {
            Text(
                label,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (enabled) (if (selected) accent else cs.onSurface) else cs.onSurfaceVariant.copy(alpha = 0.5f),
                maxLines = 1,
            )
            if (sub != null) {
                Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1)
            }
        }
    }
}

/** The volume dial, exact +/- buttons and quick picks. The duration only shows when the bot allows a choice. */
@Composable
private fun VolumeSection(
    gb: Int, minGb: Int, maxGb: Int, accent: Color,
    days: Int, minDays: Int, maxDays: Int,
    onGb: (Int) -> Unit, onDays: (Int) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    GlassCard(Modifier.fillMaxWidth(), shape = CardShape, padding = 16.dp) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(stringResource(Res.string.buy_volume_title), style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant, modifier = Modifier.fillMaxWidth())
            VolumeDial(value = gb, min = minGb, max = maxGb, accent = accent, unit = "GB", onChange = onGb)
            Text(
                stringResource(Res.string.buy_dial_hint) + "  ($minGb – $maxGb GB)",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                StepButton("−10", gb - 10 >= minGb) { onGb((gb - 10).coerceAtLeast(minGb)) }
                StepButton("−1", gb - 1 >= minGb) { onGb(gb - 1) }
                StepButton("+1", gb + 1 <= maxGb) { onGb(gb + 1) }
                StepButton("+10", gb + 10 <= maxGb) { onGb((gb + 10).coerceAtMost(maxGb)) }
            }
            val quick = listOf(10, 20, 30, 50, 100, 200, 300, 500).filter { it in minGb..maxGb }
            if (quick.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    quick.take(5).forEach { v ->
                        AssistChip(onClick = { onGb(v) }, label = { Text("$v") })
                    }
                }
            }
        }
    }
    GlassCard(Modifier.fillMaxWidth(), shape = CardShape, padding = 14.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(Res.string.buy_duration_title), style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
            if (minDays == maxDays) {
                Text("$days " + stringResource(Res.string.account_days), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    StepButton("−", days - 1 >= minDays) { onDays(days - 1) }
                    Text("$days " + stringResource(Res.string.account_days), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    StepButton("+", days + 1 <= maxDays) { onDays(days + 1) }
                }
            }
        }
    }
}

@Composable
private fun StepButton(text: String, enabled: Boolean, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, enabled = enabled, modifier = Modifier.height(40.dp), contentPadding = PaddingValues(horizontal = 14.dp)) {
        Text(text, fontWeight = FontWeight.SemiBold)
    }
}

/** The unlimited plans: no volume at all, only how many users and how long. */
@Composable
private fun UsersSection(
    plans: List<AccountRepository.Plan>,
    selected: String?,
    accent: Color,
    onSelect: (String) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Text(stringResource(Res.string.buy_users_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    if (plans.isEmpty()) {
        Text(stringResource(Res.string.buy_kind_missing), color = cs.error, style = MaterialTheme.typography.bodyMedium)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        plans.forEach { p ->
            val isSel = p.id == selected
            Surface(
                onClick = { onSelect(p.id) },
                shape = ChipShape,
                color = if (isSel) accent.copy(alpha = 0.20f) else cs.surfaceContainerHighest.copy(alpha = 0.55f),
                border = BorderStroke(if (isSel) 1.5.dp else 1.dp, if (isSel) accent else cs.outlineVariant),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(usersText(p), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(
                            listOfNotNull(stringResource(Res.string.buy_unlimited), p.days?.let { it + " " + stringResource(Res.string.account_days) }).joinToString("  ·  "),
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.onSurfaceVariant,
                        )
                    }
                    PriceBlock(p, accent)
                }
            }
        }
    }
}

@Composable
private fun PriceBlock(plan: AccountRepository.Plan, accent: Color) {
    val cs = MaterialTheme.colorScheme
    val price = plan.price ?: return
    val discounted = plan.appPrice?.takeIf { it < price }
    Column(horizontalAlignment = Alignment.End) {
        if (discounted != null) {
            Text(toman(price), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, textDecoration = TextDecoration.LineThrough)
        }
        Text(
            toman(discounted ?: price) + " " + stringResource(Res.string.account_toman),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = accent,
        )
    }
}

@Composable
private fun OtherPlanRow(plan: AccountRepository.Plan, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val accent = cs.primary
    Surface(
        onClick = onClick,
        shape = ChipShape,
        color = if (selected) accent.copy(alpha = 0.20f) else cs.surfaceContainerHighest.copy(alpha = 0.55f),
        border = BorderStroke(if (selected) 1.5.dp else 1.dp, if (selected) accent else cs.outlineVariant),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(plan.title.ifBlank { plan.id }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                val parts = listOfNotNull(plan.volumeGb?.let { "$it GB" }, plan.days?.let { it + " " + stringResource(Res.string.account_days) })
                if (parts.isNotEmpty()) Text(parts.joinToString("  ·  "), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
            }
            PriceBlock(plan, accent)
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: String, strike: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            textDecoration = if (strike) TextDecoration.LineThrough else null,
        )
    }
}
