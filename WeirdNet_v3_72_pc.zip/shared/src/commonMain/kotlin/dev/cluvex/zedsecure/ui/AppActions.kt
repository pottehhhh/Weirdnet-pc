package dev.cluvex.zedsecure.ui

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf

/**
 * The in-app places every "Buy", "Support" and "Messages" button leads to. Screens call these instead
 * of opening Telegram, so buying and support always happen inside the app. When the user is not
 * signed in yet, those pages show the sign-in step first.
 */
@Immutable
class AppActions(
    val openBuy: () -> Unit,
    val openSupport: () -> Unit,
    val openInbox: () -> Unit,
    val openAccount: () -> Unit,
)

val LocalAppActions = staticCompositionLocalOf<AppActions?> { null }
