package dev.cluvex.zedsecure.ui.home

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.cluvex.zedsecure.data.config.ConfigRepository
import dev.cluvex.zedsecure.data.net.PingCoordinator
import dev.cluvex.zedsecure.domain.config.VpnProfile
import dev.cluvex.zedsecure.domain.model.ConnectionState
import dev.cluvex.zedsecure.shared.resources.*
import dev.cluvex.zedsecure.ui.components.FlagBadge
import dev.cluvex.zedsecure.ui.connection.ConnectionUiState
import dev.cluvex.zedsecure.ui.format.formatElapsed
import dev.cluvex.zedsecure.ui.format.formatRate
import dev.cluvex.zedsecure.ui.platform.LocalPlatform
import dev.cluvex.zedsecure.ui.servers.RegionGrouping
import androidx.compose.ui.graphics.lerp
import dev.cluvex.zedsecure.ui.settings.CapsuleButton
import dev.cluvex.zedsecure.ui.settings.GlassCard
import dev.cluvex.zedsecure.ui.settings.MoneySheet
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

private val Green = Color(0xFF34C759)
private val Amber = Color(0xFFFF9F0A)
private val Red = Color(0xFFFF453A)

private fun pingColor(ms: Int?): Color = when {
    ms == null || ms <= 0 -> Color(0xFF8E8E93)
    ms < 180 -> Green
    ms < 450 -> Amber
    else -> Red
}

/** The server name without its flag emoji and bolt: the flag is drawn separately, so the name is not repeated. */
private fun cleanName(name: String): String {
    val sb = StringBuilder()
    var i = 0
    while (i < name.length) {
        val cp = name.codePointAt(i)
        i += Character.charCount(cp)
        if (cp in 0x1F1E6..0x1F1FF || cp == 0x26A1 || cp == 0xFE0F || cp == 0x200D) continue
        sb.appendCodePoint(cp)
    }
    return sb.toString().trim().trimStart('|', '-', '·', ' ').ifBlank { name }
}

/** The real flag of a server: from the flag or country in its name first, never the ping's guess. */
private fun flagOf(p: VpnProfile?): String? = p?.let { RegionGrouping.countryOf(it) }

/**
 * The simple mode: a big glowing orb to connect, the server with its flag and ping, and the few things a
 * beginner needs (add a server, buy or renew, support, the account) on the same page.
 */
@Composable
internal fun SimpleHome(
    ui: ConnectionUiState,
    repository: ConfigRepository,
    onToggle: () -> Unit,
    onBuy: () -> Unit,
    onSupport: () -> Unit,
    onAccount: () -> Unit,
    onExit: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val platform = LocalPlatform.current
    val scope = rememberCoroutineScope()
    val haptics = LocalHapticFeedback.current
    val profiles by repository.profiles.collectAsState()
    val activeId by repository.activeId.collectAsState()
    val progress by PingCoordinator.progress.collectAsState()
    val active = profiles.firstOrNull { it.id == activeId }
    val hasServer = active != null
    var picking by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }

    val live = ui.state == ConnectionState.Connected
    val busy = ui.state == ConnectionState.Connecting || ui.state == ConnectionState.Reconnecting || ui.state == ConnectionState.Disconnecting
    val failed = ui.state == ConnectionState.Error

    val tone by animateColorAsState(
        when { live -> Green; busy -> Amber; failed -> Red; else -> cs.primary },
        tween(500),
        label = "simple-tone",
    )
    val energy by animateFloatAsState(if (live) 1f else if (busy) 0.65f else 0.25f, tween(800), label = "simple-energy")
    val t = rememberInfiniteTransition(label = "simple")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "spin")
    val breathe by t.animateFloat(0.96f, 1.04f, infiniteRepeatable(tween(2000, easing = LinearEasing), RepeatMode.Reverse), label = "breathe")

    fun testPing(list: List<VpnProfile>) {
        PingCoordinator.start(
            profiles = list,
            useRealDelay = false,
            concurrency = 16,
            delayUrl = "",
            chainConfig = repository::chainProbeConfig,
            clearPings = { repository.clearPings(it, persist = false) },
            onResult = { id, ms, cc -> repository.setPing(id, ms, cc, persist = false) },
            flush = { repository.flushProfiles() },
        )
    }

    val headline = when {
        !hasServer -> stringResource(Res.string.simple_no_server)
        live -> stringResource(Res.string.simple_live)
        busy -> stringResource(Res.string.simple_busy)
        failed -> stringResource(Res.string.simple_failed)
        else -> stringResource(Res.string.simple_idle)
    }

    Box(
        modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(cs.background, cs.background)))
            .background(Brush.radialGradient(listOf(tone.copy(alpha = 0.20f * energy), Color.Transparent), center = Offset(540f, 520f), radius = 1100f)),
    ) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // ---- top: brand and state ----
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("WEIRDNET", fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, color = cs.onSurface.copy(alpha = 0.85f), modifier = Modifier.weight(1f))
                Surface(shape = CircleShape, color = tone.copy(alpha = 0.16f)) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(tone))
                        Spacer(Modifier.width(7.dp))
                        Text(
                            stringResource(if (live) Res.string.simple_state_on else Res.string.simple_state_off),
                            fontSize = 13.sp, fontWeight = FontWeight.Bold, color = tone,
                        )
                    }
                }
            }

            // ---- the orb ----
            Box(
                Modifier.fillMaxWidth().height(270.dp)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, enabled = hasServer && ui.state != ConnectionState.Disconnecting) {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        onToggle()
                    },
                contentAlignment = Alignment.Center,
            ) {
                Canvas(Modifier.size(250.dp)) {
                    val s = size.minDimension
                    val c = Offset(s / 2f, s / 2f)
                    // soft glow behind everything
                    drawCircle(Brush.radialGradient(listOf(tone.copy(alpha = 0.42f * energy), Color.Transparent), center = c, radius = s * 0.52f), radius = s * 0.52f, center = c)
                    // outer hairline ring
                    drawCircle(tone.copy(alpha = 0.22f), radius = s * 0.46f * (if (live) breathe else 1f), center = c, style = Stroke(width = 2.dp.toPx()))
                    // the ring: full when live, a travelling arc while busy, a faint track otherwise
                    val ringR = s * 0.40f
                    val tl = Offset(c.x - ringR, c.y - ringR)
                    val sz = Size(ringR * 2, ringR * 2)
                    drawArc(tone.copy(alpha = 0.18f), 0f, 360f, false, tl, sz, style = Stroke(5.dp.toPx()))
                    when {
                        busy -> rotate(spin, c) { drawArc(Brush.sweepGradient(listOf(Color.Transparent, tone), c), -90f, 100f, false, tl, sz, style = Stroke(7.dp.toPx(), cap = StrokeCap.Round)) }
                        live -> drawArc(tone, -90f, 360f, false, tl, sz, style = Stroke(6.dp.toPx(), cap = StrokeCap.Round))
                    }
                    // the disc: one clean gradient, a thin light edge
                    val discR = s * 0.31f
                    drawCircle(
                        Brush.linearGradient(
                            listOf(lerp(tone, Color.White, 0.28f), tone),
                            start = Offset(c.x - discR, c.y - discR),
                            end = Offset(c.x + discR, c.y + discR),
                        ),
                        radius = discR, center = c,
                    )
                    drawCircle(Color.White.copy(alpha = 0.30f), radius = discR, center = c, style = Stroke(1.2.dp.toPx()))
                }
                Icon(painterResource(Res.drawable.ic_fill_power), null, tint = Color.White, modifier = Modifier.size(60.dp))
            }

            Text(
                headline,
                fontSize = 21.sp, lineHeight = 30.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
                color = if (live) Green else cs.onSurface,
            )
            if (live) {
                val (dv, du) = formatRate(ui.downloadBps)
                val (uv, uu) = formatRate(ui.uploadBps)
                GlassCard(Modifier.fillMaxWidth(), padding = 14.dp) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        StatCell(stringResource(Res.string.simple_down), "$dv $du", Modifier.weight(1f))
                        StatCell("⏱", formatElapsed(ui.elapsedSeconds), Modifier.weight(1f))
                        StatCell(stringResource(Res.string.simple_up), "$uv $uu", Modifier.weight(1f))
                    }
                }
            }

            // ---- server ----
            GlassCard(Modifier.fillMaxWidth(), padding = 16.dp, onClick = { picking = true }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FlagBadge(countryCode = flagOf(active), size = 32.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(stringResource(Res.string.simple_server), fontSize = 12.sp, color = cs.onSurfaceVariant)
                        Text(active?.name?.let(::cleanName) ?: "—", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    PingChip(active?.lastPingMs)
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CapsuleButton(
                        text = if (progress != null) "${progress?.done ?: 0}/${progress?.total ?: 0}" else stringResource(Res.string.simple_ping),
                        onClick = { if (progress != null) PingCoordinator.cancel() else active?.let { testPing(listOf(it)) } },
                        container = cs.onSurface.copy(alpha = 0.08f), content = cs.onSurface,
                        modifier = Modifier.weight(1f), enabled = hasServer, height = 42.dp,
                    )
                    CapsuleButton(
                        text = stringResource(Res.string.simple_change),
                        onClick = { picking = true },
                        container = cs.primary.copy(alpha = 0.16f), content = cs.primary,
                        modifier = Modifier.weight(1f), height = 42.dp,
                    )
                }
            }

            // ---- the four things a beginner needs ----
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Tile(stringResource(Res.string.simple_add), Res.drawable.ic_fill_apps, { adding = true }, Modifier.weight(1f))
                Tile(stringResource(Res.string.simple_buy), Res.drawable.ic_shopping_cart, onBuy, Modifier.weight(1f))
                Tile(stringResource(Res.string.simple_support), Res.drawable.ic_headset, onSupport, Modifier.weight(1f))
                Tile(stringResource(Res.string.simple_account), Res.drawable.ic_person, onAccount, Modifier.weight(1f))
            }

            Surface(onClick = onExit, shape = RoundedCornerShape(12.dp), color = Color.Transparent) {
                Text(stringResource(Res.string.simple_exit_button), style = MaterialTheme.typography.labelLarge, color = cs.primary, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            }
        }
    }

    if (picking) {
        val sorted = profiles.filter { !it.isLocked || it.id == activeId }
            .let { list -> if (list.any { (it.lastPingMs ?: 0) > 0 }) list.sortedBy { p -> p.lastPingMs?.takeIf { it > 0 } ?: Int.MAX_VALUE } else list }
        MoneySheet(onDismiss = { picking = false }) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(Res.string.simple_pick_title), fontSize = 19.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface, modifier = Modifier.weight(1f))
                    CapsuleButton(
                        text = if (progress != null) "${progress?.done ?: 0}/${progress?.total ?: 0}  ✕" else stringResource(Res.string.simple_ping_all),
                        onClick = { if (progress != null) PingCoordinator.cancel() else testPing(sorted.filter { !it.isAutoSelect }) },
                        container = cs.primary.copy(alpha = 0.16f), content = cs.primary,
                        modifier = Modifier.width(128.dp), height = 38.dp,
                    )
                }
                LazyColumn(Modifier.heightIn(max = 400.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(sorted, key = { it.id }) { p ->
                        val on = p.id == activeId
                        Surface(
                            onClick = { repository.setActive(p.id); picking = false },
                            shape = RoundedCornerShape(18.dp),
                            color = if (on) cs.primary.copy(alpha = 0.16f) else cs.onSurface.copy(alpha = 0.05f),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                FlagBadge(countryCode = flagOf(p), size = 26.dp)
                                Spacer(Modifier.width(12.dp))
                                Text(cleanName(p.name), fontSize = 15.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal, color = cs.onSurface, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                PingChip(p.lastPingMs)
                                if (on) Icon(painterResource(Res.drawable.ic_check_circle), null, tint = cs.primary, modifier = Modifier.padding(start = 8.dp).size(22.dp))
                            }
                        }
                    }
                }
                CapsuleButton(stringResource(Res.string.account_close), { picking = false }, Color.Transparent, cs.onSurfaceVariant, Modifier.fillMaxWidth(), height = 46.dp)
            }
        }
    }

    if (adding) {
        var text by remember { mutableStateOf("") }
        var note by remember { mutableStateOf<String?>(null) }
        var working by remember { mutableStateOf(false) }
        val failedText = stringResource(Res.string.simple_add_failed)
        MoneySheet(onDismiss = { if (!working) adding = false }) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(stringResource(Res.string.simple_add_title), fontSize = 21.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it; note = null },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    maxLines = 5,
                    shape = RoundedCornerShape(18.dp),
                )
                note?.let { Text(it, color = cs.error, fontSize = 15.sp) }
                CapsuleButton(
                    stringResource(Res.string.simple_paste),
                    { platform.readClipboard()?.let { text = it; note = null } },
                    cs.onSurface.copy(alpha = 0.08f), cs.onSurface, Modifier.fillMaxWidth(), height = 50.dp,
                )
                CapsuleButton(
                    if (working) "…" else stringResource(Res.string.simple_add_go),
                    {
                        working = true
                        scope.launch {
                            val r = repository.importPasted(text.trim())
                            val n = r.getOrNull()?.let { it.count + it.duplicates } ?: 0
                            if (n > 0) {
                                adding = false
                                if (repository.activeId.value == null) repository.profiles.value.lastOrNull()?.let { repository.setActive(it.id) }
                            } else note = failedText
                            working = false
                        }
                    },
                    cs.primary, cs.onPrimary, Modifier.fillMaxWidth(), enabled = text.isNotBlank() && !working, height = 54.dp,
                )
                CapsuleButton(stringResource(Res.string.account_close), { adding = false }, Color.Transparent, cs.onSurfaceVariant, Modifier.fillMaxWidth(), enabled = !working, height = 46.dp)
            }
        }
    }
}

@Composable
private fun StatCell(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
    }
}

/** The ping as a coloured dot and number: green is fast, amber is fair, red is slow, grey is not tested yet. */
@Composable
private fun PingChip(ms: Int?) {
    val c = pingColor(ms)
    Surface(shape = CircleShape, color = c.copy(alpha = 0.16f)) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).clip(CircleShape).background(c))
            Spacer(Modifier.width(6.dp))
            Text(if (ms != null && ms > 0) "$ms ms" else "—", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = c)
        }
    }
}

@Composable
private fun Tile(text: String, icon: DrawableResource, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Surface(onClick = onClick, shape = RoundedCornerShape(20.dp), color = cs.onSurface.copy(alpha = 0.07f), contentColor = cs.onSurface, modifier = modifier.height(92.dp)) {
        Column(Modifier.fillMaxSize().padding(horizontal = 4.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(painterResource(icon), null, tint = cs.primary, modifier = Modifier.size(24.dp))
            Spacer(Modifier.height(6.dp))
            Text(text, fontSize = 11.sp, lineHeight = 14.sp, fontWeight = FontWeight.Medium, color = cs.onSurface, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}
