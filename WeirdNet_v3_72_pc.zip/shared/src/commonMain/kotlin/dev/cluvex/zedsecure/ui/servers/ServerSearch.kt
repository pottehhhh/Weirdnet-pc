package dev.cluvex.zedsecure.ui.servers

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.unit.dp
import dev.cluvex.zedsecure.domain.config.VpnProfile
import dev.cluvex.zedsecure.shared.resources.*
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import java.text.Normalizer
import java.util.Locale

/**
 * Server search with a small query language. Everything is optional, plain words still work:
 *
 *   frankfurt            words, all must match (name, address, country, protocol, subscription, note)
 *   "new york"           exact phrase
 *   -tor                 exclude a word
 *   proto:vless          protocol          net:ws        transport (tcp, ws, grpc…)
 *   sec:tls / sec:reality / sec:none       security
 *   country:de | آلمان   country code or name (English or Persian)
 *   port:443             port              host:example.com / name:… / sub:… / note:…
 *   ping:<200  ping:>=100  ping:150        latency in ms
 *   status:ok | fail | untested            test result
 *
 * Digits and letters are normalised (Persian/Arabic digits, ي/ی, ك/ک, accents, ZWNJ), and when
 * nothing matches exactly a one-typo fuzzy pass is tried.
 */
object ServerSearch {
    data class Term(val field: String?, val value: String, val negate: Boolean, val phrase: Boolean = false)

    private val fieldAliases = mapOf(
        "proto" to "proto", "protocol" to "proto", "p" to "proto",
        "net" to "net", "network" to "net", "transport" to "net",
        "sec" to "sec", "security" to "sec", "tls" to "sec",
        "country" to "country", "c" to "country", "cc" to "country",
        "port" to "port",
        "host" to "host", "addr" to "host", "address" to "host", "ip" to "host",
        "name" to "name", "n" to "name",
        "sub" to "sub", "group" to "sub",
        "note" to "note",
        "ping" to "ping",
        "status" to "status", "is" to "status",
    )

    fun normalize(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            when (ch) {
                '\u200c', '\u200d', '\u0640' -> {}
                'ي', 'ى' -> sb.append('ی')
                'ك' -> sb.append('ک')
                in '۰'..'۹' -> sb.append('0' + (ch - '۰'))
                in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
                else -> sb.append(ch)
            }
        }
        return Normalizer.normalize(sb.toString(), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .lowercase()
    }

    fun parse(raw: String): List<Term> {
        val out = mutableListOf<Term>()
        val s = raw.trim()
        var i = 0
        while (i < s.length) {
            if (s[i].isWhitespace()) { i++; continue }
            var negate = false
            if (s[i] == '-' && i + 1 < s.length && !s[i + 1].isWhitespace()) { negate = true; i++ }
            val tokenStart = i
            var field: String? = null
            var phrase = false
            val value = StringBuilder()
            while (i < s.length && !s[i].isWhitespace()) {
                val c = s[i]
                if (c == '"') {
                    val end = s.indexOf('"', i + 1).let { if (it < 0) s.length else it }
                    value.append(s.substring(i + 1, end))
                    phrase = true
                    i = minOf(end + 1, s.length)
                } else if (c == ':' && field == null && !phrase) {
                    val key = fieldAliases[normalize(s.substring(tokenStart, i))]
                    if (key != null) { field = key; value.clear() } else value.append(c)
                    i++
                } else { value.append(c); i++ }
            }
            val v = normalize(value.toString()).trim()
            if (v.isNotEmpty()) out += Term(field, v, negate, phrase)
        }
        return out
    }

    fun tokenOf(field: String, value: String) = "$field:$value"

    fun hasToken(raw: String, token: String): Boolean =
        raw.split(' ').any { it.equals(token, ignoreCase = true) }

    fun toggleToken(raw: String, token: String): String {
        val parts = raw.split(' ').filter { it.isNotBlank() }
        return if (parts.any { it.equals(token, true) }) parts.filterNot { it.equals(token, true) }.joinToString(" ")
        else (parts + token).joinToString(" ")
    }

    private class Doc(p: VpnProfile, subName: String?) {
        val name = normalize(p.name)
        val nameWords = name.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
        val host = normalize(p.address)
        val port = p.port.toString()
        val proto = normalize(p.protocol)
        val label = normalize(p.transportLabel)
        val protoLabel = normalize(p.transportLabel.substringBefore(" · "))
        val net = p.transportLabel.split(" · ").getOrNull(1)?.substringBefore(" / ")?.let(::normalize).orEmpty()
        val sec = when (p.transportLabel.substringAfter(" / ", "").lowercase()) {
            "tls" -> "tls"; "reality" -> "reality"; else -> "none"
        }
        val sub = normalize(subName.orEmpty())
        val note = normalize(p.note.orEmpty())
        val code = (RegionGrouping.countryOf(p) ?: "").lowercase()
        val countryNames: String = if (code.length == 2) {
            val loc = Locale.Builder().setRegion(code.uppercase()).build()
            normalize(loc.getDisplayCountry(Locale.ENGLISH) + " " + loc.getDisplayCountry(Locale.forLanguageTag("fa")))
        } else ""
        val ping = p.lastPingMs
        val all = "$name $host $port $proto $label $sub $note $code $countryNames"
    }

    private fun within1(a: String, b: String): Boolean {
        if (a == b) return true
        if (kotlin.math.abs(a.length - b.length) > 1) return false
        var i = 0; var j = 0; var edits = 0
        while (i < a.length && j < b.length) {
            if (a[i] == b[j]) { i++; j++; continue }
            if (++edits > 1) return false
            when {
                a.length == b.length -> { i++; j++ }
                a.length > b.length -> i++
                else -> j++
            }
        }
        return edits + (a.length - i) + (b.length - j) <= 1
    }

    private fun pingMatches(ping: Int?, expr: String): Boolean {
        val m = Regex("^(<=|>=|<|>|=)?(\\d+)$").matchEntire(expr) ?: return false
        val n = m.groupValues[2].toInt()
        val p = ping ?: return false
        if (p <= 0) return false
        return when (m.groupValues[1]) {
            "<" -> p < n; "<=" -> p <= n; ">" -> p > n; ">=" -> p >= n; else -> p == n
        }
    }

    /** Score > 0 means "matches"; a higher score ranks earlier. Fuzzy only applies to free words. */
    private fun score(d: Doc, t: Term, fuzzy: Boolean): Double {
        val v = t.value
        return when (t.field) {
            "proto" -> if (d.proto == v || d.protoLabel == v || d.protoLabel.startsWith(v)) 2.0 else 0.0
            "net" -> if (d.net == v) 2.0 else 0.0
            "sec" -> if (d.sec == v) 2.0 else 0.0
            "country" -> if (d.code == v || (v.length > 2 && d.countryNames.contains(v))) 2.0 else 0.0
            "port" -> if (d.port == v) 2.0 else 0.0
            "host" -> if (d.host.contains(v)) 2.0 else 0.0
            "name" -> if (d.name.contains(v)) 2.0 else 0.0
            "sub" -> if (d.sub.contains(v)) 2.0 else 0.0
            "note" -> if (d.note.contains(v)) 2.0 else 0.0
            "ping" -> if (pingMatches(d.ping, v)) 2.0 else 0.0
            "status" -> when (v) {
                "ok", "good", "alive", "up" -> if ((d.ping ?: 0) > 0) 2.0 else 0.0
                "fail", "failed", "timeout", "dead", "down" -> if (d.ping != null && d.ping <= 0) 2.0 else 0.0
                "untested", "none", "new" -> if (d.ping == null) 2.0 else 0.0
                else -> 0.0
            }
            else -> {
                when {
                    d.name.startsWith(v) -> 5.0
                    d.nameWords.any { it.startsWith(v) } -> 4.0
                    d.name.contains(v) -> 3.0
                    d.countryNames.contains(v) || d.code == v -> 2.5
                    d.host.contains(v) -> 2.0
                    d.all.contains(v) -> 1.0
                    fuzzy && !t.phrase && v.length >= 4 &&
                        (d.nameWords + d.countryNames.split(' ')).any { within1(it, v) } -> 0.5
                    else -> 0.0
                }
            }
        }
    }

    fun filter(servers: List<VpnProfile>, raw: String, subName: (VpnProfile) -> String?): List<VpnProfile> {
        val terms = parse(raw)
        if (terms.isEmpty()) return servers
        val docs = servers.map { it to Doc(it, subName(it)) }
        fun run(fuzzy: Boolean): List<VpnProfile> =
            docs.mapNotNull { (p, d) ->
                var total = 0.0
                for (t in terms) {
                    val s = score(d, t, fuzzy)
                    if (t.negate) { if (s > 0) return@mapNotNull null } else { if (s <= 0) return@mapNotNull null; total += s }
                }
                Triple(p, total, 0)
            }.sortedByDescending { it.second }.map { it.first }
        val exact = run(false)
        return if (exact.isNotEmpty() || terms.none { it.field == null && !it.negate }) exact else run(true)
    }
}

@Composable
fun ServerSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    total: Int,
    matched: Int,
    protocols: List<String>,
    modifier: Modifier = Modifier,
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            singleLine = true,
            placeholder = { Text(stringResource(Res.string.servers_search_hint)) },
            leadingIcon = {
                Icon(painterResource(Res.drawable.ic_search), null, Modifier.size(20.dp))
            },
            trailingIcon = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (query.isNotBlank()) {
                        Text(
                            stringResource(Res.string.servers_search_count, matched, total),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        IconButton(onClick = { onQueryChange("") }) {
                            Icon(
                                painterResource(Res.drawable.ic_close),
                                contentDescription = stringResource(Res.string.servers_search_clear),
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                }
            },
            shape = RoundedCornerShape(28.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.60f),
                focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.72f),
                unfocusedBorderColor = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.14f),
            ),
            modifier = Modifier.fillMaxWidth().focusRequester(focus),
        )
        val chips = buildList {
            protocols.forEach { add(it to ServerSearch.tokenOf("proto", it.lowercase())) }
            add("TLS" to "sec:tls")
            add("Reality" to "sec:reality")
            add(stringResource(Res.string.servers_search_fast) to "ping:<200")
            add(stringResource(Res.string.ping_timeout) to "status:fail")
            add(stringResource(Res.string.servers_search_untested) to "status:untested")
        }
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(end = 8.dp),
        ) {
            items(chips, key = { it.second }) { (label, token) ->
                val on = ServerSearch.hasToken(query, token)
                FilterChip(
                    selected = on,
                    onClick = { onQueryChange(ServerSearch.toggleToken(query, token)) },
                    label = { Text(label) },
                    shape = RoundedCornerShape(50),
                )
            }
        }
        AnimatedVisibility(visible = query.isBlank()) {
            Text(
                stringResource(Res.string.servers_search_tip),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                modifier = Modifier.padding(horizontal = 6.dp),
            )
        }
    }
}
