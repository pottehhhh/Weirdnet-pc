package dev.cluvex.zedsecure.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import dev.cluvex.zedsecure.data.account.AccountConfig
import dev.cluvex.zedsecure.data.account.AccountRepository
import dev.cluvex.zedsecure.platform.currentTimeMillis
import dev.cluvex.zedsecure.shared.resources.*
import dev.cluvex.zedsecure.ui.platform.LocalPlatform
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.StringResource
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

@Composable
private fun agoText(atSec: Long): String {
    if (atSec <= 0) return ""
    val s = (currentTimeMillis() / 1000 - atSec).coerceAtLeast(0)
    return when {
        s < 90 -> stringResource(Res.string.account_ago_now)
        s < 3600 -> stringResource(Res.string.account_ago_min, (s / 60).toString())
        s < 86400 -> stringResource(Res.string.account_ago_hour, (s / 3600).toString())
        else -> stringResource(Res.string.account_ago_day, (s / 86400).toString())
    }
}

// ---------------------------------------------------------------------------------------------
// Messages (announcements). The bot API has none, so this stays an empty, tidy inbox.
// ---------------------------------------------------------------------------------------------

@Composable
internal fun InboxPage(account: AccountRepository, contentPadding: PaddingValues, modifier: Modifier) {
    val loggedIn by account.loggedIn.collectAsState()
    SettingsPageScaffold(
        title = stringResource(Res.string.account_inbox),
        art = SettingsArts.Update,
        subtitle = stringResource(Res.string.account_inbox_sub),
        contentPadding = contentPadding,
        modifier = modifier,
    ) {
        if (!loggedIn) LoginSection(account, stringResource(Res.string.inbox_login_reason)) else GlassPage { InboxContent(account) }
    }
}

@Composable
private fun InboxContent(account: AccountRepository) {
    var notes by remember { mutableStateOf<List<AccountRepository.Note>?>(null) }
    var failed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        account.inbox().fold(onSuccess = { notes = it }, onFailure = { failed = true })
    }
    val cs = MaterialTheme.colorScheme
    Column(Modifier.padding(horizontal = 16.dp).padding(top = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        val list = notes
        when {
            failed -> GlassNotice(stringResource(Res.string.account_error_network), tone = cs.error)
            list == null -> Text("…", color = cs.onSurfaceVariant)
            list.isEmpty() -> GlassCard(Modifier.fillMaxWidth(), padding = 24.dp) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassIcon(Res.drawable.ic_notifications, cs.primary, box = 56.dp, glyph = 30.dp)
                    Text(stringResource(Res.string.account_inbox_empty), color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
                }
            }
            else -> list.forEach { n ->
                GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), padding = 16.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            n.title,
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(agoText(n.at), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(n.body, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Support: chat, tickets and quick help in one place.
// ---------------------------------------------------------------------------------------------

@Composable
internal fun SupportChatPage(account: AccountRepository, contentPadding: PaddingValues, modifier: Modifier) {
    val loggedIn by account.loggedIn.collectAsState()
    val scroll = rememberScrollState()
    SettingsPageScaffold(
        title = stringResource(Res.string.sup_page_title),
        art = SettingsArts.Support,
        subtitle = stringResource(Res.string.sup_page_sub),
        contentPadding = contentPadding,
        modifier = modifier,
        scroll = scroll,
    ) {
        if (!loggedIn) LoginSection(account, stringResource(Res.string.support_login_reason)) else GlassPage {
            Column(Modifier.padding(top = 14.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                TicketsTab(account, scroll)
            }
        }
    }
}

/** A small centred day label between messages of different days. */
@Composable
private fun DayPill(text: String) {
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        GlassBadge(text, MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/**
 * One speech bubble. Mine sit on the end side, support's on the start side with a small avatar, in either
 * text direction. Under the text: the time, or "Sending…" while it is on its way.
 */
@Composable
private fun Bubble(m: AccountRepository.ChatMessage, sending: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    val mine = !m.fromSupport
    val shape = RoundedCornerShape(
        topStart = 20.dp,
        topEnd = 20.dp,
        bottomEnd = if (mine) 6.dp else 20.dp,
        bottomStart = if (mine) 20.dp else 6.dp,
    )
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Bottom,
    ) {
        if (!mine) {
            GlassIcon(Res.drawable.ic_headset, cs.tertiary, box = 32.dp, glyph = 18.dp)
            Spacer(Modifier.width(8.dp))
        }
        Column(
            Modifier
                .widthIn(max = 300.dp)
                .clip(shape)
                .background(if (mine) cs.primary.copy(alpha = if (sending) 0.12f else 0.24f) else cs.surfaceContainerHighest.copy(alpha = 0.75f))
                .border(1.dp, Color.White.copy(alpha = 0.10f), shape)
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            if (!mine) {
                Text(
                    stringResource(Res.string.sup_agent),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = cs.tertiary,
                )
            }
            Text(m.body, style = MaterialTheme.typography.bodyMedium)
            val meta = if (sending) stringResource(Res.string.sup_sending) else timeText(m.at)
            if (meta.isNotBlank()) {
                Text(
                    meta,
                    style = MaterialTheme.typography.labelSmall,
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.End),
                )
            }
        }
    }
}

/** Messages oldest first with a day label whenever the day changes, then what is still being sent. */
@Composable
private fun MessageList(messages: List<AccountRepository.ChatMessage>, pending: List<String>) {
    val jalali = stringResource(Res.string.wallet_use_jalali) == "true"
    val today = currentTimeMillis() / 1000 / 86_400
    val todayLabel = stringResource(Res.string.wallet_today)
    val yesterdayLabel = stringResource(Res.string.wallet_yesterday)
    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        var lastDay = Long.MIN_VALUE
        messages.forEach { m ->
            val day = if (m.at > 0) m.at.floorDiv(86_400L) else -1L
            if (day >= 0 && day != lastDay) {
                lastDay = day
                DayPill(
                    when (day) {
                        today -> todayLabel
                        today - 1 -> yesterdayLabel
                        else -> dayText(day * 86_400L, jalali)
                    },
                )
            }
            Bubble(m)
        }
        pending.forEach { text -> Bubble(AccountRepository.ChatMessage(Long.MAX_VALUE, false, text, 0L), sending = true) }
    }
}

/** The round send button; its arrow turns around in right-to-left layouts. */
@Composable
private fun SendButton(enabled: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    Surface(
        onClick = onClick,
        enabled = enabled,
        shape = CircleShape,
        color = if (enabled) cs.primary else cs.primary.copy(alpha = 0.30f),
        contentColor = cs.onPrimary,
        modifier = Modifier.size(54.dp),
    ) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Icon(
                painterResource(Res.drawable.ic_send),
                contentDescription = stringResource(Res.string.account_chat_send),
                modifier = Modifier.size(24.dp).graphicsLayer { scaleX = if (rtl) -1f else 1f },
            )
        }
    }
}

/** The text box and its send button on one glass card. */
@Composable
private fun Composer(
    text: String,
    onText: (String) -> Unit,
    placeholder: String,
    sending: Boolean,
    onSend: () -> Unit,
    top: @Composable () -> Unit = {},
) {
    GlassCard(Modifier.padding(horizontal = 16.dp).fillMaxWidth(), padding = 14.dp) {
        top()
        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassField(
                value = text,
                onValueChange = { onText(it.take(1500)) },
                modifier = Modifier.weight(1f),
                placeholder = placeholder,
                singleLine = false,
                minLines = 2,
            )
            SendButton(enabled = !sending && text.isNotBlank(), onClick = onSend)
        }
    }
}

@Composable
private fun EmptyChat(text: String) {
    val cs = MaterialTheme.colorScheme
    GlassCard(Modifier.padding(horizontal = 16.dp).fillMaxWidth(), padding = 24.dp) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassIcon(Res.drawable.ic_chat, cs.primary, box = 56.dp, glyph = 28.dp)
            Text(text, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
        }
    }
}

/** The load problem, in words, with a retry; the technical reason is the last line. */
@Composable
private fun LoadError(message: String, onRetry: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    GlassCard(Modifier.padding(horizontal = 16.dp).fillMaxWidth(), padding = 16.dp) {
        Text(stringResource(Res.string.sup_load_failed), fontWeight = FontWeight.SemiBold, color = cs.error)
        Text(message, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        Spacer(Modifier.height(10.dp))
        CapsuleButton(
            text = stringResource(Res.string.sup_retry),
            onClick = onRetry,
            container = cs.primary.copy(alpha = 0.16f),
            content = cs.primary,
            modifier = Modifier.fillMaxWidth(),
            height = 44.dp,
        )
    }
}

/** Keeps the newest message in view: after the list changes, the page scrolls to its end. */
@Composable
private fun ScrollToEnd(scroll: ScrollState, key: Any?) {
    LaunchedEffect(key) {
        delay(150)
        scroll.animateScrollTo(scroll.maxValue)
    }
}

/** The form for a new ticket: a topic, the text, and send. Opens the ticket when it is created. */
@Composable
private fun NewTicketForm(account: AccountRepository, onCancel: () -> Unit, onCreated: (String?, String?, String) -> Unit) {
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var text by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf(-1) }
    var sending by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    val topics = listOf(
        stringResource(Res.string.sup_topic_buy),
        stringResource(Res.string.sup_topic_connect),
        stringResource(Res.string.sup_topic_renew),
        stringResource(Res.string.sup_topic_other),
    )
    Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        GlassChip(stringResource(Res.string.sup_all_tickets), selected = false, onClick = onCancel)
    }
    Text(
        stringResource(Res.string.sup_new_title),
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(horizontal = 24.dp),
    )
    Text(
        stringResource(Res.string.sup_new_hint),
        style = MaterialTheme.typography.bodyMedium,
        color = cs.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 24.dp),
    )
    if (failed) GlassNotice(stringResource(Res.string.sup_send_failed), Modifier.padding(horizontal = 16.dp), tone = cs.error)
    Composer(
        text = text,
        onText = { text = it },
        placeholder = stringResource(Res.string.account_chat_placeholder),
        sending = sending,
        onSend = {
            val body = text.trim()
            if (body.isNotEmpty() && !sending) {
                sending = true
                failed = false
                val subject = topics.getOrNull(topic)
                scope.launch {
                    account.createTicket(subject, body).fold(
                        onSuccess = { id -> onCreated(id, subject, body) },
                        onFailure = { failed = true },
                    )
                    sending = false
                }
            }
        },
        top = {
            Text(
                stringResource(Res.string.sup_topic_title),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = cs.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                topics.forEachIndexed { i, label -> GlassChip(label, topic == i, { topic = if (topic == i) -1 else i }) }
            }
            Spacer(Modifier.height(12.dp))
        },
    )
}

private class TicketLook(val label: StringResource, val color: Color, val closed: Boolean = false, val answered: Boolean = false)

private fun ticketLook(status: String?): TicketLook {
    val s = status?.trim()?.lowercase().orEmpty()
    return when {
        "close" in s || "resolv" in s || "done" in s || "بسته" in s -> TicketLook(Res.string.sup_status_closed, Color(0xFF8E99A8), closed = true)
        "answer" in s || "repl" in s || "پاسخ" in s -> TicketLook(Res.string.sup_status_answered, Color(0xFF3DD6A3), answered = true)
        else -> TicketLook(Res.string.sup_status_open, Color(0xFFFFB84D))
    }
}

@Composable
private fun TicketsTab(account: AccountRepository, scroll: ScrollState) {
    val cs = MaterialTheme.colorScheme
    var tickets by remember { mutableStateOf<List<AccountRepository.TicketInfo>?>(null) }
    var failed by remember { mutableStateOf<String?>(null) }
    var open by remember { mutableStateOf<AccountRepository.TicketInfo?>(null) }
    var reload by remember { mutableStateOf(0) }
    var creating by remember { mutableStateOf(false) }
    val jalali = stringResource(Res.string.wallet_use_jalali) == "true"

    LaunchedEffect(open == null, creating, reload) {
        if (open == null) {
            account.tickets().fold(onSuccess = { tickets = it; failed = null }, onFailure = { failed = errorText(it) })
        }
    }

    if (creating) {
        NewTicketForm(
            account,
            onCancel = { creating = false },
            onCreated = { id, subject, body ->
                creating = false
                // Open the ticket that was just made, as the bot lists it, or as it was written.
                open = tickets?.firstOrNull { it.id == id }
                    ?: id?.let { AccountRepository.TicketInfo(it, subject, "open", currentTimeMillis() / 1000, body) }
                reload++
            },
        )
        return
    }
    val current = open
    if (current != null) {
        TicketThread(account, scroll, current, onBack = { open = null }, onNew = { open = null; creating = true })
        return
    }

    CapsuleButton(
        text = stringResource(Res.string.sup_new_ticket),
        onClick = { creating = true },
        container = cs.primary,
        content = cs.onPrimary,
        modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
        height = 50.dp,
    )
    val list = tickets
    when {
        failed != null && list == null -> LoadError(failed ?: "") { reload++ }
        list == null -> Text("…", color = cs.onSurfaceVariant, modifier = Modifier.padding(horizontal = 24.dp))
        list.isEmpty() -> GlassCard(Modifier.padding(horizontal = 16.dp).fillMaxWidth(), padding = 24.dp) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                GlassIcon(Res.drawable.ic_description, cs.primary, box = 56.dp, glyph = 28.dp)
                Spacer(Modifier.height(4.dp))
                Text(stringResource(Res.string.sup_tickets_empty), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    stringResource(Res.string.sup_tickets_empty_sub),
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
            }
        }
        else -> Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            list.forEach { t ->
                val look = ticketLook(t.status)
                GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), padding = 14.dp, onClick = { open = t }) {
                    Row(verticalAlignment = Alignment.Top) {
                        GlassIcon(Res.drawable.ic_chat, look.color)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    t.subject?.takeIf { it.isNotBlank() } ?: stringResource(Res.string.sup_ticket_n, t.id),
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    modifier = Modifier.weight(1f),
                                )
                                Spacer(Modifier.width(8.dp))
                                GlassBadge(stringResource(look.label), look.color)
                            }
                            t.text?.let {
                                Text(it, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, maxLines = 2)
                            }
                            val sub = listOfNotNull(
                                stringResource(Res.string.sup_ticket_n, t.id),
                                dayText(t.at, jalali).takeIf { it.isNotBlank() },
                                timeText(t.at).takeIf { it.isNotBlank() },
                            ).joinToString(" · ")
                            Text(sub, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
    HelpTab()
}

/** One ticket as a chat: its messages, then the reply box, with the page scrolled to the newest message. */
@Composable
private fun TicketThread(
    account: AccountRepository,
    scroll: ScrollState,
    ticket: AccountRepository.TicketInfo,
    onBack: () -> Unit,
    onNew: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val platform = LocalPlatform.current
    val cs = MaterialTheme.colorScheme
    var messages by remember { mutableStateOf<List<AccountRepository.ChatMessage>?>(null) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var text by remember { mutableStateOf("") }
    val pending = remember { mutableStateListOf<String>() }
    var sending by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    var tick by remember { mutableStateOf(0) }
    var raw by remember { mutableStateOf<String?>(null) }
    val look = ticketLook(ticket.status)
    val closed = look.closed

    LaunchedEffect(tick) {
        while (true) {
            account.ticketConversation(ticket.id).fold(
                onSuccess = { messages = it; loadError = null },
                onFailure = { loadError = errorText(it) },
            )
            delay(15_000)
        }
    }
    val list = messages
    ScrollToEnd(scroll, (list?.size ?: -1) * 100 + pending.size)

    Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        GlassChip(stringResource(Res.string.sup_all_tickets), selected = false, onClick = onBack)
        Spacer(Modifier.weight(1f))
        GlassBadge(stringResource(look.label), look.color)
    }
    Text(
        ticket.subject?.takeIf { it.isNotBlank() } ?: stringResource(Res.string.sup_ticket_n, ticket.id),
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(horizontal = 24.dp),
    )

    loadError?.let { e -> if (list == null) LoadError(e) { tick++ } }
    when {
        list == null -> if (loadError == null) Text("…", color = cs.onSurfaceVariant, modifier = Modifier.padding(horizontal = 24.dp))
        list.isEmpty() && pending.isEmpty() -> EmptyChat(stringResource(Res.string.account_chat_empty))
        else -> MessageList(list, pending)
    }
    if (list != null && list.isNotEmpty() && !list.last().fromSupport && !closed) {
        GlassNotice(stringResource(Res.string.sup_waiting_reply), Modifier.padding(horizontal = 16.dp), tone = Color(0xFFFFB84D))
    }
    if (answeredWithoutReply(ticket.status, list)) UnreadAnswer(account, ticket.id)
    if (failed) GlassNotice(stringResource(Res.string.sup_send_failed), Modifier.padding(horizontal = 16.dp), tone = cs.error)

    if (closed) {
        GlassNotice(stringResource(Res.string.sup_closed_note), Modifier.padding(horizontal = 16.dp))
        CapsuleButton(
            text = stringResource(Res.string.sup_new_ticket),
            onClick = onNew,
            container = cs.primary,
            content = cs.onPrimary,
            modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
            height = 50.dp,
        )
    } else {
        Composer(
            text = text,
            onText = { text = it },
            placeholder = stringResource(Res.string.sup_reply_hint),
            sending = sending,
            onSend = {
                val body = text.trim()
                if (body.isNotEmpty() && !sending) {
                    sending = true
                    failed = false
                    text = ""
                    pending.add(body)
                    scope.launch {
                        account.replyTicket(ticket.id, body).fold(
                            onSuccess = { pending.remove(body); tick++ },
                            onFailure = { failed = true; pending.remove(body); text = body },
                        )
                        sending = false
                    }
                }
            },
        )
    }

    // What the bot really sent for this ticket, for the rare case a reply does not show.
    Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        GlassChip(
            stringResource(Res.string.sup_debug),
            selected = raw != null,
            onClick = { if (raw == null) scope.launch { raw = account.ticketRaw(ticket.id) } else raw = null },
        )
        if (raw != null) {
            GlassChip(
                stringResource(Res.string.sup_debug_copy),
                selected = false,
                onClick = { raw?.let { platform.copyToClipboard(it) } },
            )
        }
    }
    raw?.let { r ->
        GlassCard(Modifier.padding(horizontal = 16.dp).fillMaxWidth(), padding = 12.dp) {
            androidx.compose.foundation.text.selection.SelectionContainer {
                Text(r, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}


/**
 * The bot's raw answer for one ticket, shown by itself when the ticket is marked as answered but no reply
 * could be read from it: the text to copy tells exactly where the reply is.
 */
@Composable
private fun UnreadAnswer(account: AccountRepository, ticketId: String) {
    val platform = LocalPlatform.current
    var raw by remember(ticketId) { mutableStateOf<String?>(null) }
    LaunchedEffect(ticketId) { raw = account.ticketRaw(ticketId) }
    GlassNotice(stringResource(Res.string.sup_answer_unreadable), Modifier.padding(horizontal = 16.dp), tone = Color(0xFFFFB84D))
    raw?.let { r ->
        GlassCard(Modifier.padding(horizontal = 16.dp).fillMaxWidth(), padding = 12.dp) {
            androidx.compose.foundation.text.selection.SelectionContainer {
                Text(r, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, style = MaterialTheme.typography.labelSmall)
            }
            Spacer(Modifier.height(8.dp))
            CapsuleButton(
                text = stringResource(Res.string.sup_debug_copy),
                onClick = { platform.copyToClipboard(r) },
                container = MaterialTheme.colorScheme.primary,
                content = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.fillMaxWidth(),
                height = 44.dp,
            )
        }
    }
}

private fun answeredWithoutReply(status: String?, list: List<AccountRepository.ChatMessage>?): Boolean =
    list != null && ticketLook(status).answered && list.none { it.fromSupport }

private class Faq(val q: StringResource, val a: StringResource)

private val FaqList = listOf(
    Faq(Res.string.sup_faq_q1, Res.string.sup_faq_a1),
    Faq(Res.string.sup_faq_q2, Res.string.sup_faq_a2),
    Faq(Res.string.sup_faq_q3, Res.string.sup_faq_a3),
    Faq(Res.string.sup_faq_q4, Res.string.sup_faq_a4),
)

/** Quick answers to the usual questions, and a door to Telegram. */
@Composable
private fun HelpTab() {
    val platform = LocalPlatform.current
    val cs = MaterialTheme.colorScheme
    val expanded = remember { mutableStateListOf<Int>() }

    GlassSectionTitle(stringResource(Res.string.sup_faq_title))
    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        FaqList.forEachIndexed { i, f ->
            val open = i in expanded
            GlassCard(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                padding = 16.dp,
                onClick = { if (open) expanded.remove(i) else expanded.add(i) },
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlassIcon(Res.drawable.ic_help, cs.primary, box = 36.dp, glyph = 20.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        stringResource(f.q),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f),
                    )
                    Icon(
                        painterResource(Res.drawable.ic_expand_more),
                        contentDescription = null,
                        tint = cs.onSurfaceVariant,
                        modifier = Modifier.size(22.dp).graphicsLayer { rotationZ = if (open) 180f else 0f },
                    )
                }
                if (open) {
                    Spacer(Modifier.height(10.dp))
                    Text(stringResource(f.a), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                }
            }
        }
    }

    GlassSectionTitle(stringResource(Res.string.sup_still_help))
    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), padding = 14.dp, onClick = { platform.openUri(AccountConfig.SUPPORT_URL) }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                GlassIcon(Res.drawable.ic_telegram, Color(0xFF4D9DFF))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(stringResource(Res.string.sup_telegram), style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                    Text(stringResource(Res.string.sup_telegram_sub), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
                Icon(
                    painterResource(Res.drawable.ic_open_in_new),
                    contentDescription = null,
                    tint = cs.onSurfaceVariant,
                    modifier = Modifier.size(20.dp),
                )
            }
        }
    }
}
