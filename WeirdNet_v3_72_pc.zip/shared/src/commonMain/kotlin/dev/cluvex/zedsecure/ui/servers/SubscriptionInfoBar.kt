package dev.cluvex.zedsecure.ui.servers

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.cluvex.zedsecure.domain.config.Subscription
import dev.cluvex.zedsecure.domain.config.SubscriptionHeaders
import dev.cluvex.zedsecure.shared.resources.Res
import dev.cluvex.zedsecure.shared.resources.ic_headset
import dev.cluvex.zedsecure.shared.resources.ic_link
import dev.cluvex.zedsecure.shared.resources.ic_public
import dev.cluvex.zedsecure.shared.resources.ic_telegram
import dev.cluvex.zedsecure.shared.resources.subs_banner_expired
import dev.cluvex.zedsecure.shared.resources.subs_banner_expires_in
import dev.cluvex.zedsecure.shared.resources.subs_banner_expires_today
import dev.cluvex.zedsecure.shared.resources.subs_days_left
import dev.cluvex.zedsecure.shared.resources.subs_expired
import dev.cluvex.zedsecure.shared.resources.subs_expires_today
import dev.cluvex.zedsecure.shared.resources.subs_no_expiry
import dev.cluvex.zedsecure.shared.resources.subs_one_day_left
import dev.cluvex.zedsecure.shared.resources.subs_open_support
import dev.cluvex.zedsecure.shared.resources.subs_open_website
import dev.cluvex.zedsecure.shared.resources.subs_quota_exhausted
import dev.cluvex.zedsecure.shared.resources.subs_renew
import dev.cluvex.zedsecure.ui.format.formatBytes
import dev.cluvex.zedsecure.ui.format.ltrIsolate
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

private const val DAY_MS = 86_400_000L

/** Happ shows the expiry banner when 3 or fewer full days remain (or after expiry). */
private const val EXPIRE_BANNER_DAYS = 3

/**
 * Subscription status bar laid out like Happ's:
 *
 *  [web-page icon] | used / total · expiry date | [support icon]
 *  ───────────────── progress ─────────────────
 *  announcement block (sub-expire banner > sub-info block > plain `announce`)
 *
 * - Left icon: subscription web page (`profile-web-page-url`); tinted when set, grey otherwise.
 * - Right icon: support (`support-url`); Telegram glyph for t.me links, generic link glyph otherwise.
 * - `total=0` is unlimited and `expire=0` is "no expiry" (both arrive here as null).
 * - Renders nothing when the provider sent no usage, expiry, link or announcement at all.
 */
@Composable
fun SubscriptionInfoBar(sub: Subscription, modifier: Modifier = Modifier, accent: Color? = null) {
    val used = sub.used
    val total = sub.total
    val expireAt = sub.expireAt
    val hasStatus = used != null || total != null || expireAt != null ||
        sub.webPageUrl != null || sub.supportUrl != null
    val hasAnnouncement = sub.announce != null || sub.subInfoText != null || sub.subExpire
    if (!hasStatus && !hasAnnouncement) return

    val uriHandler = LocalUriHandler.current
    val open: (String) -> Unit = { url -> runCatching { uriHandler.openUri(url) } }

    val now = dev.cluvex.zedsecure.platform.currentTimeMillis()
    val fraction = if (used != null && total != null && total > 0) {
        (used.toDouble() / total).toFloat().coerceIn(0f, 1f)
    } else null
    val expired = expireAt != null && expireAt <= now
    val daysLeft = expireAt?.let { Math.floorDiv(it - now, DAY_MS).toInt() }
    val exhausted = fraction != null && fraction >= 1f
    val warning = !expired && !exhausted &&
        ((fraction != null && fraction >= 0.8f) || (daysLeft != null && daysLeft <= EXPIRE_BANNER_DAYS))
    val dark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
    val stateColor = when {
        expired || exhausted -> MaterialTheme.colorScheme.error
        warning -> if (dark) Color(0xFFFFB74D) else Color(0xFF9A5B00)
        else -> accent ?: MaterialTheme.colorScheme.primary
    }

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (hasStatus) {
            StatusBar(
                sub = sub,
                used = used,
                total = total,
                expireAt = expireAt,
                fraction = fraction,
                expired = expired,
                exhausted = exhausted,
                daysLeft = daysLeft,
                warning = warning,
                stateColor = stateColor,
                onOpen = open,
            )
        }

        val expireBanner = sub.subExpire && expireAt != null &&
            (expired || (daysLeft != null && daysLeft <= EXPIRE_BANNER_DAYS))
        when {
            // Happ: the expiry notice has priority; the info block only shows when there is none.
            expireBanner -> {
                val text = when {
                    expired -> stringResource(Res.string.subs_banner_expired)
                    daysLeft == null || daysLeft <= 0 -> stringResource(Res.string.subs_banner_expires_today)
                    else -> stringResource(Res.string.subs_banner_expires_in, daysLeft)
                }
                AnnouncementBlock(
                    text = text,
                    accent = MaterialTheme.colorScheme.error,
                    buttonText = sub.subExpireButtonLink?.let { stringResource(Res.string.subs_renew) },
                    onButton = sub.subExpireButtonLink?.let { link -> { open(link) } },
                )
            }
            sub.subInfoText != null -> AnnouncementBlock(
                text = sub.subInfoText,
                accent = when (sub.subInfoColor) {
                    "red" -> MaterialTheme.colorScheme.error
                    "green" -> if (dark) Color(0xFF81C784) else Color(0xFF2E7D32)
                    else -> MaterialTheme.colorScheme.primary
                },
                buttonText = sub.subInfoButtonText?.takeIf { sub.subInfoButtonLink != null },
                onButton = sub.subInfoButtonLink?.let { link -> { open(link) } },
            )
            sub.announce != null -> AnnouncementBlock(
                text = sub.announce,
                accent = MaterialTheme.colorScheme.primary,
                buttonText = null,
                onButton = null,
            )
        }
    }
}

@Composable
private fun StatusBar(
    sub: Subscription,
    used: Long?,
    total: Long?,
    expireAt: Long?,
    fraction: Float?,
    expired: Boolean,
    exhausted: Boolean,
    daysLeft: Int?,
    warning: Boolean,
    stateColor: Color,
    onOpen: (String) -> Unit,
) {
    // "used / total" with the total after the slash; an unlimited plan reads "used / ∞".
    val usageText = used?.let {
        ltrIsolate("${formatBytes(it)} / ${total?.let(::formatBytes) ?: "∞"}")
    }
    val expiryText = when {
        expired -> stringResource(Res.string.subs_expired)
        exhausted -> stringResource(Res.string.subs_quota_exhausted)
        daysLeft == null -> if (used != null) stringResource(Res.string.subs_no_expiry) else null
        daysLeft <= 0 -> stringResource(Res.string.subs_expires_today)
        daysLeft == 1 -> stringResource(Res.string.subs_one_day_left)
        else -> stringResource(Res.string.subs_days_left, daysLeft)
    }
    val dateText = expireAt?.let { ltrIsolate(formatDate(it)) }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.72f),
        border = dev.cluvex.zedsecure.ui.components.glassBorder(),
        tonalElevation = 2.dp,
        shadowElevation = 3.dp,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(horizontal = 4.dp, vertical = 2.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Left: subscription web page. Tinted when the provider set it, grey when not.
                val web = sub.webPageUrl
                IconButton(onClick = { web?.let(onOpen) }, enabled = web != null, modifier = Modifier.size(40.dp)) {
                    Icon(
                        painterResource(Res.drawable.ic_public),
                        contentDescription = stringResource(Res.string.subs_open_website),
                        tint = if (web != null) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(22.dp),
                    )
                }

                Column(Modifier.weight(1f).padding(horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        usageText ?: dateText.orEmpty(),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (expiryText != null) {
                        Text(
                            if (dateText != null && usageText != null) "$expiryText · $dateText" else expiryText,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (expired || exhausted || warning) stateColor
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }

                // Right: support. Telegram glyph for t.me links, generic link glyph otherwise.
                val support = sub.supportUrl
                val appActions = dev.cluvex.zedsecure.ui.LocalAppActions.current
                if (support != null) {
                    // Support is answered inside the app; the provider's own link is only a fallback.
                    IconButton(
                        onClick = { appActions?.openSupport?.invoke() ?: onOpen(support) },
                        modifier = Modifier.size(40.dp),
                    ) {
                        Icon(
                            painterResource(Res.drawable.ic_headset),
                            contentDescription = stringResource(Res.string.subs_open_support),
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp),
                        )
                    }
                } else {
                    Box(Modifier.size(40.dp))
                }
            }
            if (fraction != null) {
                LinearProgressIndicator(
                    progress = { fraction },
                    color = stateColor,
                    trackColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).height(3.dp),
                )
            }
        }
    }
}

@Composable
private fun AnnouncementBlock(
    text: String,
    accent: Color,
    buttonText: String?,
    onButton: (() -> Unit)?,
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = accent.copy(alpha = 0.14f),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            Modifier.padding(start = 12.dp, end = if (buttonText != null) 4.dp else 12.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(width = 3.dp, height = 18.dp).background(accent, RoundedCornerShape(2.dp)))
            Text(
                text,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 4,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).padding(horizontal = 10.dp),
            )
            if (buttonText != null && onButton != null) {
                TextButton(onClick = onButton) {
                    Text(buttonText, color = accent, fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
        }
    }
}

/** yyyy-MM-dd (UTC) without any platform date API, so it works in commonMain. */
private fun formatDate(epochMs: Long): String {
    val z = Math.floorDiv(epochMs, 86_400_000L) + 719_468L
    val era = Math.floorDiv(z, 146_097L)
    val doe = z - era * 146_097L
    val yoe = (doe - doe / 1_460 + doe / 36_524 - doe / 146_096) / 365
    val doy = doe - (365 * yoe + yoe / 4 - yoe / 100)
    val mp = (5 * doy + 2) / 153
    val day = doy - (153 * mp + 2) / 5 + 1
    val month = if (mp < 10) mp + 3 else mp - 9
    val year = yoe + era * 400 + if (month <= 2) 1 else 0
    return "%04d-%02d-%02d".format(year, month, day)
}
