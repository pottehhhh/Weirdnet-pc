package dev.cluvex.zedsecure.ui.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.cluvex.zedsecure.data.account.AccountConfig
import dev.cluvex.zedsecure.data.account.AccountRepository
import dev.cluvex.zedsecure.platform.currentTimeMillis
import dev.cluvex.zedsecure.shared.resources.*
import dev.cluvex.zedsecure.ui.platform.LocalPlatform
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.getString
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

// ---------------------------------------------------------------------------------------------
// A small "liquid glass" kit for the account screens: translucent layers, a bright hairline edge,
// generous radii, big numerals and capsule buttons.
// ---------------------------------------------------------------------------------------------

internal val GlassShape = RoundedCornerShape(30.dp)
private val TileShape = RoundedCornerShape(26.dp)

@Composable
internal fun isDark(): Boolean = MaterialTheme.colorScheme.surface.luminance() < 0.5f

@Composable
private fun glassFill(): Brush {
    val cs = MaterialTheme.colorScheme
    val dark = isDark()
    return Brush.verticalGradient(
        listOf(
            cs.surfaceContainerHighest.copy(alpha = if (dark) 0.78f else 0.86f),
            cs.surfaceContainerHigh.copy(alpha = if (dark) 0.58f else 0.66f),
        ),
    )
}

@Composable
private fun glassEdge(): Brush {
    val dark = isDark()
    return Brush.verticalGradient(
        listOf(
            Color.White.copy(alpha = if (dark) 0.26f else 0.95f),
            Color.White.copy(alpha = if (dark) 0.04f else 0.30f),
        ),
    )
}

/** A frosted card. Everything on the account screens sits on one of these. */
@Composable
internal fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = GlassShape,
    padding: androidx.compose.ui.unit.Dp = 18.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    // Pressing a tappable card gives a little, springy squeeze, like a control on iOS.
    val source = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (onClick != null && pressed) 0.97f else 1f,
        animationSpec = androidx.compose.animation.core.spring(dampingRatio = 0.62f, stiffness = 520f),
        label = "glass-press",
    )
    val base = modifier
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .clip(shape)
        .background(glassFill())
        .border(1.dp, glassEdge(), shape)
    Column(
        (if (onClick != null) base.clickable(interactionSource = source, indication = null, onClick = onClick) else base).padding(padding),
        content = content,
    )
}

@Composable
internal fun GlassSectionTitle(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(start = 24.dp, end = 24.dp, top = 8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        if (subtitle != null) {
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}


// ---------------------------------------------------------------------------------------------
// The rest of the glass kit: page glow, icon bubble, badge, chips, segmented control, field, notice.
// ---------------------------------------------------------------------------------------------

/** A soft tinted glow behind a whole page, so the glass layers on top have something to catch. */
@Composable
internal fun GlassPage(content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    val a = cs.primary
    val b = cs.tertiary
    Box(
        Modifier.fillMaxWidth().drawBehind {
            drawRect(
                Brush.radialGradient(
                    listOf(a.copy(alpha = 0.22f), Color.Transparent),
                    center = Offset(size.width, 0f),
                    radius = size.width * 0.95f,
                ),
            )
            drawRect(
                Brush.radialGradient(
                    listOf(b.copy(alpha = 0.16f), Color.Transparent),
                    center = Offset(0f, size.height * 0.45f),
                    radius = size.width * 0.85f,
                ),
            )
        },
    ) {
        Column(Modifier.fillMaxWidth(), content = content)
    }
}

/** The round tinted bubble that carries an icon. */
@Composable
internal fun GlassIcon(
    icon: DrawableResource,
    accent: Color,
    modifier: Modifier = Modifier,
    box: Dp = 40.dp,
    glyph: Dp = 22.dp,
) {
    Box(
        modifier.size(box).clip(CircleShape).background(accent.copy(alpha = 0.18f)),
        contentAlignment = Alignment.Center,
    ) {
        Icon(painterResource(icon), contentDescription = null, tint = accent, modifier = Modifier.size(glyph))
    }
}

/** A small tinted capsule for a state ("Successful", "Open", "Pending"). */
@Composable
internal fun GlassBadge(text: String, color: Color, modifier: Modifier = Modifier) {
    Surface(shape = CircleShape, color = color.copy(alpha = 0.16f), contentColor = color, modifier = modifier) {
        Text(
            text,
            Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
        )
    }
}

/** A selectable capsule: filters, topics, quick amounts. */
@Composable
internal fun GlassChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    accent: Color = MaterialTheme.colorScheme.primary,
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = if (selected) accent.copy(alpha = 0.20f) else cs.surfaceContainerHighest.copy(alpha = 0.55f),
        contentColor = if (selected) accent else cs.onSurface,
        border = BorderStroke(1.dp, if (selected) accent.copy(alpha = 0.85f) else cs.outlineVariant.copy(alpha = 0.6f)),
        modifier = modifier,
    ) {
        Text(
            text,
            Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
        )
    }
}

/** An iOS-style segmented control on a glass capsule. */
@Composable
internal fun GlassSegmented(
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    GlassCard(modifier.fillMaxWidth(), shape = CircleShape, padding = 4.dp) {
        Row(Modifier.fillMaxWidth()) {
            options.forEachIndexed { i, label ->
                CapsuleButton(
                    text = label,
                    onClick = { onSelect(i) },
                    container = if (selected == i) cs.primary else Color.Transparent,
                    content = if (selected == i) cs.onPrimary else cs.onSurface,
                    modifier = Modifier.weight(1f),
                    height = 40.dp,
                )
            }
        }
    }
}

/** A rounded text field with a faint glass fill. */
@Composable
internal fun GlassField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: String? = null,
    placeholder: String? = null,
    singleLine: Boolean = true,
    minLines: Int = 1,
    keyboardType: KeyboardType = KeyboardType.Text,
    mono: Boolean = false,
    supporting: String? = null,
) {
    val cs = MaterialTheme.colorScheme
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth(),
        label = if (label != null) { { Text(label) } } else null,
        placeholder = if (placeholder != null) { { Text(placeholder) } } else null,
        supportingText = if (supporting != null) { { Text(supporting) } } else null,
        singleLine = singleLine,
        minLines = if (singleLine) 1 else minLines,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        textStyle = if (mono) {
            androidx.compose.material3.LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, textDirection = TextDirection.Ltr)
        } else {
            androidx.compose.material3.LocalTextStyle.current
        },
        shape = RoundedCornerShape(22.dp),
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedContainerColor = Color.White.copy(alpha = if (isDark()) 0.05f else 0.35f),
            focusedContainerColor = Color.White.copy(alpha = if (isDark()) 0.08f else 0.50f),
            unfocusedBorderColor = cs.outlineVariant.copy(alpha = 0.7f),
        ),
    )
}

/** A one-line (or short) message on a glass card, with a coloured dot. Tap to dismiss when [onClick] is given. */
@Composable
internal fun GlassNotice(
    text: String,
    modifier: Modifier = Modifier,
    tone: Color = MaterialTheme.colorScheme.primary,
    onClick: (() -> Unit)? = null,
) {
    GlassCard(modifier.fillMaxWidth(), padding = 14.dp, shape = RoundedCornerShape(24.dp), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(tone))
            Spacer(Modifier.width(10.dp))
            Text(text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        }
    }
}

/** The container colour for dialogs, so they match the glass cards instead of a flat sheet. */
@Composable
internal fun glassDialogColor(): Color =
    MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = if (isDark()) 0.94f else 0.96f)

/** "2 min ago"-style text for the sync badge. */
@Composable
private fun agoLabel(atSec: Long, nowMs: Long): String {
    val s = ((nowMs / 1000) - atSec).coerceAtLeast(0)
    return when {
        s < 45 -> stringResource(Res.string.account_ago_now)
        s < 3600 -> stringResource(Res.string.account_ago_min, ((s + 30) / 60).coerceAtLeast(1).toString())
        s < 86400 -> stringResource(Res.string.account_ago_hour, (s / 3600).toString())
        else -> stringResource(Res.string.account_ago_day, (s / 86400).toString())
    }
}

/** The wallet: a big gradient card with the balance, the sync state and the two main actions. */
@Composable
internal fun WalletHero(
    balance: Long?,
    loading: Boolean,
    lastSync: Long,
    syncing: Boolean,
    offline: Boolean,
    onTopUp: () -> Unit,
    onBuy: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(36.dp)
    val a = cs.primary
    val b = lerp(cs.primary, cs.tertiary, 0.55f)
    var now by remember { mutableStateOf(currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(15_000)
            now = currentTimeMillis()
        }
    }
    Box(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(a, b)))
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.05f))), shape),
    ) {
        // The soft highlight a glass surface catches along its top.
        Box(
            Modifier
                .matchParentSize()
                .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.22f), Color.Transparent), endY = 260f)),
        )
        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(painterResource(Res.drawable.ic_wallet), contentDescription = null, tint = cs.onPrimary, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    stringResource(Res.string.account_balance),
                    style = MaterialTheme.typography.titleSmall,
                    color = cs.onPrimary.copy(alpha = 0.85f),
                    modifier = Modifier.weight(1f),
                )
                SyncPill(lastSync, syncing, offline, now)
            }
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    balance?.let { toman(it) } ?: if (loading) "…" else "—",
                    fontSize = 44.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = cs.onPrimary,
                )
                if (balance != null) {
                    Text(
                        stringResource(Res.string.account_toman),
                        style = MaterialTheme.typography.titleMedium,
                        color = cs.onPrimary.copy(alpha = 0.85f),
                        modifier = Modifier.padding(bottom = 8.dp),
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                CapsuleButton(
                    stringResource(Res.string.account_topup),
                    onClick = onTopUp,
                    container = cs.onPrimary.copy(alpha = 0.20f),
                    content = cs.onPrimary,
                    modifier = Modifier.weight(1f),
                )
                CapsuleButton(
                    stringResource(Res.string.account_buy_new),
                    onClick = onBuy,
                    container = cs.onPrimary,
                    content = cs.primary,
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun SyncPill(lastSync: Long, syncing: Boolean, offline: Boolean, nowMs: Long) {
    val cs = MaterialTheme.colorScheme
    val live = !offline && lastSync > 0
    val label = when {
        offline -> stringResource(Res.string.account_offline_short)
        syncing -> stringResource(Res.string.account_syncing)
        live -> stringResource(Res.string.account_sync_live, agoLabel(lastSync, nowMs))
        else -> stringResource(Res.string.account_syncing)
    }
    Surface(shape = CircleShape, color = cs.onPrimary.copy(alpha = 0.16f), contentColor = cs.onPrimary) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            if (syncing) {
                CircularProgressIndicator(modifier = Modifier.size(10.dp), strokeWidth = 1.5.dp, color = cs.onPrimary)
            } else {
                Box(
                    Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (live) Color(0xFF5BE584) else Color(0xFFFFB84D)),
                )
            }
            Spacer(Modifier.width(6.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
        }
    }
}

@Composable
internal fun CapsuleButton(
    text: String,
    onClick: () -> Unit,
    container: Color,
    content: Color,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    height: androidx.compose.ui.unit.Dp = 46.dp,
) {
    Surface(
        onClick = onClick,
        enabled = enabled,
        shape = CircleShape,
        color = container,
        contentColor = content,
        modifier = modifier.height(height),
    ) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text(text, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

/** A square-ish shortcut tile with a tinted icon. */
@Composable
internal fun GlassTile(
    icon: DrawableResource,
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    accent: Color = MaterialTheme.colorScheme.primary,
    onClick: () -> Unit,
) {
    GlassCard(modifier, shape = TileShape, padding = 14.dp, onClick = onClick) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(accent.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(painterResource(icon), contentDescription = null, tint = accent, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 1)
        if (subtitle != null) {
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

/** One service of the account on a glass card: plan logo, name, state, usage bar and days left. */
@Composable
internal fun ServiceGlassCard(svc: AccountRepository.Service, kind: Int, inApp: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    GlassCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            PlanBadge(kind)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    svc.email ?: svc.code,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                )
                val sub = listOfNotNull(svc.plan, if (inApp) stringResource(Res.string.account_in_app) else null).joinToString(" · ")
                if (sub.isNotBlank()) {
                    Text(
                        sub,
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
            StatusChip(svc)
        }
        Spacer(Modifier.height(14.dp))
        UsageBlock(svc)
    }
}

// ---------------------------------------------------------------------------------------------
// Free test: one card for every plan the bot offers a trial on.
// ---------------------------------------------------------------------------------------------

private sealed interface TrialUi {
    data object Busy : TrialUi
    data object Done : TrialUi
    data object Used : TrialUi
    data class Failed(val text: String) : TrialUi
}

/** 0 Standard, 1 Omega, 2 Gaming, 3 Unlimited: the same numbering the plan badges use. */
private fun trialKind(p: AccountRepository.PanelInfo): Int = when (p.label.uppercase()) {
    "OMEGA" -> 1
    "GAMING" -> 2
    "UNLIMITED" -> 3
    else -> 0
}

internal fun planAccent(kind: Int): Color = when (kind) {
    1 -> Color(0xFF4D9DFF)
    2 -> Color(0xFFFF8A65)
    3 -> Color(0xFFB197FC)
    else -> Color(0xFF3DD6A3)
}

private fun planIcon(kind: Int): DrawableResource = when (kind) {
    1 -> Res.drawable.ic_bolt
    2 -> Res.drawable.ic_plan_gaming
    3 -> Res.drawable.ic_plan_unlimited
    else -> Res.drawable.ic_plan_standard
}

/**
 * The free-test cards. Every tap answers on the card itself (spinner, then a check or the reason it
 * failed) and with a toast, so it is never silent. A new test service is added to the app at once.
 */
@Composable
internal fun TrialCarousel(account: AccountRepository, reload: Int = 0, onDone: () -> Unit = {}) {
    val scope = rememberCoroutineScope()
    val platform = LocalPlatform.current
    var loaded by remember { mutableStateOf(false) }
    var panels by remember { mutableStateOf<List<AccountRepository.PanelInfo>?>(null) }
    val states = remember { mutableStateMapOf<String, TrialUi>() }

    LaunchedEffect(reload) {
        panels = account.panels().getOrNull()
        loaded = true
    }

    GlassSectionTitle(stringResource(Res.string.account_trial), stringResource(Res.string.account_trial_sub))

    if (!loaded) {
        GlassCard(Modifier.padding(horizontal = 16.dp).fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
            }
        }
        return
    }

    // Every panel the bot sells from gets its own card, so a test can be taken from any plan. The bot decides
    // who may take one and when it is out of stock: a tap asks it and the card shows its own answer. Panels
    // that say "on" come first; when the list cannot be read, one card lets the bot pick its first panel.
    val cards = panels.orEmpty().sortedByDescending { it.trialEnabled }.ifEmpty {
        listOf(AccountRepository.PanelInfo(id = "", key = "", name = "", customEnabled = false, trialEnabled = true))
    }

    val title = stringResource(Res.string.account_trial)
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        cards.forEach { p ->
            val key = p.ref.ifBlank { "default" }
            val kind = trialKind(p)
            val known = p.label in AccountConfig.PANEL_KINDS.values
            val name = when {
                p.label.isBlank() -> title
                known -> "WEIRDNET " + p.label
                else -> p.label
            }
            TrialCard(
                name = name,
                kind = kind,
                state = states[key],
                onGet = {
                    states[key] = TrialUi.Busy
                    scope.launch {
                        account.trial(p.ref.takeIf { it.isNotBlank() }).fold(
                            onSuccess = { svc ->
                                svc?.let { account.addService(it) }
                                states[key] = TrialUi.Done
                                platform.toast(getString(Res.string.account_trial_done))
                                account.refresh()
                                onDone()
                            },
                            onFailure = { e ->
                                val text = errorText(e)
                                val used = (e as? AccountRepository.AccountException)?.message == "trial_already_used"
                                states[key] = if (used) TrialUi.Used else TrialUi.Failed(text)
                                platform.toast(text)
                            },
                        )
                    }
                },
            )
        }
    }
}

@Composable
private fun TrialCard(name: String, kind: Int, state: TrialUi?, onGet: () -> Unit) {
    val accent = planAccent(kind)
    val shape = RoundedCornerShape(30.dp)
    val ink = Color.White
    Box(
        Modifier
            .width(248.dp)
            .clip(shape)
            .background(Brush.linearGradient(listOf(accent, lerp(accent, Color.Black, 0.42f))))
            .border(BorderStroke(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.5f), Color.White.copy(alpha = 0.04f)))), shape),
    ) {
        Box(
            Modifier
                .matchParentSize()
                .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.20f), Color.Transparent), endY = 220f)),
        )
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.22f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(painterResource(planIcon(kind)), contentDescription = null, tint = ink, modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.height(10.dp))
            Text(name, color = ink, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(
                stringResource(Res.string.account_trial_free_once),
                color = ink.copy(alpha = 0.82f),
                style = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.height(10.dp))
            if (state is TrialUi.Failed) {
                Text(state.text, color = ink, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(bottom = 6.dp))
            }
            val label = when (state) {
                TrialUi.Done -> stringResource(Res.string.account_trial_added)
                TrialUi.Used -> stringResource(Res.string.account_trial_used_short)
                is TrialUi.Failed -> stringResource(Res.string.account_trial_retry)
                else -> stringResource(Res.string.account_trial_get)
            }
            val enabled = state == null || state is TrialUi.Failed
            Surface(
                onClick = onGet,
                enabled = enabled,
                shape = CircleShape,
                color = if (enabled) Color.White else Color.White.copy(alpha = 0.30f),
                contentColor = if (enabled) lerp(accent, Color.Black, 0.35f) else Color.White,
                modifier = Modifier.fillMaxWidth().height(46.dp),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    if (state == TrialUi.Busy) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                    } else {
                        Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1)
                    }
                }
            }
        }
    }
}


// ---------------------------------------------------------------------------------------------
// Sync center: what the bot and the app hold, and what the automatic sync changed.
// ---------------------------------------------------------------------------------------------

@Composable
private fun eventText(e: AccountRepository.SyncEvent): String = when (e.kind) {
    AccountRepository.SyncEvent.Kind.Added -> stringResource(Res.string.sync_ev_added, e.name)
    AccountRepository.SyncEvent.Kind.Removed -> stringResource(Res.string.sync_ev_removed, e.name)
    AccountRepository.SyncEvent.Kind.Relinked -> stringResource(Res.string.sync_ev_relinked, e.name)
    AccountRepository.SyncEvent.Kind.Trial -> stringResource(Res.string.sync_ev_trial, e.name)
}

@Composable
internal fun SyncCenterCard(account: AccountRepository, onSync: () -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val services by account.servicesFlow.collectAsState()
    val events by account.events.collectAsState()
    val syncing by account.syncing.collectAsState()
    val lastSync by account.lastSync.collectAsState()
    val offline by account.offline.collectAsState()
    val inBot = services.count { it.subLink != null }
    val inApp = services.count { s -> s.subLink?.let { account.isInApp(it) } == true }
    var now by remember { mutableStateOf(currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(15_000)
            now = currentTimeMillis()
        }
    }
    val inSync = inBot == inApp
    GlassCard(modifier.fillMaxWidth(), padding = 18.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GlassIcon(Res.drawable.ic_fill_sync, if (offline) Color(0xFFFFB84D) else planAccent(0))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(stringResource(Res.string.sync_center), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    when {
                        offline -> stringResource(Res.string.account_offline_short)
                        syncing -> stringResource(Res.string.account_syncing)
                        lastSync > 0 -> stringResource(Res.string.account_sync_live, agoLabel(lastSync, now))
                        else -> stringResource(Res.string.account_syncing)
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
            }
            GlassBadge(if (inSync) "$inApp / $inBot" else "$inApp / $inBot", if (inSync) planAccent(0) else Color(0xFFFFB84D))
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f)) {
                Text(inBot.toString(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                Text(stringResource(Res.string.sync_in_bot), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
            }
            Column(Modifier.weight(1f)) {
                Text(inApp.toString(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                Text(stringResource(Res.string.sync_in_app), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(stringResource(Res.string.sync_recent), style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
        Spacer(Modifier.height(6.dp))
        if (events.isEmpty()) {
            Text(stringResource(Res.string.sync_none), style = MaterialTheme.typography.bodyMedium)
        } else {
            events.take(4).forEach { e ->
                Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(6.dp).clip(CircleShape).background(planAccent(0)))
                    Spacer(Modifier.width(10.dp))
                    Text(eventText(e), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    Text(agoLabel(e.at, now), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        CapsuleButton(
            text = stringResource(Res.string.account_sync_now),
            onClick = onSync,
            container = cs.primary.copy(alpha = 0.14f),
            content = cs.primary,
            modifier = Modifier.fillMaxWidth(),
            enabled = !syncing,
            height = 46.dp,
        )
    }
}

/** Services that are about to run out: 3 days or less left, or 10% or less of the data. */
internal fun needsAttention(svc: AccountRepository.Service): Boolean {
    if (!isServiceActive(svc)) return false
    val days = daysLeft(svc.expiryMs)
    if (days != null && days in 0..3) return true
    val total = svc.totalBytes
    val used = svc.usedBytes
    return !isUnlimitedService(svc) && total != null && total > 0 && used != null && (total - used) * 10 <= total
}

/** One calm notice when some services need attention; tapping it opens them. */
@Composable
internal fun AttentionNotice(services: List<AccountRepository.Service>, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val n = services.count { needsAttention(it) }
    if (n == 0) return
    val cs = MaterialTheme.colorScheme
    GlassCard(modifier.fillMaxWidth(), padding = 14.dp, shape = RoundedCornerShape(24.dp), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(Color(0xFFFFB84D)))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(stringResource(Res.string.account_attention, n.toString()), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(stringResource(Res.string.account_attention_sub), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            Icon(painterResource(Res.drawable.ic_chevron_right), contentDescription = null, tint = cs.onSurfaceVariant, modifier = Modifier.size(20.dp))
        }
    }
}
