package dev.cluvex.zedsecure.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.cluvex.zedsecure.data.account.AccountConfig
import dev.cluvex.zedsecure.shared.resources.*
import dev.cluvex.zedsecure.ui.platform.LocalPlatform
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

/**
 * "Support & plans": everything that used to send people to Telegram now lives inside the app.
 * Buying, services, the support chat and the account are one tap away from here.
 */
@Composable
fun SupportPage(
    contentPadding: PaddingValues,
    modifier: Modifier,
    onOpen: (SettingsPage) -> Unit = {},
) {
    val platform = LocalPlatform.current
    val cs = MaterialTheme.colorScheme
    SettingsPageScaffold(
        title = stringResource(Res.string.support_title),
        subtitle = stringResource(Res.string.support_subtitle),
        contentPadding = contentPadding,
        modifier = modifier,
        art = SettingsArts.Support,
    ) {
        GlassPage {
            Column(Modifier.padding(top = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                GlassCard(Modifier.padding(horizontal = 16.dp).fillMaxWidth(), padding = 16.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        GlassIcon(Res.drawable.ic_wallet, cs.primary, box = 48.dp, glyph = 26.dp)
                        Text(stringResource(Res.string.support_intro), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    }
                }
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    HubCard(Res.drawable.ic_shopping_cart, stringResource(Res.string.support_buy_title), stringResource(Res.string.support_buy_sub), planAccent(0)) { onOpen(SettingsPage.Buy) }
                    HubCard(Res.drawable.ic_inventory, stringResource(Res.string.support_hub_services), stringResource(Res.string.svc_hub_sub), planAccent(1)) { onOpen(SettingsPage.Services) }
                    HubCard(Res.drawable.ic_headset, stringResource(Res.string.sup_page_title), stringResource(Res.string.sup_hub_sub), planAccent(2)) { onOpen(SettingsPage.SupportChat) }
                    HubCard(Res.drawable.ic_person, stringResource(Res.string.account_title), stringResource(Res.string.account_menu_sub), planAccent(3)) { onOpen(SettingsPage.Account) }
                    HubCard(Res.drawable.ic_telegram, stringResource(Res.string.sup_telegram), stringResource(Res.string.sup_telegram_sub), Color(0xFF4D9DFF)) {
                        platform.openUri(AccountConfig.SUPPORT_URL)
                    }
                }
            }
        }
    }
}

@Composable
private fun HubCard(icon: DrawableResource, label: String, sub: String, accent: Color, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    GlassCard(Modifier.fillMaxWidth(), padding = 14.dp, onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GlassIcon(icon, accent, box = 46.dp, glyph = 24.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            Icon(painterResource(Res.drawable.ic_chevron_right), contentDescription = null, tint = cs.onSurfaceVariant, modifier = Modifier.size(22.dp))
        }
    }
}
