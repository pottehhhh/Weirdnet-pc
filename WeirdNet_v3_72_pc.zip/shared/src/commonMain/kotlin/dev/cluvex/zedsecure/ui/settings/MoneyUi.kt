package dev.cluvex.zedsecure.ui.settings

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin
import kotlin.math.sqrt

private val Emphasized = CubicBezierEasing(0.2f, 0f, 0f, 1f)

/** How a money action ended: it went through, it was refused, or nobody can tell (the reply never came). */
internal enum class Outcome { Success, Failure, Unknown }

internal fun outcomeColor(o: Outcome): Color = when (o) {
    Outcome.Success -> Color(0xFF34C759)
    Outcome.Failure -> Color(0xFFFF453A)
    Outcome.Unknown -> Color(0xFFFF9F0A)
}

/**
 * The result mark: a ring draws itself, then a check (success), a cross that shakes once (failure) or an
 * exclamation (unknown) is drawn inside it. Everything is vector drawing, so it is sharp at any size.
 */
@Composable
internal fun ResultMark(outcome: Outcome, modifier: Modifier = Modifier, markSize: Dp = 104.dp) {
    val color = outcomeColor(outcome)
    val pop = remember(outcome) { Animatable(0.55f) }
    val ring = remember(outcome) { Animatable(0f) }
    val glyph = remember(outcome) { Animatable(0f) }
    val shake = remember(outcome) { Animatable(0f) }
    val haptics = LocalHapticFeedback.current

    LaunchedEffect(outcome) {
        launch { pop.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 380f)) }
        ring.animateTo(1f, tween(460, easing = Emphasized))
        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
        glyph.animateTo(1f, tween(360, easing = Emphasized))
        if (outcome == Outcome.Failure) shake.animateTo(1f, tween(420, easing = LinearEasing))
    }

    Canvas(
        modifier
            .size(markSize)
            .graphicsLayer {
                scaleX = pop.value
                scaleY = pop.value
                translationX = (sin(shake.value * PI.toFloat() * 4f) * (1f - shake.value) * 9.dp.toPx())
            },
    ) {
        val s = this.size.minDimension
        val stroke = s * 0.055f
        drawCircle(color.copy(alpha = 0.13f), radius = s / 2f)
        drawArc(
            color = color,
            startAngle = -90f,
            sweepAngle = 360f * ring.value,
            useCenter = false,
            topLeft = Offset(stroke / 2f, stroke / 2f),
            size = Size(s - stroke, s - stroke),
            style = Stroke(stroke, cap = StrokeCap.Round),
        )
        val w = s * 0.075f
        when (outcome) {
            Outcome.Success -> {
                val a = Offset(s * 0.30f, s * 0.53f)
                val b = Offset(s * 0.44f, s * 0.67f)
                val c = Offset(s * 0.72f, s * 0.36f)
                polyline(color, w, glyph.value, listOf(a, b, c))
            }
            Outcome.Failure -> {
                val t = glyph.value
                polyline(color, w, (t * 2f).coerceAtMost(1f), listOf(Offset(s * 0.35f, s * 0.35f), Offset(s * 0.65f, s * 0.65f)))
                polyline(color, w, ((t - 0.5f) * 2f).coerceIn(0f, 1f), listOf(Offset(s * 0.65f, s * 0.35f), Offset(s * 0.35f, s * 0.65f)))
            }
            Outcome.Unknown -> {
                val t = glyph.value
                polyline(color, w, (t * 1.6f).coerceAtMost(1f), listOf(Offset(s * 0.5f, s * 0.28f), Offset(s * 0.5f, s * 0.56f)))
                if (t > 0.6f) drawCircle(color, radius = w * 0.62f * ((t - 0.6f) / 0.4f), center = Offset(s * 0.5f, s * 0.71f))
            }
        }
    }
}

/** Draws the first [progress] (0..1) of the path through [points] as one rounded stroke. */
private fun DrawScope.polyline(color: Color, width: Float, progress: Float, points: List<Offset>) {
    if (progress <= 0f || points.size < 2) return
    val lengths = (0 until points.size - 1).map { i ->
        val dx = points[i + 1].x - points[i].x
        val dy = points[i + 1].y - points[i].y
        sqrt(dx * dx + dy * dy)
    }
    var left = lengths.sum() * progress.coerceIn(0f, 1f)
    for (i in lengths.indices) {
        if (left <= 0f) break
        val part = (left / lengths[i]).coerceAtMost(1f)
        val end = Offset(
            points[i].x + (points[i + 1].x - points[i].x) * part,
            points[i].y + (points[i + 1].y - points[i].y) * part,
        )
        drawLine(color, points[i], end, strokeWidth = width, cap = StrokeCap.Round)
        left -= lengths[i]
    }
}

/** A calm rounded sheet for results and forms: big corners, one column, room to breathe. */
@Composable
internal fun MoneySheet(onDismiss: () -> Unit, content: @Composable () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(34.dp),
            color = glassDialogColor(),
            contentColor = MaterialTheme.colorScheme.onSurface,
            tonalElevation = 0.dp,
            shadowElevation = 12.dp,
        ) { content() }
    }
}

/** The outcome of a withdrawal, transfer or renewal: the animated mark, a title, a sentence, one button. */
@Composable
internal fun ResultSheet(outcome: Outcome, title: String, body: String, button: String, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    MoneySheet(onDismiss = onClose) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            ResultMark(outcome)
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(body, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, textAlign = TextAlign.Center)
            CapsuleButton(
                text = button,
                onClick = onClose,
                container = outcomeColor(outcome),
                content = Color.White,
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                height = 52.dp,
            )
        }
    }
}

/** Two or three labels in one rounded track; the chosen one is lifted. Colours glide when the choice changes. */
@Composable
internal fun SegmentedTabs(labels: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier
            .fillMaxWidth()
            .height(40.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(cs.onSurface.copy(alpha = 0.06f))
            .padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        labels.forEachIndexed { i, label ->
            val on = i == selected
            val bg by animateColorAsState(if (on) cs.primary.copy(alpha = 0.18f) else Color.Transparent, tween(220), label = "seg-bg")
            val fg by animateColorAsState(if (on) cs.primary else cs.onSurfaceVariant, tween(220), label = "seg-fg")
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(11.dp))
                    .background(bg)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) {
                Text(label, color = fg, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal, style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

/** A thin progress bar that fills smoothly toward a goal. */
@Composable
internal fun GoalBar(fraction: Float, accent: Color, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val f by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(800, easing = Emphasized), label = "goal")
    Box(modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(cs.surfaceContainerHighest.copy(alpha = 0.8f))) {
        if (f > 0.001f) {
            Box(
                Modifier
                    .fillMaxWidth(f)
                    .fillMaxHeight()
                    .clip(CircleShape)
                    .background(Brush.horizontalGradient(listOf(accent.copy(alpha = 0.75f), accent))),
            )
        }
    }
}
