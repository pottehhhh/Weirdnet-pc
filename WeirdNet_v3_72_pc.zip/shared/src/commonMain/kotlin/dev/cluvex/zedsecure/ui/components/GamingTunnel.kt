package dev.cluvex.zedsecure.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.cluvex.zedsecure.domain.config.VpnProfile
import dev.cluvex.zedsecure.shared.resources.*
import kotlinx.coroutines.delay
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

private val GamingA = Color(0xFFFF5A36)
private val GamingB = Color(0xFFFFB02E)

/** A plain WireGuard server (not AmneziaWG) is the one the gaming tunnel carries. */
fun VpnProfile.usesGamingTunnel(enabled: Boolean): Boolean = enabled && protocol.equals("wireguard", ignoreCase = true)

/** Asks for the "Gaming tunnel on" banner; the overlay near the top of the app shows it for a moment. */
object GamingTunnelFlash {
    var token by mutableStateOf(0)
        private set
    var visible by mutableStateOf(false)
        private set

    fun show() {
        token += 1
        visible = true
    }

    internal fun hide() { visible = false }
}

/** A small fiery capsule with a slow pulse: this server runs on the gaming tunnel. */
@Composable
fun GamingTunnelBadge(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "gaming-badge")
    val glow by t.animateFloat(0.55f, 1f, infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Reverse), label = "glow")
    Surface(
        shape = CircleShape,
        color = Color.Transparent,
        border = BorderStroke(1.dp, GamingA.copy(alpha = 0.35f + 0.4f * glow)),
        modifier = modifier,
    ) {
        Row(
            Modifier
                .padding(horizontal = 8.dp, vertical = 2.dp)
                .graphicsLayer { },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(painterResource(Res.drawable.ic_bolt), null, tint = GamingB.copy(alpha = glow), modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(3.dp))
            Text(
                stringResource(Res.string.gaming_badge),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.ExtraBold,
                color = GamingA,
                maxLines = 1,
            )
        }
    }
}

/** The banner that drops in from the top when a WireGuard server is chosen with the gaming tunnel on. */
@Composable
fun GamingTunnelOverlay(modifier: Modifier = Modifier) {
    val haptics = LocalHapticFeedback.current
    LaunchedEffect(GamingTunnelFlash.token) {
        if (GamingTunnelFlash.token == 0) return@LaunchedEffect
        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
        delay(2800)
        GamingTunnelFlash.hide()
    }
    Box(modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp), contentAlignment = Alignment.TopCenter) {
        AnimatedVisibility(
            visible = GamingTunnelFlash.visible,
            enter = slideInVertically(tween(420)) { -it } + fadeIn(tween(300)),
            exit = slideOutVertically(tween(320)) { -it } + fadeOut(tween(240)),
        ) { GamingBanner() }
    }
}

@Composable
private fun GamingBanner() {
    val t = rememberInfiniteTransition(label = "gaming-banner")
    val sweep by t.animateFloat(-0.3f, 1.3f, infiniteRepeatable(tween(1500, easing = LinearEasing)), label = "sweep")
    val pulse by t.animateFloat(0.9f, 1.12f, infiniteRepeatable(tween(700, easing = LinearEasing), RepeatMode.Reverse), label = "pulse")
    Surface(
        shape = RoundedCornerShape(26.dp),
        color = Color(0xFF1B1210),
        contentColor = Color.White,
        border = BorderStroke(1.dp, Brush.horizontalGradient(listOf(GamingA, GamingB))),
        shadowElevation = 14.dp,
    ) {
        Box {
            // A streak of light sliding across, like a speed line.
            Canvas(Modifier.matchParentSize()) {
                val x = size.width * sweep
                drawRect(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, GamingB.copy(alpha = 0.22f), Color.Transparent),
                        startX = x - 140f,
                        endX = x + 140f,
                    ),
                )
                drawCircle(
                    Brush.radialGradient(listOf(GamingA.copy(alpha = 0.45f), Color.Transparent), center = Offset(60.dp.toPx(), size.height / 2f), radius = 70.dp.toPx()),
                    radius = 70.dp.toPx(),
                    center = Offset(60.dp.toPx(), size.height / 2f),
                )
            }
            Row(Modifier.padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) {
                    Icon(
                        painterResource(Res.drawable.ic_bolt),
                        null,
                        tint = GamingB,
                        modifier = Modifier.size(34.dp).graphicsLayer { scaleX = pulse; scaleY = pulse },
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(stringResource(Res.string.gaming_flash_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                    Text(stringResource(Res.string.gaming_flash_sub), style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.72f))
                }
            }
        }
    }
}
