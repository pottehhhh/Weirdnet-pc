package dev.cluvex.zedsecure.ui.settings

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import dev.cluvex.zedsecure.data.account.AccountRepository
import dev.cluvex.zedsecure.shared.resources.*
import dev.cluvex.zedsecure.ui.platform.LocalPlatform
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.getString
import org.jetbrains.compose.resources.stringResource

/** What a pending money move is, for the confirmation sheet. */
private sealed interface Pending {
    class Withdraw(val amount: Long, val destination: String) : Pending
    class Transfer(val to: String, val amount: Long) : Pending
}

private class Done(val outcome: Outcome, val title: String, val body: String)

/** Referral income, withdrawing it, and sending balance to another user. */
@Composable
internal fun EarnPage(account: AccountRepository, contentPadding: PaddingValues, modifier: Modifier) {
    val loggedIn by account.loggedIn.collectAsState()
    SettingsPageScaffold(
        title = stringResource(Res.string.earn_title),
        art = SettingsArts.Account,
        subtitle = stringResource(Res.string.earn_sub),
        contentPadding = contentPadding,
        modifier = modifier,
    ) {
        if (!loggedIn) LoginSection(account) else GlassPage { EarnContent(account) }
    }
}

private const val DEFAULT_MIN = 200_000L

@Composable
private fun EarnContent(account: AccountRepository) {
    val platform = LocalPlatform.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val balance by account.balanceFlow.collectAsState()
    val offline by account.offline.collectAsState()

    var reload by remember { mutableStateOf(0) }
    var info by remember { mutableStateOf<AccountRepository.WithdrawInfo?>(null) }
    var tinfo by remember { mutableStateOf<AccountRepository.TransferInfo?>(null) }
    var referral by remember { mutableStateOf<AccountRepository.Referral?>(null) }
    var history by remember { mutableStateOf<List<AccountRepository.WithdrawItem>>(emptyList()) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var done by remember { mutableStateOf<Done?>(null) }
    var tab by remember { mutableStateOf(0) }
    var rulesOpen by remember { mutableStateOf(false) }

    var amount by remember { mutableStateOf("") }
    var destination by remember { mutableStateOf("") }
    var sendTo by remember { mutableStateOf("") }
    var sendAmount by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<Pending?>(null) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(reload) {
        account.balance()
        account.withdrawInfo().fold(onSuccess = { info = it; loadError = null }, onFailure = { loadError = errorText(it) })
        account.transferInfo().fold(onSuccess = { tinfo = it }, onFailure = { })
        account.referral().fold(onSuccess = { referral = it }, onFailure = { })
        account.withdraws().fold(onSuccess = { history = it }, onFailure = { })
    }

    val jalali = stringResource(Res.string.wallet_use_jalali) == "true"
    val tomanWord = stringResource(Res.string.account_toman)
    val inFlight = busy || offline
    val accent = Color(0xFF34C759)

    // Withdrawal covers ONLY referral earnings: never fall back to the wallet balance.
    val w = info
    val earned = w?.withdrawable
    val goal = (w?.minAmount ?: 0L).takeIf { it > 0 } ?: DEFAULT_MIN
    val wAmount = amount.toLongOrNull()
    val reached = earned != null && earned >= goal
    val wValid = w?.enabled == true && wAmount != null && wAmount > 0 && wAmount >= goal &&
        (earned == null || wAmount <= earned) && destination.trim().length >= 6

    val t = tinfo
    val tAmount = sendAmount.toLongOrNull()
    val tMin = t?.minAmount ?: 0L
    val tValid = t?.enabled == true && tAmount != null && tAmount > 0 && tAmount >= tMin &&
        (balance == null || tAmount <= balance!!) && sendTo.trim().length >= 3

    Column(
        Modifier.padding(top = 14.dp, bottom = 12.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        if (offline) GlassNotice(stringResource(Res.string.account_offline), tone = Color(0xFFFFB84D))
        loadError?.let { GlassNotice(it, tone = cs.error) }

        // ---- hero: what can be withdrawn, and how far it is from the minimum ----
        GlassCard(Modifier.fillMaxWidth(), padding = 20.dp) {
            Text(stringResource(Res.string.earn_hero_label), style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    earned?.let { toman(it) } ?: "—",
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (reached) accent else cs.onSurface,
                )
                Spacer(Modifier.width(6.dp))
                Text(tomanWord, style = MaterialTheme.typography.titleSmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 6.dp))
            }
            if (earned != null) {
                Spacer(Modifier.height(14.dp))
                GoalBar(fraction = earned.toFloat() / goal.toFloat(), accent = if (reached) accent else cs.primary)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (reached) stringResource(Res.string.earn_goal_ready) else stringResource(Res.string.earn_goal_left, toman(goal - earned)),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = if (reached) accent else cs.onSurface,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        "${(earned * 100 / goal).coerceAtMost(100)}٪".let { if (stringResource(Res.string.wallet_use_jalali) == "true") it else it.replace("٪", "%") },
                        style = MaterialTheme.typography.labelMedium,
                        color = cs.onSurfaceVariant,
                    )
                }
                Text(stringResource(Res.string.earn_goal_of, toman(goal)), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            }
            Spacer(Modifier.height(12.dp))
            Text(stringResource(Res.string.earn_referral_only_note), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(Res.string.earn_balance_total), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
                Text((balance?.let { toman(it) } ?: "—") + " " + tomanWord, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            }
        }

        // ---- withdraw / transfer ----
        SegmentedTabs(
            labels = listOf(stringResource(Res.string.earn_tab_withdraw), stringResource(Res.string.earn_tab_transfer)),
            selected = tab,
            onSelect = { tab = it },
        )
        AnimatedContent(
            targetState = tab,
            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(140)) },
            label = "earn-tab",
        ) { page ->
            GlassCard(Modifier.fillMaxWidth(), padding = 18.dp) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (page == 0) {
                        when {
                            w == null -> Text("…", color = cs.onSurfaceVariant)
                            !w.enabled -> Text(stringResource(Res.string.withdraw_disabled), color = cs.onSurfaceVariant)
                            else -> {
                                w.label?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
                                GlassField(
                                    value = amount,
                                    onValueChange = { amount = it.filter(Char::isDigit).take(10) },
                                    label = stringResource(Res.string.withdraw_amount),
                                    keyboardType = KeyboardType.Number,
                                    supporting = stringResource(Res.string.withdraw_min, toman(goal)),
                                )
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    CapsuleButton(
                                        text = stringResource(Res.string.withdraw_min_chip),
                                        onClick = { amount = goal.toString() },
                                        container = cs.surfaceContainerHighest.copy(alpha = 0.8f),
                                        content = cs.onSurface,
                                        modifier = Modifier.weight(1f),
                                        enabled = earned == null || earned >= goal,
                                        height = 36.dp,
                                    )
                                    CapsuleButton(
                                        text = stringResource(Res.string.withdraw_all),
                                        onClick = { earned?.let { amount = it.toString() } },
                                        container = cs.surfaceContainerHighest.copy(alpha = 0.8f),
                                        content = cs.onSurface,
                                        modifier = Modifier.weight(1f),
                                        enabled = earned != null && earned > 0,
                                        height = 36.dp,
                                    )
                                }
                                GlassField(
                                    value = destination,
                                    onValueChange = { destination = it.take(120) },
                                    label = stringResource(Res.string.withdraw_dest),
                                    supporting = stringResource(Res.string.withdraw_dest_hint),
                                    mono = true,
                                )
                                CapsuleButton(
                                    text = stringResource(Res.string.withdraw_go),
                                    onClick = { pending = Pending.Withdraw(wAmount ?: 0L, destination.trim()) },
                                    container = cs.primary,
                                    content = cs.onPrimary,
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = wValid && !inFlight,
                                    height = 52.dp,
                                )
                                if (earned != null && earned <= 0L) {
                                    Text(stringResource(Res.string.withdraw_blocked_none), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                                } else if (earned != null && !reached) {
                                    Text(stringResource(Res.string.withdraw_blocked_min), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                                }
                            }
                        }
                    } else {
                        when {
                            t == null -> Text("…", color = cs.onSurfaceVariant)
                            !t.enabled -> Text(stringResource(Res.string.transfer_disabled), color = cs.onSurfaceVariant)
                            else -> {
                                Text(
                                    stringResource(if (t.needsApproval) Res.string.transfer_mode_approve else Res.string.transfer_mode_auto),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = cs.onSurfaceVariant,
                                )
                                GlassField(
                                    value = sendTo,
                                    onValueChange = { sendTo = it.replace(" ", "").take(40) },
                                    label = stringResource(Res.string.transfer_to),
                                    supporting = stringResource(Res.string.transfer_to_hint),
                                    mono = true,
                                )
                                GlassField(
                                    value = sendAmount,
                                    onValueChange = { sendAmount = it.filter(Char::isDigit).take(10) },
                                    label = stringResource(Res.string.transfer_amount),
                                    keyboardType = KeyboardType.Number,
                                    supporting = if (tMin > 0) stringResource(Res.string.withdraw_min, toman(tMin)) else null,
                                )
                                CapsuleButton(
                                    text = stringResource(Res.string.transfer_go),
                                    onClick = { pending = Pending.Transfer(sendTo.trim(), tAmount ?: 0L) },
                                    container = cs.primary,
                                    content = cs.onPrimary,
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = tValid && !inFlight,
                                    height = 52.dp,
                                )
                            }
                        }
                    }
                }
            }
        }

        if (history.isNotEmpty()) {
            GlassSectionTitle(stringResource(Res.string.withdraw_history))
            GlassCard(Modifier.fillMaxWidth(), padding = 14.dp) {
                history.take(20).forEachIndexed { i, h ->
                    val st = statusLook(h.status)
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                (h.amount?.let { toman(it) } ?: "—") + " " + tomanWord,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                            )
                            val sub = listOfNotNull(
                                h.destination?.let { maskDestination(it) },
                                h.at.takeIf { it > 0 }?.let { dayText(it, jalali) },
                            ).joinToString(" · ")
                            if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        }
                        Spacer(Modifier.width(8.dp))
                        if (st != null) GlassBadge(stringResource(st.label), st.color)
                        else h.status?.let { GlassBadge(it, cs.onSurfaceVariant) }
                    }
                    if (i < history.take(20).lastIndex) androidx.compose.material3.HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                }
            }
        }

        // ---- the invite link and what it earned ----
        GlassSectionTitle(stringResource(Res.string.account_referral))
        referral?.link?.let { link ->
            InviteCard(
                link = link,
                onCopy = {
                    platform.copyToClipboard(link)
                    scope.launch { platform.toast(getString(Res.string.account_link_copied)) }
                },
                onShare = { platform.shareText(link) },
            )
        }
        referral?.let { r ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                r.invited?.let { Stat(stringResource(Res.string.account_ref_invited), it.toString(), Modifier.weight(1f)) }
                r.reward?.let { Stat(stringResource(Res.string.account_ref_reward), toman(it), Modifier.weight(1f)) }
            }
        }

        // ---- rules, folded away until wanted ----
        GlassCard(Modifier.fillMaxWidth(), padding = 16.dp, onClick = { rulesOpen = !rulesOpen }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(Res.string.earn_rules_toggle), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text(if (rulesOpen) "−" else "+", style = MaterialTheme.typography.titleLarge, color = cs.onSurfaceVariant)
            }
            AnimatedVisibility(rulesOpen, enter = expandVertically(tween(260)) + fadeIn(tween(260)), exit = shrinkVertically(tween(200)) + fadeOut(tween(160))) {
                Column(Modifier.padding(top = 8.dp)) {
                    listOf(
                        Res.string.earn_rule_ref_only, Res.string.earn_rule_1, Res.string.earn_rule_2, Res.string.earn_rule_3,
                        Res.string.earn_rule_4, Res.string.earn_rule_5, Res.string.earn_rule_6, Res.string.earn_rule_7,
                    ).forEach { line ->
                        Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.Top) {
                            Text("•  ", color = cs.primary, fontWeight = FontWeight.Bold)
                            Text(stringResource(line), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }

    // Money moves are confirmed once, in a sheet with the exact amount and place written out.
    pending?.let { p ->
        MoneySheet(onDismiss = { if (!busy) pending = null }) {
            Column(
                Modifier.padding(horizontal = 24.dp, vertical = 26.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    stringResource(if (p is Pending.Withdraw) Res.string.withdraw_confirm_title else Res.string.transfer_confirm_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = cs.onSurfaceVariant,
                )
                val shownAmount = if (p is Pending.Withdraw) p.amount else (p as Pending.Transfer).amount
                Text(toman(shownAmount) + " " + tomanWord, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                Text(
                    if (p is Pending.Withdraw) p.destination else (p as Pending.Transfer).to,
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurface,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
                Text(
                    stringResource(Res.string.money_irreversible),
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
                CapsuleButton(
                    text = if (busy) "…" else stringResource(Res.string.money_confirm),
                    onClick = {
                        busy = true
                        scope.launch {
                            val failure: Throwable?
                            var result: Done? = null
                            when (p) {
                                is Pending.Withdraw -> {
                                    val r = account.withdraw(p.amount, p.destination)
                                    failure = r.exceptionOrNull()
                                    if (r.isSuccess) {
                                        amount = ""; destination = ""
                                        result = Done(Outcome.Success, getString(Res.string.result_withdraw_title), getString(Res.string.withdraw_ok))
                                    }
                                }
                                is Pending.Transfer -> {
                                    val r = account.transfer(p.to, p.amount)
                                    failure = r.exceptionOrNull()
                                    r.getOrNull()?.let {
                                        sendTo = ""; sendAmount = ""
                                        result = if (it.status?.lowercase() == "pending")
                                            Done(Outcome.Success, getString(Res.string.result_transfer_pending_title), getString(Res.string.transfer_ok_pending))
                                        else Done(Outcome.Success, getString(Res.string.result_transfer_title), getString(Res.string.transfer_ok_done))
                                    }
                                }
                            }
                            done = result ?: if ((failure as? AccountRepository.AccountException)?.kind == AccountRepository.AccountException.Kind.Network) {
                                // The reply never came: the move may or may not have happened, so it is not sent again.
                                Done(Outcome.Unknown, getString(Res.string.result_unknown_title), getString(Res.string.money_unknown))
                            } else Done(Outcome.Failure, getString(Res.string.result_failed_title), errorText(failure))
                            busy = false
                            pending = null
                            reload++
                        }
                    },
                    container = cs.primary,
                    content = cs.onPrimary,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    enabled = !busy,
                    height = 52.dp,
                )
                CapsuleButton(
                    text = stringResource(Res.string.account_close),
                    onClick = { pending = null },
                    container = Color.Transparent,
                    content = cs.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy,
                    height = 44.dp,
                )
            }
        }
    }

    done?.let { d ->
        ResultSheet(d.outcome, d.title, d.body, stringResource(Res.string.result_close)) { done = null }
    }
}

/** A card number or wallet address with only its end shown. */
private fun maskDestination(d: String): String {
    val t = d.trim()
    return when {
        t.length >= 12 && t.all(Char::isDigit) -> "•••• " + t.takeLast(4)
        t.length > 14 -> t.take(5) + "…" + t.takeLast(4)
        else -> t
    }
}
