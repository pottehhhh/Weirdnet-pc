package dev.cluvex.zedsecure.domain.config

/**
 * The only subscription providers this app accepts. A subscription link is recognised by its
 * host alone, so no user token or private link is ever stored in the app.
 *
 * A plan can be served from more than one host (for example when the panel moves to a new domain);
 * every host listed for a plan is accepted as that plan.
 */
object WeirdNetPlans {
    data class Plan(val name: String, val hosts: List<String>) {
        constructor(name: String, host: String) : this(name, listOf(host))

        /** The main host of the plan. */
        val host: String get() = hosts.first()
    }

    val all: List<Plan> = listOf(
        Plan("WEIRDNET STANDARD", listOf("standard.mikewave.ir", "sub.sefrtasad.com", "sub.shopfastpro.ir")),
        Plan("WEIRDNET OMEGA", "link.gridpointgo.com"),
        Plan("WEIRDNET GAMING", "consumers.alizadehstore.ir"),
        Plan("WEIRDNET UNLIMITED", "client.mastershoop.ir"),
    )

    fun match(url: String): Plan? {
        val t = url.trim()
        val scheme = when {
            t.startsWith("https://", ignoreCase = true) -> "https://"
            t.startsWith("http://", ignoreCase = true) -> "http://"
            else -> return null
        }
        val rest = t.substring(scheme.length)
        val cut = rest.indexOfFirst { it == '/' || it == '?' || it == '#' }
        val authority = if (cut < 0) rest else rest.substring(0, cut)
        val path = if (cut < 0) "" else rest.substring(cut)
        if (authority.contains('@')) return null
        if (path.trimStart('/').substringBefore('?').substringBefore('#').isEmpty()) return null
        val host = authority.substringBefore(':').trim().lowercase()
        return all.firstOrNull { host in it.hosts }
    }

    /** The plan family of a link: 0 Standard, 1 Omega, 2 Gaming, 3 Unlimited; null when the host is not a WEIRDNET one. */
    fun familyOf(url: String): Int? = match(url)?.let { all.indexOf(it) }
}
