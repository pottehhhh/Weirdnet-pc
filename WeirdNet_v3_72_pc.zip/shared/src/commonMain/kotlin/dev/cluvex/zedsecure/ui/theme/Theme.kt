package dev.cluvex.zedsecure.ui.theme

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Density
import com.materialkolor.PaletteStyle
import com.materialkolor.dynamicColorScheme
import com.materialkolor.dynamiccolor.ColorSpec
import com.materialkolor.ktx.animateColorScheme
import dev.cluvex.zedsecure.domain.model.AppDesign
import dev.cluvex.zedsecure.domain.model.ColorContrast
import dev.cluvex.zedsecure.domain.model.ColorStyle

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun ZedSecureTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,

    accentColor: Int = 0,
    amoledBlack: Boolean = false,

    colorStyle: ColorStyle = ColorStyle.ZedSecure,
    colorContrast: ColorContrast = ColorContrast.Standard,
    animateColors: Boolean = true,

    design: AppDesign = AppDesign.Portal,

    languageTag: String = "en",

    fontScale: Float = 1f,
    content: @Composable () -> Unit,
) {
    val system = if (dynamicColor) dynamicColorSchemeOrNull(darkTheme) else null
    val scheme = (system ?: rememberZedColorScheme(darkTheme, accentColor, colorStyle, colorContrast))
        .let { if (amoledBlack) it.amoled(darkTheme) else it }
    val colorScheme = if (animateColors) {
        animateColorScheme(scheme, animationSpec = { spring(stiffness = Spring.StiffnessMediumLow) })
    } else {
        scheme
    }

    val density = LocalDensity.current
    val scaled = remember(density, fontScale) {
        if (fontScale == 1f) density else Density(density.density, density.fontScale * fontScale)
    }
    MaterialExpressiveTheme(
        colorScheme = colorScheme,
        motionScheme = MotionScheme.expressive(),
        shapes = ZedShapes,
        typography = typographyFor(languageTag, design),
    ) {
        // Direction follows the app language, not the device locale: Persian is RTL, every other
        // supported language (English, Chinese, Russian) is LTR even on a Persian-locale device.
        val direction = if (languageTag == "fa") LayoutDirection.Rtl else LayoutDirection.Ltr
        CompositionLocalProvider(
            LocalDensity provides scaled,
            LocalAppDesign provides design,
            LocalLayoutDirection provides direction,
            content = content,
        )
    }
}

@Composable
fun rememberZedColorScheme(
    dark: Boolean,
    accent: Int,
    style: ColorStyle,
    contrast: ColorContrast,
): ColorScheme = remember(dark, accent, style, contrast) { zedColorScheme(dark, accent, style, contrast) }

fun zedColorScheme(dark: Boolean, accent: Int, style: ColorStyle, contrast: ColorContrast): ColorScheme {
    val seed = accentSeed(accent)
    return if (style == ColorStyle.ZedSecure) {
        val base = dynamicColorScheme(
            seedColor = seed,
            isDark = dark,
            primary = seed,
            secondary = BrandTeal,
            tertiary = BrandRose,
            style = PaletteStyle.TonalSpot,
            contrastLevel = contrast.level,
            specVersion = ColorSpec.SpecVersion.SPEC_2025,
        )
        // The default accent is the WEIRDNET brand look (navy surfaces, electric blue, neon red).
        if (accent == 0) base.weirdNetBrand(dark) else base
    } else {
        dynamicColorScheme(
            seedColor = seed,
            isDark = dark,
            style = style.palette,
            contrastLevel = contrast.level,
            specVersion = ColorSpec.SpecVersion.SPEC_2025,
        )
    }
}

fun accentSeed(index: Int): Color = AccentPresets.getOrNull(index)?.light ?: BrandIris

val ColorStyle.palette: PaletteStyle
    get() = when (this) {
        ColorStyle.ZedSecure, ColorStyle.TonalSpot -> PaletteStyle.TonalSpot
        ColorStyle.Vibrant -> PaletteStyle.Vibrant
        ColorStyle.Expressive -> PaletteStyle.Expressive
        ColorStyle.Rainbow -> PaletteStyle.Rainbow
        ColorStyle.FruitSalad -> PaletteStyle.FruitSalad
        ColorStyle.Fidelity -> PaletteStyle.Fidelity
        ColorStyle.Neutral -> PaletteStyle.Neutral
        ColorStyle.Monochrome -> PaletteStyle.Monochrome
    }

val LocalAppDesign = staticCompositionLocalOf { AppDesign.Portal }

@Composable
expect fun dynamicColorSchemeOrNull(darkTheme: Boolean): ColorScheme?

private fun ColorScheme.weirdNetBrand(dark: Boolean): ColorScheme = if (dark) copy(
    primary = Color(0xFF4DA3FF), onPrimary = Color(0xFF031636),
    primaryContainer = Color(0xFF0B3C8C), onPrimaryContainer = Color(0xFFD8E8FF),
    secondary = Color(0xFF9DB8EC), onSecondary = Color(0xFF0A1F45),
    secondaryContainer = Color(0xFF16305F), onSecondaryContainer = Color(0xFFD6E3FF),
    tertiary = Color(0xFFFF4A5C), onTertiary = Color(0xFF3B000A),
    tertiaryContainer = Color(0xFF6E0F1E), onTertiaryContainer = Color(0xFFFFDADD),
    background = Color(0xFF030A1C), onBackground = Color(0xFFE3ECFF),
    surface = Color(0xFF030A1C), onSurface = Color(0xFFE3ECFF),
    surfaceVariant = Color(0xFF14264D), onSurfaceVariant = Color(0xFFA3B7DE),
    surfaceDim = Color(0xFF030A1C), surfaceBright = Color(0xFF14264D),
    surfaceContainerLowest = Color(0xFF020716), surfaceContainerLow = Color(0xFF061230),
    surfaceContainer = Color(0xFF081A3D), surfaceContainerHigh = Color(0xFF0D2249),
    surfaceContainerHighest = Color(0xFF132B58),
    outline = Color(0xFF5D7BB5), outlineVariant = Color(0xFF1E3566),
    inverseSurface = Color(0xFFE3ECFF), inverseOnSurface = Color(0xFF0A1630), inversePrimary = Color(0xFF1F5BFF),
    surfaceTint = Color(0xFF4DA3FF),
    error = Color(0xFFFF5A6A), onError = Color(0xFF3B000A),
    errorContainer = Color(0xFF6E0F1E), onErrorContainer = Color(0xFFFFDADD),
) else copy(
    primary = Color(0xFF1F5BFF), onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD9E5FF), onPrimaryContainer = Color(0xFF001A4D),
    secondary = Color(0xFF42578A), onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFDCE5FF), onSecondaryContainer = Color(0xFF0A1F45),
    tertiary = Color(0xFFD71F35), onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFFFDAD9), onTertiaryContainer = Color(0xFF410008),
    background = Color(0xFFF5F8FF), onBackground = Color(0xFF0A1630),
    surface = Color(0xFFF5F8FF), onSurface = Color(0xFF0A1630),
    surfaceVariant = Color(0xFFDDE4F5), onSurfaceVariant = Color(0xFF44506B),
    surfaceContainerLowest = Color(0xFFFFFFFF), surfaceContainerLow = Color(0xFFEEF3FF),
    surfaceContainer = Color(0xFFE8EEFC), surfaceContainerHigh = Color(0xFFE1E8F8),
    surfaceContainerHighest = Color(0xFFDAE2F4),
    outline = Color(0xFF6F7BA0), outlineVariant = Color(0xFFC5CDE3),
    surfaceTint = Color(0xFF1F5BFF),
)
