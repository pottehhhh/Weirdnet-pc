package dev.cluvex.zedsecure.ui.home

import dev.cluvex.zedsecure.ui.components.glassEdge

import dev.cluvex.zedsecure.ui.components.glassBorder

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import dev.cluvex.zedsecure.data.account.AccountRepository
import dev.cluvex.zedsecure.shared.resources.*
import dev.cluvex.zedsecure.ui.settings.toman
import kotlinx.coroutines.delay
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

/** Height the quick bar takes at the top of Home; the Home designs start below it. */
val HomeQuickBarHeight: Dp = 52.dp

/**
 * The small strip at the top of Home: wallet balance on one side, and on the other support, messages and
 * "my account" as icons. The two icons that can have news show a count badge. It keeps the numbers fresh
 * by itself while Home is on screen, and adds services bought in the app that are not in it yet.
 */
@Composable
fun HomeQuickBar(
    account: AccountRepository,
    onSupport: () -> Unit,
    onInbox: () -> Unit,
    onAccount: () -> Unit,
    modifier: Modifier = Modifier,
    onSimple: (() -> Unit)? = null,
) {
    val loggedIn by account.loggedIn.collectAsState()
    val balance by account.balanceFlow.collectAsState()
    val unreadNotes by account.unreadNotes.collectAsState()
    val unreadSupport by account.unreadSupport.collectAsState()

    LaunchedEffect(loggedIn) {
        if (!loggedIn) return@LaunchedEffect
        account.sync()
        var round = 0
        while (true) {
            delay(60_000)
            round++
            if (round % 3 == 0) account.sync() else account.refreshUnread()
        }
    }

    val cs = MaterialTheme.colorScheme
    Row(
        modifier.fillMaxWidth().height(HomeQuickBarHeight).padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Surface(
            onClick = onAccount,
            shape = CircleShape,
            color = cs.surfaceContainerHigh.copy(alpha = 0.60f),
            border = glassBorder(),
            modifier = Modifier.widthIn(max = 190.dp),
        ) {
            Row(
                Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(
                    painterResource(if (loggedIn) Res.drawable.ic_wallet else Res.drawable.ic_person),
                    contentDescription = null,
                    tint = cs.tertiary,
                    modifier = Modifier.size(18.dp),
                )
                Text(
                    when {
                        !loggedIn -> stringResource(Res.string.home_signin)
                        balance != null -> toman(balance!!) + " " + stringResource(Res.string.account_toman)
                        else -> "…"
                    },
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = cs.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Spacer(Modifier.weight(1f))
        onSimple?.let { BarIcon(Res.drawable.ic_fill_apps, stringResource(Res.string.simple_title), 0, it) }
        BarIcon(Res.drawable.ic_headset, stringResource(Res.string.home_cd_support), unreadSupport, onSupport)
        BarIcon(Res.drawable.ic_person, stringResource(Res.string.home_cd_account), 0, onAccount)
    }
}

@Composable
private fun BarIcon(icon: DrawableResource, description: String, badge: Int, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(cs.surfaceContainerHigh.copy(alpha = 0.60f))
            .glassEdge(CircleShape)
            .clickable(onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        if (badge > 0) {
            BadgedBox(badge = { Badge { Text(if (badge > 9) "9+" else badge.toString()) } }) {
                Icon(painterResource(icon), contentDescription = null, tint = cs.onSurface, modifier = Modifier.size(20.dp))
            }
        } else {
            Icon(painterResource(icon), contentDescription = null, tint = cs.onSurface, modifier = Modifier.size(20.dp))
        }
    }
}
