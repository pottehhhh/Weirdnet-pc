package dev.cluvex.zedsecure.ui.theme

import androidx.compose.ui.graphics.Color

// WEIRDNET brand palette (from the logo): deep navy, electric blue, neon red, silver.
val BrandIris = Color(0xFF3D9BFF)
val BrandTeal = Color(0xFF1F5BFF)
val BrandRose = Color(0xFFFF3B4E)

val ZedLime = Color(0xFF3FB0FF)
val ZedOnLime = Color(0xFF031636)
val ZedHotPink = Color(0xFFFF3B4E)
val ZedViolet = Color(0xFF1747C8)
val ZedDeepViolet = Color(0xFF050F2B)
val ZedCyan = Color(0xFF8AD8FF)
