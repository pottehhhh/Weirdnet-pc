package dev.cluvex.zedsecure.ui.servers

import dev.cluvex.zedsecure.domain.config.VpnProfile
import java.util.Locale

/** Continents in the order they are listed. */
enum class Continent(val key: String) {
    Europe("EU"), Asia("AS"), NorthAmerica("NA"), SouthAmerica("SA"), Africa("AF"), Oceania("OC"), Other("XX"),
}

/** One line of the region-grouped server list. */
sealed interface RegionRow {
    val key: String

    data class ContinentHeader(val continent: Continent, val count: Int, val collapsed: Boolean) : RegionRow {
        override val key get() = "cont-${continent.key}"
    }

    data class CountryHeader(
        val code: String,
        val flag: String,
        val name: String,
        val count: Int,
        val collapsed: Boolean,
    ) : RegionRow {
        override val key get() = "ctry-$code"
    }

    data class Server(val profile: VpnProfile) : RegionRow {
        override val key get() = "srv-${profile.id}"
    }
}

/**
 * Sorts servers by the country in their name (the flag emoji WEIRDNET puts in front of it),
 * then by continent. Countries with more than one location get their own sub-group.
 */
object RegionGrouping {
    private const val RI_A = 0x1F1E6
    private const val RI_Z = 0x1F1FF

    /** "🇩🇪 Frankfurt" -> "DE". Null when the text has no flag. */
    fun flagCode(text: String): String? {
        var i = 0
        while (i < text.length) {
            val first = text.codePointAt(i)
            i += Character.charCount(first)
            if (first in RI_A..RI_Z && i < text.length) {
                val second = text.codePointAt(i)
                if (second in RI_A..RI_Z) {
                    return "" + ('A' + (first - RI_A)) + ('A' + (second - RI_A))
                }
            }
        }
        return null
    }

    fun flagOf(code: String): String {
        if (code.length != 2) return ""
        val a = code[0].uppercaseChar()
        val b = code[1].uppercaseChar()
        return String(Character.toChars(RI_A + (a - 'A'))) + String(Character.toChars(RI_A + (b - 'A')))
    }

    private val englishNames: Map<String, String> by lazy {
        Locale.getISOCountries().associateBy(
            { runCatching { Locale.Builder().setRegion(it).build().getDisplayCountry(Locale.ENGLISH).lowercase() }.getOrDefault(it) },
            { it },
        ) + mapOf("uk" to "GB", "usa" to "US", "uae" to "AE", "united states" to "US", "russia" to "RU", "turkiye" to "TR")
    }

    /** Persian names of common countries, for names like "آلمان 01". */
    private val persianNames = mapOf(
        "آلمان" to "DE", "فنلاند" to "FI", "هلند" to "NL", "فرانسه" to "FR", "انگلیس" to "GB", "بریتانیا" to "GB",
        "آمریکا" to "US", "امریکا" to "US", "کانادا" to "CA", "ترکیه" to "TR", "امارات" to "AE", "سوئد" to "SE",
        "سوید" to "SE", "سوئیس" to "CH", "سوییس" to "CH", "ژاپن" to "JP", "سنگاپور" to "SG", "روسیه" to "RU",
        "ایتالیا" to "IT", "اسپانیا" to "ES", "لهستان" to "PL", "اتریش" to "AT", "رومانی" to "RO", "اوکراین" to "UA",
        "هند" to "IN", "کره" to "KR", "استرالیا" to "AU", "هنگ کنگ" to "HK", "قزاقستان" to "KZ", "ارمنستان" to "AM",
        "ایرلند" to "IE", "نروژ" to "NO", "دانمارک" to "DK", "بلغارستان" to "BG", "چک" to "CZ", "ایران" to "IR",
        "عراق" to "IQ", "قطر" to "QA", "عمان" to "OM", "بحرین" to "BH", "کویت" to "KW", "ارمنستان" to "AM",
    )

    private val nameKeys: List<String> by lazy { englishNames.keys.filter { it.length > 3 }.sortedByDescending { it.length } }

    /** Short words that are also country codes: read as a country only when written in capitals ("IT", not "it"). */
    private val codeWords = codes("IN IT ME AS TO OR NO IS AT BY ON SO AN BE DO GO HE IF MY OF UP AD AM ID AL")

    /** "De Tr", "DE-01", "tr_fast": the first word that is a country code, or null. */
    private fun codeInName(name: String): String? {
        val valid = Locale.getISOCountries().toSet()
        for (token in name.split(Regex("[^\\p{L}]+"))) {
            if (token.length != 2 || !token.all { it in 'A'..'Z' || it in 'a'..'z' }) continue
            val up = token.uppercase()
            if (up !in valid) continue
            if (up in codeWords && token != up) continue
            return up
        }
        return null
    }

    /** A country named inside a longer name ("Germany Fast 01", "سرور آلمان"), or null. */
    private fun countryInName(name: String): String? {
        val lower = name.lowercase()
        persianNames.entries.firstOrNull { it.key in name }?.let { return it.value }
        val words = lower.split(Regex("[^\\p{L}]+")).filter { it.length > 2 }
        // Longest names first, so "south africa" is not read as something shorter.
        for (c in nameKeys) {
            if (c.contains(' ')) { if (c in lower) return englishNames[c] }
            else if (c in words) return englishNames[c]
        }
        return null
    }

    /**
     * Country code of a server: the flag in its name, then a country named in it, then where its address
     * is. Info lines of a subscription ("👤 Mike", "📊 2.87 GB") have no country, and neither do
     * WireGuard servers by their address, since that is usually a relay and not the exit.
     */
    fun countryOf(profile: VpnProfile): String? {
        if (profile.isInfoEntry) return null
        flagCode(profile.name)?.let { return it }
        val plain = profile.name.filter { it.isLetter() || it == ' ' }.trim().lowercase()
        englishNames[plain]?.let { return it }
        countryInName(profile.name)?.let { return it }
        codeInName(profile.name)?.let { return it }
        if (!profile.countryFromAddress) return null
        return profile.countryCode?.uppercase()?.takeIf { it.length == 2 }
    }

    fun countryName(code: String): String =
        runCatching { Locale.Builder().setRegion(code).build().getDisplayCountry(Locale.getDefault()) }
            .getOrDefault("").ifBlank { code }

    private fun codes(s: String) = s.split(' ').filter { it.isNotBlank() }.toSet()

    private val europe = codes("AL AD AT BY BE BA BG HR CY CZ DK EE FO FI FR DE GI GR GG HU IS IE IM IT JE XK LV LI LT LU MT MD MC ME NL MK NO PL PT RO RU SM RS SK SI ES SE CH UA GB VA AX")
    private val asia = codes("AF AM AZ BH BD BT BN KH CN GE HK IN ID IR IQ IL JP JO KZ KW KG LA LB MO MY MV MN MM NP KP OM PK PS PH QA SA SG KR LK SY TW TJ TH TL TR TM AE UZ VN YE")
    private val northAmerica = codes("US CA MX GT BZ SV HN NI CR PA CU JM HT DO BS BB TT PR GL BM KY AG DM GD KN LC VC AW CW SX BQ TC VG VI AI MS GP MQ BL MF PM")
    private val southAmerica = codes("AR BO BR CL CO EC GY PY PE SR UY VE FK GF")
    private val africa = codes("DZ AO BJ BW BF BI CM CV CF TD KM CG CD CI DJ EG GQ ER SZ ET GA GM GH GN GW KE LS LR LY MG MW ML MR MU MA MZ NA NE NG RW ST SN SC SL SO ZA SS SD TZ TG TN UG ZM ZW EH RE YT SH")
    private val oceania = codes("AU NZ FJ PG SB VU WS TO KI FM MH PW NR TV NC PF GU AS CK NU TK WF MP")

    fun continentOf(code: String?): Continent = when (code?.uppercase() ?: "") {
        in europe -> Continent.Europe
        in asia -> Continent.Asia
        in northAmerica -> Continent.NorthAmerica
        in southAmerica -> Continent.SouthAmerica
        in africa -> Continent.Africa
        in oceania -> Continent.Oceania
        else -> Continent.Other
    }

    /**
     * Builds the flat list shown by the grouped view. Everything starts folded; [open] holds the keys of the
     * continent / country headers the user unfolded. [expandAll] (used while searching) unfolds everything.
     * Every country gets a header, so single-server countries look the same as the others.
     */
    fun rows(servers: List<VpnProfile>, open: Set<String>, expandAll: Boolean = false): List<RegionRow> {
        val byContinent = servers.groupBy { continentOf(countryOf(it)) }
        val out = mutableListOf<RegionRow>()
        Continent.entries.forEach { continent ->
            val inContinent = byContinent[continent].orEmpty()
            if (inContinent.isEmpty()) return@forEach
            val foldedContinent = !expandAll && "cont-${continent.key}" !in open
            out += RegionRow.ContinentHeader(continent, inContinent.size, foldedContinent)
            if (foldedContinent) return@forEach
            val byCountry = inContinent.groupBy { countryOf(it) ?: "" }
            byCountry.entries
                .sortedWith(compareBy({ it.key.isEmpty() }, { if (it.key.isEmpty()) "" else countryName(it.key) }))
                .forEach { (code, list) ->
                    if (code.isNotEmpty()) {
                        val folded = !expandAll && "ctry-$code" !in open
                        out += RegionRow.CountryHeader(code, flagOf(code), countryName(code), list.size, folded)
                        if (!folded) list.forEach { out += RegionRow.Server(it) }
                    } else {
                        list.forEach { out += RegionRow.Server(it) }
                    }
                }
        }
        return out
    }
}
