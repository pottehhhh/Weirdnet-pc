package dev.cluvex.zedsecure.ui.settings

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import dev.cluvex.zedsecure.data.account.AccountRepository
import dev.cluvex.zedsecure.shared.resources.*
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource
import kotlin.random.Random

private fun renewRef(code: String) = "renew-" + code.takeLast(12) + "-" + Random.nextLong().toULong().toString(16)

/** One thing the service can be renewed with: a number of days (volume plans) or a user pack (unlimited). */
private class Choice(val option: AccountRepository.RenewOption?, val plan: AccountRepository.Plan?) {
    val price: Long? get() = plan?.let { pl -> pl.appPrice ?: pl.price } ?: option?.price
    val days: Long? get() = option?.days ?: plan?.days?.toLongOrNull()
}

/**
 * Renews one service from the wallet. Volume services pick a duration and, if they like, a volume on the
 * dial; unlimited services pick a user pack (one user, two users, ...). One confirmation, then an animated
 * result. The request carries a fixed reference, so pressing twice or retrying after a dropped connection can
 * never charge twice.
 */
@Composable
internal fun RenewDialog(
    account: AccountRepository,
    svc: AccountRepository.Service,
    onClose: (renewed: Boolean) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val balance by account.balanceFlow.collectAsState()
    val kind = account.kindOf(svc)
    val unlimited = kind == 3
    val accent = planAccent(kind)

    var info by remember { mutableStateOf<AccountRepository.RenewInfo?>(null) }
    var packs by remember { mutableStateOf<List<AccountRepository.Plan>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var picked by remember { mutableStateOf<Int?>(null) }
    var gb by remember { mutableStateOf<Int?>(null) }
    var dayPick by remember { mutableStateOf<Int?>(null) }
    var limits by remember { mutableStateOf<AccountRepository.PanelLimits?>(null) }
    var busy by remember { mutableStateOf(false) }
    var failure by remember { mutableStateOf<String?>(null) }
    var done by remember { mutableStateOf<AccountRepository.RenewResult?>(null) }

    LaunchedEffect(svc.code) {
        account.balance()
        if (!unlimited) account.custom().onSuccess { c -> limits = c.panels.firstOrNull { it.type.equals(listOf("STANDARD", "OMEGA", "GAMING").getOrNull(kind), ignoreCase = true) } }
        account.renewInfo(svc.code).fold(onSuccess = { info = it }, onFailure = { if (!unlimited) loadError = errorText(it) })
        if (unlimited) {
            account.plans().fold(
                onSuccess = { list -> packs = list.filter { it.isUnlimited }.sortedBy { it.ipLimit ?: Int.MAX_VALUE } },
                onFailure = { loadError = errorText(it) },
            )
        }
        loaded = true
    }

    // Unlimited services are renewed by user pack; volume services by duration + volume on the dial.
    val choices: List<Choice> = remember(packs, unlimited) {
        if (unlimited) packs.map { Choice(null, it) } else emptyList()
    }
    LaunchedEffect(choices.size) { if (choices.size == 1) picked = 0 }
    val choice = picked?.let { choices.getOrNull(it) }

    val table = remember(info) { info?.options.orEmpty().filter { it.planId == null && it.gb != null } }
    // The durations the bot allows for renewing come from renew_info itself (days_options). Only if it says nothing do the
    // plan's own limits decide; a single allowed value means the days are fixed and no control is shown.
    val dayList = remember(info) {
        // The bot's own days_options win; the days written in option rows are only used when it gave none.
        (info?.daysOptions.orEmpty().ifEmpty { info?.options.orEmpty().mapNotNull { it.days } }).distinct().sorted().map { it.toInt() }
    }
    val allowedDays: List<Int> = remember(dayList, limits) {
        val lo = limits?.minDays
        val hi = limits?.maxDays
        when {
            dayList.size > 1 -> dayList
            lo != null && hi != null && hi > lo -> (lo..hi).toList()
            else -> listOf(dayList.firstOrNull() ?: lo ?: 30)
        }
    }
    val daysAdjustable = !unlimited && allowedDays.size > 1
    val dayMin = allowedDays.first()
    val dayMax = allowedDays.last()
    fun snapDay(v: Int): Int = allowedDays.minByOrNull { kotlin.math.abs(it - v) } ?: v
    val days: Int? = when {
        unlimited -> choice?.days?.toInt()
        daysAdjustable -> snapDay(dayPick ?: 30)
        else -> dayMin
    }

    val current = svc.totalBytes?.let { (it / 1_073_741_824L).toInt() }?.takeIf { it > 0 }
    val minGb = (info?.gbMin ?: limits?.minGb?.toLong() ?: table.filter { it.gb!! > 0 }.minOfOrNull { it.gb!! } ?: 1L).toInt().coerceAtLeast(1)
    val maxGb = (info?.gbMax ?: limits?.maxGb?.toLong() ?: table.maxOfOrNull { it.gb!! } ?: 1000L).toInt().coerceAtLeast(minGb)
    val volumeAllowed = !unlimited && loaded && loadError == null
    // The bot lists a "0 GB" row: renew the time only, without adding volume.
    val canSkipVolume = table.any { it.gb == 0L }
    var noVolume by remember { mutableStateOf(false) }
    val skipVolume = canSkipVolume && noVolume
    val startGb = (current ?: minGb).coerceIn(minGb, maxGb)
    val chosenGb = (gb ?: startGb).coerceIn(minGb, maxGb)
    val effGb = if (skipVolume) 0 else chosenGb

    // The bot's own price list is linear (a price per day plus a price per GB), so any volume is priced from it exactly:
    // the "0 GB" row of a duration is the days alone, and two neighbouring GB rows give the price of one GB.
    val dayBase: Long? = days?.let { d -> table.firstOrNull { it.gb == 0L && it.days?.toInt() == d }?.price }
    val gbStep: Long? = days?.let { d ->
        val rows = table.filter { it.days?.toInt() == d && (it.gb ?: 0L) > 0L && it.price != null }.sortedBy { it.gb }
        if (rows.size >= 2 && rows[1].gb!! > rows[0].gb!!) (rows[1].price!! - rows[0].price!!) / (rows[1].gb!! - rows[0].gb!!) else null
    }
    val localPrice: Long? = if (!volumeAllowed || days == null) null else
        table.firstOrNull { it.gb?.toInt() == effGb && it.days?.toInt() == days }?.price
            ?: if (dayBase != null && effGb == 0) dayBase
            else if (dayBase != null && gbStep != null) dayBase + gbStep * effGb
            else null

    // Only when the list cannot price it does a live quote ask the bot.
    var quoted by remember { mutableStateOf<Long?>(null) }
    var quoting by remember { mutableStateOf(false) }
    LaunchedEffect(volumeAllowed, effGb, days, localPrice) {
        quoted = null
        if (!volumeAllowed || days == null || localPrice != null || effGb == 0) { quoting = false; return@LaunchedEffect }
        quoting = true
        kotlinx.coroutines.delay(350)
        account.quote(null, effGb, days, svc.panel).fold(onSuccess = { quoted = it.finalPrice }, onFailure = { })
        quoting = false
    }
    val shownPrice: Long? = if (unlimited) choice?.price else localPrice ?: quoted
    val enough = shownPrice == null || balance == null || balance!! >= shownPrice
    val after = if (shownPrice != null && balance != null) balance!! - shownPrice else null
    val canGo = (if (unlimited) choice != null else volumeAllowed) && enough && !busy && !quoting

    val ref = refFor(svc.code, choice, if (volumeAllowed) effGb else null, days)

    fun submit() {
        val c = choice
        if (unlimited && c == null) return
        busy = true
        failure = null
        scope.launch {
            account.renew(
                service = svc.code,
                ref = ref,
                days = if (c?.plan != null) null else days,
                gb = if (volumeAllowed && effGb > 0) effGb else null,
                planId = c?.plan?.id,
            ).fold(onSuccess = { done = it }, onFailure = { failure = errorText(it) })
            busy = false
        }
    }

    val result = done
    val problem = failure
    when {
        result != null -> ResultSheet(
            outcome = Outcome.Success,
            title = stringResource(Res.string.renew_ok),
            body = result.charged?.let { stringResource(Res.string.renew_charged, toman(it)) } ?: "",
            button = stringResource(Res.string.buy_success_ok),
            onClose = { onClose(true) },
        )
        problem != null && !busy -> ResultSheet(
            outcome = Outcome.Failure,
            title = stringResource(Res.string.renew_failed_title),
            body = problem,
            button = stringResource(Res.string.renew_try_again),
            onClose = { failure = null },
        )
        else -> MoneySheet(onDismiss = { if (!busy) onClose(false) }) {
            Column(Modifier.padding(horizontal = 22.dp, vertical = 22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
              Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PlanBadge(kind)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(stringResource(Res.string.renew_title), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(svc.email ?: svc.code, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1)
                    }
                }

                when {
                    loadError != null -> Text(loadError ?: "", color = cs.error)
                    !loaded -> Text("…", color = cs.onSurfaceVariant)
                    unlimited && choices.isEmpty() -> Text(stringResource(Res.string.renew_none), color = cs.onSurfaceVariant)
                    else -> {
                        if (unlimited) {
                            Text(stringResource(Res.string.renew_users_title), style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                choices.forEachIndexed { i, c ->
                                    ChoiceRow(c, selected = picked == i, accent = accent ?: cs.primary) { picked = i; failure = null }
                                }
                            }
                        } else {
                            if (daysAdjustable && days != null) {
                                Text(stringResource(Res.string.renew_days_title), style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    VolumeDial(value = days, min = dayMin, max = dayMax, accent = accent ?: cs.primary, unit = stringResource(Res.string.renew_day_unit), onChange = { dayPick = snapDay(it) })
                                    Text("$dayMin – $dayMax " + stringResource(Res.string.renew_day_unit), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        listOf(-10, -1, 1, 10).forEach { d ->
                                            val idx = allowedDays.indexOf(days)
                                            val target = when (d) {
                                                -1 -> allowedDays.getOrElse(idx - 1) { days }
                                                1 -> allowedDays.getOrElse(idx + 1) { days }
                                                else -> snapDay(days + d)
                                            }
                                            CapsuleButton(
                                                text = if (d > 0) "+$d" else "−${-d}",
                                                onClick = { dayPick = target },
                                                container = cs.surfaceContainerHighest.copy(alpha = 0.8f),
                                                content = cs.onSurface,
                                                modifier = Modifier.weight(1f),
                                                enabled = target != days,
                                                height = 38.dp,
                                            )
                                        }
                                    }
                                }
                            }
                            Text(stringResource(Res.string.renew_gb), style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                            if (canSkipVolume) {
                                CapsuleButton(
                                    text = stringResource(if (skipVolume) Res.string.renew_add_volume else Res.string.renew_no_volume),
                                    onClick = { noVolume = !noVolume },
                                    container = if (skipVolume) (accent ?: cs.primary).copy(alpha = 0.18f) else cs.surfaceContainerHighest.copy(alpha = 0.8f),
                                    content = if (skipVolume) (accent ?: cs.primary) else cs.onSurface,
                                    modifier = Modifier.fillMaxWidth(),
                                    height = 42.dp,
                                )
                            }
                            if (!skipVolume) Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                VolumeDial(value = chosenGb, min = minGb, max = maxGb, accent = accent ?: cs.primary, unit = "GB", onChange = { gb = it })
                                Text("$minGb – $maxGb GB", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    listOf(-10, -1, 1, 10).forEach { d ->
                                        val target = chosenGb + d
                                        CapsuleButton(
                                            text = if (d > 0) "+$d" else "−${-d}",
                                            onClick = { gb = target.coerceIn(minGb, maxGb) },
                                            container = cs.surfaceContainerHighest.copy(alpha = 0.8f),
                                            content = cs.onSurface,
                                            modifier = Modifier.weight(1f),
                                            enabled = target in minGb..maxGb,
                                            height = 38.dp,
                                        )
                                    }
                                }
                            }
                        }

                        // The invoice: what is being bought, what each day and each GB costs, and what is left afterwards.
                        val tomanWord = stringResource(Res.string.account_toman)
                        val gbForInvoice: Int? = if (unlimited) null else effGb
                        if (days != null && (!unlimited || choice != null)) {
                            Surface(shape = RoundedCornerShape(22.dp), color = cs.surfaceContainerHighest.copy(alpha = 0.55f)) {
                                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                    Text(stringResource(Res.string.renew_inv_title), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                    SummaryLine(stringResource(Res.string.renew_inv_service), svc.email ?: svc.code)
                                    if (unlimited) choice?.plan?.let { SummaryLine(stringResource(Res.string.renew_inv_users), usersText(it)) }
                                    SummaryLine(stringResource(Res.string.renew_inv_days), stringResource(Res.string.renew_days, days))
                                    if (!unlimited) SummaryLine(stringResource(Res.string.renew_inv_volume), if (skipVolume) stringResource(Res.string.renew_volume_none) else stringResource(Res.string.renew_gb_value, chosenGb))
                                    if (shownPrice != null) {
                                        HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.6f))
                                        // The bot's own unit prices when its list gives them; otherwise the total divided out.
                                        val perDay = if (!unlimited && dayBase != null) perUnit(dayBase, days) else perUnit(shownPrice, days)
                                        SummaryLine(stringResource(Res.string.renew_inv_per_day), toman(perDay) + " " + tomanWord)
                                        if (!unlimited && !skipVolume && gbStep != null) SummaryLine(stringResource(Res.string.renew_inv_per_gb), toman(gbStep) + " " + tomanWord)
                                        else if (gbForInvoice != null && gbForInvoice > 0 && !skipVolume) SummaryLine(stringResource(Res.string.renew_inv_per_gb), toman(perUnit(shownPrice, gbForInvoice)) + " " + tomanWord)
                                    }
                                    HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.6f))
                                    SummaryLine(
                                        stringResource(Res.string.renew_inv_total),
                                        when {
                                            quoting -> stringResource(Res.string.renew_calc)
                                            shownPrice != null -> toman(shownPrice) + " " + tomanWord
                                            else -> stringResource(Res.string.renew_price_custom)
                                        },
                                        strong = true,
                                        tone = if (enough) cs.onSurface else cs.error,
                                    )
                                    balance?.let { SummaryLine(stringResource(Res.string.account_balance), toman(it) + " " + tomanWord) }
                                    after?.let { SummaryLine(stringResource(Res.string.renew_after), toman(it) + " " + tomanWord, tone = if (it < 0) cs.error else cs.onSurface) }
                                }
                            }
                        }
                        if (!enough) Text(stringResource(Res.string.account_err_balance), color = cs.error, style = MaterialTheme.typography.bodySmall)
                        Text(stringResource(Res.string.renew_note), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                }

              }
                if (!unlimited && info?.raw?.isNotBlank() == true) {
                    var copied by remember { mutableStateOf(false) }
                    val platform = dev.cluvex.zedsecure.ui.platform.LocalPlatform.current
                    Text(
                        if (copied) stringResource(Res.string.renew_debug_done) else stringResource(Res.string.renew_debug),
                        style = MaterialTheme.typography.labelSmall,
                        color = cs.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().clickable { platform.copyToClipboard(info?.raw.orEmpty()); copied = true },
                    )
                }
                CapsuleButton(
                    text = if (busy) "…" else stringResource(Res.string.renew_go),
                    onClick = { submit() },
                    container = cs.primary,
                    content = cs.onPrimary,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = canGo,
                    height = 54.dp,
                )
                CapsuleButton(
                    text = stringResource(Res.string.account_close),
                    onClick = { onClose(false) },
                    container = androidx.compose.ui.graphics.Color.Transparent,
                    content = cs.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy,
                    height = 44.dp,
                )
            }
        }
    }
}

/** A reference that stays the same for the same choice, so a retry after a dropped connection is not charged again. */
@Composable
private fun refFor(code: String, c: Choice?, gb: Int?, days: Int?): String {
    val key = listOf(code, c?.plan?.id, gb, days).joinToString("|")
    return remember(key) { renewRef(code) }
}

@Composable
private fun ChoiceRow(c: Choice, selected: Boolean, accent: androidx.compose.ui.graphics.Color, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val border by animateColorAsState(if (selected) accent else cs.outlineVariant, tween(200), label = "choice-border")
    val fill by animateColorAsState(if (selected) accent.copy(alpha = 0.14f) else cs.surfaceContainerHighest.copy(alpha = 0.4f), tween(200), label = "choice-fill")
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = fill,
        border = BorderStroke(if (selected) 1.5.dp else 1.dp, border),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                val title = c.plan?.let { usersText(it) }
                    ?: c.option?.days?.let { stringResource(Res.string.renew_days, it.toInt()) }
                    ?: c.option?.gb?.let { stringResource(Res.string.renew_gb_value, it.toInt()) }
                    ?: "—"
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                val sub = listOfNotNull(
                    c.plan?.let { stringResource(Res.string.buy_unlimited) },
                    c.plan?.let { c.days?.let { d -> stringResource(Res.string.renew_days, d.toInt()) } },
                    c.option?.gb?.let { stringResource(Res.string.renew_gb_value, it.toInt()) }?.takeIf { c.option?.days != null },
                ).joinToString("  ·  ")
                if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            c.price?.let {
                Text(toman(it), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = if (selected) accent else cs.onSurface)
                Spacer(Modifier.width(4.dp))
                Text(stringResource(Res.string.account_toman), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            }
            if (selected) {
                Spacer(Modifier.width(10.dp))
                Icon(painterResource(Res.drawable.ic_check_circle), contentDescription = null, tint = accent, modifier = Modifier.size(22.dp))
            }
        }
    }
}

@Composable
private fun SummaryLine(label: String, value: String, strong: Boolean = false, tone: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        Text(
            value,
            style = if (strong) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium,
            fontWeight = if (strong) FontWeight.ExtraBold else FontWeight.Medium,
            color = tone,
            textAlign = TextAlign.End,
        )
    }
}

/** The price of one unit (a day, a GB), rounded to the nearest toman. */
private fun perUnit(total: Long, units: Int): Long = if (units <= 0) 0L else (total + units / 2) / units
