@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class,
)

package dev.cluvex.zedsecure.ui.servers

import dev.cluvex.zedsecure.ui.components.glassBorder

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import dev.cluvex.zedsecure.ui.theme.pingColor
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialShapes
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.SheetValue
import androidx.compose.material3.rememberBottomSheetState
import androidx.compose.material3.toShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.cluvex.zedsecure.core.AutoSelect
import dev.cluvex.zedsecure.domain.config.VpnProfile
import dev.cluvex.zedsecure.platform.currentTimeMillis
import dev.cluvex.zedsecure.shared.resources.Res
import dev.cluvex.zedsecure.shared.resources.*
import dev.cluvex.zedsecure.ui.theme.Personalization
import dev.cluvex.zedsecure.ui.theme.goodPingColor
import dev.cluvex.zedsecure.ui.theme.ZedLime
import dev.cluvex.zedsecure.ui.theme.readableOn
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

@Composable
fun autoSelectGroupLabel(profile: VpnProfile): String {
    val group = profile.autoSelectSettings()
    return when (group?.subscriptionId) {
        null -> stringResource(Res.string.auto_group_all)
        "" -> stringResource(Res.string.group_manual)
        else -> profile.name
    }
}

@Composable
fun autoSelectLiveLine(session: AutoSelect.Session, memberName: (String) -> String?): String? {
    val status = session.status ?: return null
    val name = session.selectedProfileId?.let(memberName) ?: return null
    val delay = status.member(status.selected)?.delayMs?.takeIf { it > 0 }
    return if (delay != null) stringResource(Res.string.auto_live_with_delay, name, delay.toString())
    else stringResource(Res.string.auto_live, name)
}

@Composable
fun AutoSelectCard(
    groupLabel: String,
    memberCount: Int,
    active: Boolean,
    live: AutoSelect.Session?,
    memberName: (String) -> String?,
    onSelect: () -> Unit,
    onDetails: () -> Unit,
    personalization: Personalization = Personalization.Default,
    reduceMotion: Boolean = false,
) {
    val scheme = MaterialTheme.colorScheme
    val customActive = personalization.serverActiveColor
    val customCard = personalization.serverCardColor
    val phase = live?.status?.phase
    val accent = phaseColor(phase)

    // Default look is a soft gradient; a colour picked in Personalization wins and stays flat.
    val flat: Color? = when {
        active && customActive != null -> customActive
        !active && customCard != null -> customCard
        else -> null
    }
    val brush: Brush? = if (flat != null) null else if (active) {
        Brush.linearGradient(listOf(scheme.primaryContainer.copy(alpha = 0.85f), scheme.tertiaryContainer.copy(alpha = 0.85f)))
    } else {
        Brush.linearGradient(listOf(scheme.surfaceContainerHigh.copy(alpha = 0.65f), scheme.surfaceContainerHighest.copy(alpha = 0.55f)))
    }
    val onContainer = when {
        flat != null -> flat.readableOn()
        active -> scheme.onPrimaryContainer
        else -> scheme.onSurface
    }
    val shape = RoundedCornerShape(personalization.cornerStyle.serverCardDp.dp)
    val animate = !reduceMotion && (phase == AutoSelect.Phase.Ok || phase == AutoSelect.Phase.Starting)

    Surface(
        onClick = onSelect,
        shape = shape,
        color = flat ?: Color.Transparent,
        contentColor = onContainer,
        border = if (active) BorderStroke(1.5.dp, accent.copy(alpha = 0.55f))
        else glassBorder(),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            Modifier
                .then(if (brush != null) Modifier.background(brush) else Modifier)
                .padding(start = 14.dp, end = 6.dp, top = 14.dp, bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AutoBadge(color = accent, animate = animate, size = 48.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        stringResource(Res.string.auto_title_for, groupLabel),
                        style = MaterialTheme.typography.titleMediumEmphasized,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    val line = live?.let { autoSelectLiveLine(it, memberName) }
                        ?: stringResource(Res.string.auto_card_idle, memberCount.toString())
                    Text(
                        line,
                        style = MaterialTheme.typography.bodySmall,
                        color = onContainer.copy(alpha = 0.75f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (active) {
                    Icon(
                        painterResource(Res.drawable.ic_check_circle),
                        contentDescription = stringResource(Res.string.config_active),
                        tint = scheme.primary,
                        modifier = Modifier.size(22.dp),
                    )
                }
                IconButton(onClick = onDetails) {
                    Icon(
                        painterResource(Res.drawable.ic_info),
                        contentDescription = stringResource(Res.string.auto_details),
                    )
                }
            }
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(end = 8.dp),
            ) {
                phase?.let { StatePill(phaseLabel(it), accent, onContainer) }
                InfoPill(stringResource(Res.string.servers_count, memberCount), onContainer)
                val st = live?.status
                st?.member(st.selected)?.delayMs?.takeIf { it > 0 }?.let { d ->
                    InfoPill("$d ms", onContainer, mono = true, dot = pingColor(d.toInt(), scheme.surface))
                }
            }
        }
    }
}

/** Cookie-shaped lightning badge, with a soft expanding ring while the group is live. */
@Composable
private fun AutoBadge(color: Color, animate: Boolean, size: Dp) {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        if (animate) PulseRing(color, size)
        Box(
            Modifier
                .size(size)
                .clip(MaterialShapes.Cookie9Sided.toShape())
                .background(color),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                painterResource(Res.drawable.ic_bolt),
                contentDescription = null,
                tint = color.readableOn(),
                modifier = Modifier.size(size * 0.5f),
            )
        }
    }
}

@Composable
private fun PulseRing(color: Color, size: Dp) {
    val t = rememberInfiniteTransition(label = "auto-pulse")
    val p by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1900), RepeatMode.Restart),
        label = "auto-pulse-p",
    )
    Box(
        Modifier
            .size(size)
            .graphicsLayer {
                val k = 1f + 0.45f * p
                scaleX = k; scaleY = k; alpha = 0.40f * (1f - p)
            }
            .clip(MaterialShapes.Cookie9Sided.toShape())
            .background(color),
    )
}

@Composable
private fun StatePill(label: String, color: Color, onContainer: Color) {
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.20f), contentColor = onContainer) {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(8.dp).background(color, CircleShape))
            Spacer(Modifier.width(6.dp))
            Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun InfoPill(text: String, onContainer: Color, mono: Boolean = false, dot: Color? = null) {
    Surface(shape = RoundedCornerShape(50), color = onContainer.copy(alpha = 0.08f), contentColor = onContainer) {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            dot?.let {
                Box(Modifier.size(8.dp).background(it, CircleShape))
                Spacer(Modifier.width(6.dp))
            }
            Text(
                text,
                style = MaterialTheme.typography.labelMedium,
                fontFamily = if (mono) FontFamily.Monospace else null,
                color = onContainer.copy(alpha = 0.85f),
            )
        }
    }
}

@Composable
fun AutoSelectSheet(
    groupLabel: String,
    members: List<VpnProfile>,
    live: AutoSelect.Session?,
    onDismiss: () -> Unit,
) {
    val byId = members.associateBy { it.id }
    val memberName: (String) -> String? = { id -> byId[id]?.name }
    val status = live?.status
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberBottomSheetState(SheetValue.Hidden, setOf(SheetValue.Hidden, SheetValue.Expanded)),
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(start = 20.dp, end = 20.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AutoBadge(
                    color = phaseColor(status?.phase),
                    animate = status?.phase == AutoSelect.Phase.Ok || status?.phase == AutoSelect.Phase.Starting,
                    size = 56.dp,
                )
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        stringResource(Res.string.auto_title_for, groupLabel),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                    Spacer(Modifier.height(4.dp))
                    if (status != null) {
                        StatePill(phaseLabel(status.phase), phaseColor(status.phase), MaterialTheme.colorScheme.onSurface)
                    } else {
                        Text(
                            stringResource(Res.string.auto_not_connected),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            if (live != null && status != null) {
                val selectedName = live.selectedProfileId?.let(memberName)
                if (selectedName != null) {
                    val m = status.member(status.selected)
                    Surface(
                        shape = MaterialTheme.shapes.extraLarge,
                        color = Color.Transparent,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(
                            Modifier
                                .background(
                                    Brush.linearGradient(
                                        listOf(
                                            MaterialTheme.colorScheme.primaryContainer,
                                            MaterialTheme.colorScheme.tertiaryContainer,
                                        ),
                                    ),
                                )
                                .padding(18.dp),
                        ) {
                            Row(verticalAlignment = Alignment.Top) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        stringResource(Res.string.auto_now_on),
                                        style = MaterialTheme.typography.labelLargeEmphasized,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f),
                                    )
                                    Text(
                                        selectedName,
                                        style = MaterialTheme.typography.headlineSmallEmphasized,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                                m?.delayMs?.takeIf { it > 0 }?.let { d ->
                                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(start = 12.dp)) {
                                        Text(
                                            d.toString(),
                                            fontSize = 34.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace,
                                        )
                                        Text(
                                            "ms" + if (m.jitterMs > 0) " ±${m.jitterMs}" else "",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f),
                                        )
                                    }
                                }
                            }
                            if (m != null && m.connections > 0) {
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    stringResource(Res.string.auto_connections, m.connections.toString()),
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                            }
                            if (!status.pinned.isNullOrBlank() && AutoSelect.supportsPinning) {
                                Spacer(Modifier.height(12.dp))
                                FilledTonalButton(onClick = { AutoSelect.pin(""); Unit }) {
                                    Text(stringResource(Res.string.auto_unpin))
                                }
                            }
                        }
                    }
                }

                val healthCounts = live.memberProfiles.keys.groupingBy { status.member(it)?.health ?: AutoSelect.Health.Unknown }.eachCount()
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    StatTile(healthCounts[AutoSelect.Health.Alive] ?: 0, stringResource(Res.string.auto_health_alive), healthColor(AutoSelect.Health.Alive), Modifier.weight(1f))
                    StatTile(healthCounts[AutoSelect.Health.Suspect] ?: 0, stringResource(Res.string.auto_health_suspect), healthColor(AutoSelect.Health.Suspect), Modifier.weight(1f))
                    StatTile(healthCounts[AutoSelect.Health.Dead] ?: 0, stringResource(Res.string.auto_health_dead), healthColor(AutoSelect.Health.Dead), Modifier.weight(1f))
                }

                val events = status.events.asReversed().take(6)
                if (events.isNotEmpty()) {
                    Text(
                        stringResource(Res.string.auto_history),
                        style = MaterialTheme.typography.labelLargeEmphasized,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    events.forEach { e -> EventRow(e, live) { tag -> live.memberProfiles[tag]?.let(memberName) ?: tag } }
                }
            }

            Text(
                stringResource(Res.string.auto_members),
                style = MaterialTheme.typography.labelLargeEmphasized,
                color = MaterialTheme.colorScheme.primary,
            )
            if (live != null && status != null) {
                val rows = live.memberProfiles.entries.sortedWith(
                    compareBy<Map.Entry<String, String>>(
                        { status.member(it.key)?.health?.ordinal?.let(::healthRank) ?: 9 },
                        { status.member(it.key)?.delayMs?.takeIf { d -> d > 0 } ?: Long.MAX_VALUE },
                    ),
                )
                rows.forEach { (tag, profileId) ->
                    LiveMemberRow(
                        name = memberName(profileId) ?: tag,
                        member = status.member(tag),
                        selected = tag == status.selected,
                        pinned = tag == status.pinned,
                        onPin = if (AutoSelect.supportsPinning) {
                            { AutoSelect.pin(tag); Unit }
                        } else null,
                    )
                }
            } else {
                members.sortedBy { (it.lastPingMs ?: -1).let { p -> if (p > 0) p else Int.MAX_VALUE } }
                    .forEach { StoredMemberRow(it) }
            }

            Surface(
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.72f),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        stringResource(Res.string.auto_how_title),
                        style = MaterialTheme.typography.titleSmallEmphasized,
                    )
                    Text(
                        stringResource(Res.string.auto_how_body),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun EventRow(e: AutoSelect.Event, live: AutoSelect.Session, nameOf: (String) -> String) {
    val to = nameOf(e.to)
    val from = e.from.takeIf { it.isNotBlank() }?.let(nameOf).orEmpty()
    val text = when (e.kind) {
        AutoSelect.Reason.Startup -> stringResource(Res.string.auto_reason_startup, to)
        AutoSelect.Reason.Failover -> stringResource(Res.string.auto_reason_failover, to, from)
        AutoSelect.Reason.Faster -> stringResource(Res.string.auto_reason_faster, to, from)
        AutoSelect.Reason.Pinned -> stringResource(Res.string.auto_reason_pinned, to)
        AutoSelect.Reason.Recovered -> stringResource(Res.string.auto_reason_recovered, to)
    }
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Box(
            Modifier
                .size(8.dp)
                .clip(RoundedCornerShape(50))
                .background(
                    if (e.kind == AutoSelect.Reason.Failover) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary,
                ),
        )
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        Text(
            ago(e.atMs),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun StatTile(count: Int, label: String, color: Color, modifier: Modifier = Modifier) {
    Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.72f),
        modifier = modifier,
    ) {
        Column(
            Modifier.padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(count.toString(), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = color)
            Text(
                label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun healthColor(h: AutoSelect.Health): Color = when (h) {
    AutoSelect.Health.Alive -> ZedLime
    AutoSelect.Health.Suspect -> MaterialTheme.colorScheme.tertiary
    AutoSelect.Health.Dead -> MaterialTheme.colorScheme.error
    AutoSelect.Health.Unknown -> MaterialTheme.colorScheme.outline
}

@Composable
private fun LiveMemberRow(
    name: String,
    member: AutoSelect.Member?,
    selected: Boolean,
    pinned: Boolean,
    onPin: (() -> Unit)?,
) {
    val health = member?.health ?: AutoSelect.Health.Unknown
    val emphasis by animateFloatAsState(if (selected) 1f else 0.985f, label = "member-emphasis")
    val tone = healthColor(health)
    Surface(
        shape = MaterialTheme.shapes.large,
        color = if (selected) MaterialTheme.colorScheme.secondaryContainer
        else MaterialTheme.colorScheme.surfaceContainer,
        border = if (selected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)) else null,
        modifier = Modifier.fillMaxWidth().scale(emphasis),
    ) {
        Column(Modifier.padding(start = 12.dp, end = 6.dp, top = 10.dp, bottom = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(4.dp).height(38.dp).clip(RoundedCornerShape(50)).background(tone))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(top = 4.dp),
                    ) {
                        HealthChip(health)
                        if (selected) Chip(stringResource(Res.string.config_active), MaterialTheme.colorScheme.primaryContainer)
                        if (pinned) Chip(stringResource(Res.string.auto_pinned), MaterialTheme.colorScheme.tertiaryContainer)
                        member?.takeIf { it.connections > 0 }?.let { m ->
                            Text(
                                stringResource(Res.string.auto_connections, m.connections.toString()),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
                member?.delayMs?.takeIf { it > 0 }?.let { d ->
                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(horizontal = 6.dp)) {
                        Text(
                            d.toString(),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = pingColor(d.toInt(), MaterialTheme.colorScheme.surfaceContainer),
                        )
                        Text(
                            "ms" + if (member.jitterMs > 0) " ±${member.jitterMs}" else "",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                if (onPin != null && !pinned) {
                    IconButton(onClick = onPin) {
                        Icon(
                            painterResource(Res.drawable.ic_push_pin),
                            contentDescription = stringResource(Res.string.auto_pin),
                        )
                    }
                }
            }
            val error = member?.lastError?.takeIf {
                it.isNotBlank() && (health == AutoSelect.Health.Dead || health == AutoSelect.Health.Suspect)
            }
            AnimatedVisibility(visible = error != null) {
                Text(
                    error.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.error,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp, end = 8.dp, start = 16.dp),
                )
            }
        }
    }
}

@Composable
private fun StoredMemberRow(p: VpnProfile) {
    Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                p.name,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            p.lastPingMs?.let { ping ->
                Text(
                    if (ping > 0) "$ping ms" else stringResource(Res.string.ping_timeout),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = when {
                        ping <= 0 -> MaterialTheme.colorScheme.error
                        ping < 200 -> goodPingColor(MaterialTheme.colorScheme.surfaceContainerHigh)
                        ping < 500 -> MaterialTheme.colorScheme.tertiary
                        else -> MaterialTheme.colorScheme.error
                    },
                )
            }
        }
    }
}

@Composable
private fun HealthChip(h: AutoSelect.Health) {
    val (label, color) = when (h) {
        AutoSelect.Health.Alive -> stringResource(Res.string.auto_health_alive) to MaterialTheme.colorScheme.primaryContainer
        AutoSelect.Health.Suspect -> stringResource(Res.string.auto_health_suspect) to MaterialTheme.colorScheme.tertiaryContainer
        AutoSelect.Health.Dead -> stringResource(Res.string.auto_health_dead) to MaterialTheme.colorScheme.errorContainer
        AutoSelect.Health.Unknown -> stringResource(Res.string.auto_health_unknown) to MaterialTheme.colorScheme.surfaceContainerHighest
    }
    Chip(label, color)
}

@Composable
private fun Chip(label: String, color: Color) {
    Surface(shape = RoundedCornerShape(50), color = color) {
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = color.readableOn(),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
        )
    }
}

@Composable
private fun memberFacts(m: AutoSelect.Member): String = buildString {
    if (m.delayMs > 0) {
        append("${m.delayMs} ms")
        if (m.jitterMs > 0) append(" ±${m.jitterMs}")
    }
    if (m.connections > 0) {
        if (isNotEmpty()) append(" · ")
        append(stringResource(Res.string.auto_connections, m.connections.toString()))
    }
}

@Composable
private fun phaseLabel(p: AutoSelect.Phase): String = stringResource(
    when (p) {
        AutoSelect.Phase.Starting -> Res.string.auto_state_starting
        AutoSelect.Phase.Ok -> Res.string.auto_state_ok
        AutoSelect.Phase.Degraded -> Res.string.auto_state_degraded
        AutoSelect.Phase.Down -> Res.string.auto_state_down
        AutoSelect.Phase.Idle -> Res.string.auto_state_idle
    },
)

@Composable
private fun phaseColor(p: AutoSelect.Phase?): Color = when (p) {
    AutoSelect.Phase.Degraded -> MaterialTheme.colorScheme.tertiary
    AutoSelect.Phase.Down -> MaterialTheme.colorScheme.error
    AutoSelect.Phase.Ok -> ZedLime
    else -> MaterialTheme.colorScheme.primary
}

private fun healthRank(ordinal: Int): Int = when (AutoSelect.Health.entries[ordinal]) {
    AutoSelect.Health.Alive -> 0
    AutoSelect.Health.Suspect -> 1
    AutoSelect.Health.Unknown -> 2
    AutoSelect.Health.Dead -> 3
}

@Composable
private fun ago(atMs: Long): String {
    val seconds = ((currentTimeMillis() - atMs) / 1000).coerceAtLeast(0)
    return when {
        seconds < 45 -> stringResource(Res.string.auto_ago_now)
        seconds < 3600 -> stringResource(Res.string.auto_ago_minutes, ((seconds + 30) / 60).toString())
        else -> stringResource(Res.string.auto_ago_hours, (seconds / 3600).toString())
    }
}
