package dev.cluvex.zedsecure.ui.theme

import androidx.compose.ui.graphics.Color
import dev.cluvex.zedsecure.domain.model.AppSettings

data class ThemeProfile(
    val id: String,

    val name: String,

    val accentIndex: Int,
    val amoled: Boolean = false,
    val download: Long,
    val upload: Long,
    val downloadTile: Long,
    val uploadTile: Long,
    val connect: Long,
    val connected: Long,
    val tapHint: Long,
    val serverCard: Long,
    val serverActive: Long,
    val configCard: Long,
    val configCardText: Long,
) {
    val swatches: List<Color>
        get() = listOf(Color(connect), Color(download), Color(upload))
}

val ThemeProfiles: List<ThemeProfile> = listOf(
    ThemeProfile(
        id = "weirdnet",
        name = "WEIRDNET",
        accentIndex = 0,
        amoled = true,
        download = 0xFF63D4F2,
        upload = 0xFF9AE8FA,
        downloadTile = 0xFF0B2A33,
        uploadTile = 0xFF0F333E,
        connect = 0xFF1B9DC4,
        connected = 0xFF0F6F8F,
        tapHint = 0xFFA9E9F7,
        serverCard = 0xFF10222B,
        serverActive = 0xFF1B9DC4,
        configCard = 0xFF112A34,
        configCardText = 0xFFEAF9FF,
    ),
    ThemeProfile(
        id = "midnight",
        name = "Midnight",
        accentIndex = 2,
        amoled = true,
        download = 0xFF8FC4FF,
        upload = 0xFFB5D6FF,
        downloadTile = 0xFF0B1730,
        uploadTile = 0xFF101B36,
        connect = 0xFF2563EB,
        connected = 0xFF1E3A8A,
        tapHint = 0xFFA9C6F5,
        serverCard = 0xFF0C1526,
        serverActive = 0xFF2563EB,
        configCard = 0xFF0D1932,
        configCardText = 0xFFE6EEFF,
    ),
    ThemeProfile(
        id = "aqua",
        name = "Aqua",
        accentIndex = 1,
        amoled = false,
        download = 0xFF4DD0E1,
        upload = 0xFF80DEEA,
        downloadTile = 0xFF0A2E33,
        uploadTile = 0xFF0C373D,
        connect = 0xFF00A3B4,
        connected = 0xFF006B78,
        tapHint = 0xFFA5EAF2,
        serverCard = 0xFF0C2A2E,
        serverActive = 0xFF00A3B4,
        configCard = 0xFF0E3036,
        configCardText = 0xFFE6FCFF,
    ),
    ThemeProfile(
        id = "ice",
        name = "Ice",
        accentIndex = 3,
        amoled = false,
        download = 0xFFB5E6F7,
        upload = 0xFFD4F1FB,
        downloadTile = 0xFF16303A,
        uploadTile = 0xFF1B3844,
        connect = 0xFF3A8FB7,
        connected = 0xFF24607D,
        tapHint = 0xFFD0F0FA,
        serverCard = 0xFF15303B,
        serverActive = 0xFF3A8FB7,
        configCard = 0xFF183541,
        configCardText = 0xFFF0FBFF,
    ),
    ThemeProfile(
        id = "deepsea",
        name = "Deep Sea",
        accentIndex = 4,
        amoled = true,
        download = 0xFF7EC8DE,
        upload = 0xFFA6DCEB,
        downloadTile = 0xFF0A2430,
        uploadTile = 0xFF0D2C3A,
        connect = 0xFF14607A,
        connected = 0xFF0B3D50,
        tapHint = 0xFFA8D9E8,
        serverCard = 0xFF0B1F29,
        serverActive = 0xFF14607A,
        configCard = 0xFF0C2733,
        configCardText = 0xFFE6F6FB,
    ),
)

fun themeProfileOf(id: String?): ThemeProfile? =
    id?.let { wanted -> ThemeProfiles.firstOrNull { it.id == wanted } }

fun AppSettings.applyThemeProfile(profile: ThemeProfile): AppSettings = copy(
    accentColor = profile.accentIndex,

    dynamicColor = false,
    amoledBlack = profile.amoled,
    customDownloadColor = profile.download,
    customUploadColor = profile.upload,
    customDownloadTileColor = profile.downloadTile,
    customUploadTileColor = profile.uploadTile,
    customConnectColor = profile.connect,
    customConnectedColor = profile.connected,
    customTapHintColor = profile.tapHint,
    customServerCardColor = profile.serverCard,
    customServerActiveColor = profile.serverActive,
    customConfigCardColor = profile.configCard,
    customConfigCardTextColor = profile.configCardText,
    themeProfileId = profile.id,
)
